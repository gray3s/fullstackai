// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include "aieng/application/Principal.h"

#include <QHash>
#include <QSet>
#include <QString>

namespace aieng::application {

struct ProjectRoleGrant final {
    QString projectId;
    QSet<domain::Role> roles;
};

struct CryptographicallyVerifiedClaims final {
    QString tokenType;
    QString algorithm;
    QString keyId;
    QString issuer;
    QString subject;
    QSet<QString> audiences;
    QSet<QString> groups;
    qint64 issuedAtEpochSeconds{0};
    qint64 notBeforeEpochSeconds{0};
    qint64 expiresAtEpochSeconds{0};
    qint64 authenticatedAtEpochSeconds{0};
    QString authenticationContext;
    QString confirmationThumbprint;
    bool signatureVerified{false};
    bool duplicateMembersRejected{false};
    bool senderProofVerified{false};
};

struct IdentityPolicyConfig final {
    QString issuer;
    QString audience;
    QString tokenType{QStringLiteral("at+jwt")};
    QSet<QString> allowedAlgorithms;
    QHash<QString, ProjectRoleGrant> groupRoles;
    qint64 allowedClockSkewSeconds{30};
    qint64 maximumTokenLifetimeSeconds{900};
    qint64 maximumPrivilegedAuthenticationAgeSeconds{300};
    QString privilegedAuthenticationContext;
    bool requireSenderProof{true};
};

enum class IdentityDecisionCode {
    Accepted,
    ConfigurationInvalid,
    VerificationMissing,
    WrongTokenType,
    AlgorithmRejected,
    KeyIdentityMissing,
    IssuerMismatch,
    AudienceMismatch,
    SubjectInvalid,
    TimeInvalid,
    LifetimeExceeded,
    GroupClaimsInvalid,
    NoMappedRole,
    SenderProofRequired,
    PrivilegedAuthenticationRequired,
};

struct IdentityDecision final {
    IdentityDecisionCode code{IdentityDecisionCode::VerificationMissing};
    AuthenticatedPrincipal principal;
    QString diagnostic;

    [[nodiscard]] bool accepted() const noexcept
    {
        return code == IdentityDecisionCode::Accepted;
    }
};

class IdentityPolicy final {
public:
    explicit IdentityPolicy(IdentityPolicyConfig config);

    [[nodiscard]] IdentityDecision evaluate(
        const CryptographicallyVerifiedClaims &claims,
        qint64 nowEpochSeconds) const;

private:
    [[nodiscard]] bool configurationIsValid() const;
    [[nodiscard]] static bool isBoundedClaim(
        const QString &value,
        qsizetype maximum);
    [[nodiscard]] static bool includesPrivilegedRole(const QSet<domain::Role> &roles);
    [[nodiscard]] static IdentityDecision deny(
        IdentityDecisionCode code,
        const QString &diagnostic);

    IdentityPolicyConfig m_config;
};

} // namespace aieng::application
