# Worker claims and restart recovery

Two real CLI processes raced for one SQLite ticket via separate service invocations. Exactly one received version 4. The other received
a version conflict. A fresh process recovered the winner's original reply and expiry. Only the winning proof submitted the candidate.
At the exact expiry boundary, native tests verified takeover and refused the former owner's proposal even with the new ticket version.
The tests also cover the wrong project, role, subject, proof, duplicate audit event and authenticated lease-row tampering.

All four suites passed in debug, ASan/UBSan and hardened release. The release hardening and no-Python checks passed. The initial debug
run exposed an empty reporter in the new domain fixture. Supplying its reporter fixed the fixture and all three complete runs passed.

The lease uses the service host's UTC clock, trusted UID and persisted random proof hash. Five minutes is the initial fixed duration.
The proposal currently records a digest supplied by the worker. Next, give independent QA evidence tied to the actual candidate bytes.
The Rev 0.1 release ZIP and the owner's separate dated ZIP are outside this increment.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
