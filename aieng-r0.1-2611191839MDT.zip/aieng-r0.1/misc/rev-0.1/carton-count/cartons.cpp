// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include <charconv>
#include <iostream>
#include <string_view>

static bool quantity(std::string_view text, unsigned &out)
{
    const char *end = text.data() + text.size();
    const auto result = std::from_chars(text.data(), end, out);
    return result.ec == std::errc{} && result.ptr == end && out <= 1000000000U;
}

int main(int argc, char **argv)
{
    unsigned items = 0, capacity = 0;
    if (argc != 3 || !quantity(argv[1], items) || !quantity(argv[2], capacity) || capacity == 0) {
        std::cerr << "Usage: cartons ITEMS CAPACITY (0..1000000000 items, positive capacity)\n";
        return 2;
    }
    const unsigned cartons = items / capacity;
    std::cout << cartons << '\n';
}
