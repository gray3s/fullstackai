# AIEng Primary-Source Research Baseline

**Created:** 2026-11-19  
**Decision horizon:** December 2026  
**Purpose:** evidence before architecture lock or substantial implementation

## Research rule

Prefer final standards and first-party technical documentation. Drafts may
inform future compatibility but cannot silently become acceptance requirements.
Each architecture decision must link to the exact source/version it implements.

## Evidence matrix

| Area | Primary source | Design consequence |
| --- | --- | --- |
| Secure SDLC | NIST SP 800-218 SSDF 1.1 (final); SSDF 1.2 is still draft | Map AIEng controls/evidence to PO, PS, PW, and RV; do not claim draft conformance |
| AI development | NIST SP 800-218A (final) | Treat models, prompts, datasets, evaluations, and AI dependencies as governed development assets |
| DevSecOps supply chain | NIST SP 800-204D (final) | Harden CI/CD execution, define granular roles, automate gates, preserve evidence |
| Zero trust | NIST SP 800-207 (final) | Authenticate/authorize every resource request; network location grants no trust |
| Provenance | SLSA 1.2 (approved) and in-toto attestation model | Trusted control plane, not tenant steps, generates provenance; verify builder, signature, parameters, and subject digest |
| SBOM | SPDX 3.0 (current; ISO/IEC 5962 family) | Emit machine-readable SBOM bound to immutable artifact digest |
| Application verification | OWASP ASVS 5.0.0 (stable) | Version every applicable verification requirement and store evidence, not checkbox claims |
| Assurance maturity | OWASP SAMM 2.2 / DSOMM | Track capability maturity separately from per-release pass/fail evidence |
| Agent threats | OWASP Agentic AI Threats and Mitigations | Explicitly test memory poisoning, tool misuse, identity/privilege compromise, prompt injection, and oversight failure |
| OAuth | IETF RFC 9700 / BCP 240 | Authorization code with PKCE S256; exact redirects; no implicit grant; replay-resistant short-lived credentials |
| JWT validation | IETF RFC 8725 / BCP 225 | Pin algorithms, validate every cryptographic operation and input, exact issuer/audience, explicit token typing, and mutually exclusive rules for different JWT kinds |
| Sender-constrained tokens | IETF RFC 9449 (DPoP) | Bind access tokens to a client key and validate per-request proof; privileged APIs cannot rely on replayable bearer possession alone |
| Strong human auth | W3C WebAuthn Level 3 Recommendation (2026-08-25) | Require phishing-resistant public-key authentication for privileged roles and step-up approvals |
| Ubuntu confinement | Ubuntu AppArmor/security docs; systemd.exec | Layer DAC, separate users, AppArmor, namespaces, seccomp, cgroups, read-only roots, restricted address families, and allowlisted writable paths |
| IDE architecture | Qt Creator 20 extending manual | Extend the mature IDE through a native C++ plugin; test against an isolated matching-version Creator instance |
| C/C++/Qt build | CMake Presets specification | Commit project presets; keep user presets local; expose configure/build/test/package workflow presets |
| Language intelligence | LSP 3.17 | Use protocol adapters so language services remain replaceable and privilege-separated |
| Debugging | Debug Adapter Protocol | Reuse language-neutral debugger UI/adapters instead of embedding debugger-specific privilege in the AI agent |
| C# | Microsoft Roslyn language server and .NET-on-Ubuntu docs | Use official MIT-licensed LSP adapter; pin/test because Microsoft describes the 2026 server as supported but early/experimental |
| Native HTTP boundary | Qt HTTP Server security guidance; Drogon source/configuration; Boost.Beast documentation | Do not expose Qt HTTP Server externally. Qualify Drogon in a disposable VM behind a hardened ingress before dependency admission; keep the domain independent of every transport framework |

## Source URLs

- https://csrc.nist.gov/pubs/sp/800/218/final
- https://csrc.nist.gov/pubs/sp/800/218/a/final
- https://csrc.nist.gov/pubs/sp/800/204/d/final
- https://csrc.nist.gov/pubs/sp/800/207/final
- https://slsa.dev/spec/v1.2/tracks
- https://slsa.dev/spec/v1.2/build-requirements
- https://slsa.dev/spec/v1.2/build-provenance
- https://spdx.dev/use/specifications/
- https://asvs.owasp.org/
- https://owasp.org/projects/samm
- https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/
- https://www.rfc-editor.org/rfc/rfc9700.html
- https://www.rfc-editor.org/rfc/rfc8725.html
- https://www.rfc-editor.org/rfc/rfc9449.html
- https://openid.net/specs/openid-connect-core-1_0-final.html
- https://www.w3.org/TR/webauthn-3/
- https://documentation.ubuntu.com/security/security-features/privilege-restriction/apparmor/
- https://www.freedesktop.org/software/systemd/man/latest/systemd.exec
- https://doc.qt.io/qtcreator-extending/
- https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/
- https://microsoft.github.io/debug-adapter-protocol/overview
- https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html
- https://github.com/dotnet/roslyn/blob/main/src/LanguageServer/roslyn-language-server/README.md
- https://learn.microsoft.com/dotnet/core/install/linux-ubuntu-install
- https://doc.qt.io/qt-6/qthttpserver-security.html
- https://doc.qt.io/qt-6/qthttpserver-index.html
- https://github.com/drogonframework/drogon/blob/master/config.example.json
- https://github.com/drogonframework/drogon/blob/master/lib/inc/drogon/HttpAppFramework.h
- https://www.boost.org/doc/libs/release/libs/beast/doc/html/beast/introduction.html

## Architecture consequences before implementation

1. **Do not create an editor from scratch.** Deliver AIEng primarily as a
   native Qt Creator extension plus independently deployable native services.
2. **Do not place the model in the trusted control plane.** The model is an
   untrusted proposer behind deterministic policy/tool adapters.
3. **Do not let build steps sign their own truth.** The trusted orchestrator
   observes inputs/outputs and generates provenance outside tenant execution.
4. **Do not treat a container as a security boundary.** Hostile builds use a
   defense-in-depth sandbox and, for higher risk, a disposable KVM guest.
5. **Do not bind the platform to one model, forge, registry, IdP, language
   server, or deployment system.** All are versioned adapters with conformance
   tests.
6. **Do not claim standard compliance from tool presence.** Store requirement-
   keyed, reproducible evidence and explicit exceptions.
7. **Dogfood the governed path.** AIEng is its own permanent reference project,
   while human QA/release authorities remain independent of AI-generated work.
8. **Do not expose an embedded Qt HTTP listener.** Qt explicitly says its HTTP
   Server is not hardened against network attacks. The installed Qt 6.4.2 also
   predates the configuration limits added in Qt 6.10 and 6.11.
9. **Do not couple policy to HTTP.** Network code authenticates, validates, and
   translates bounded requests into typed application commands. The domain
   remains authoritative and transport-agnostic.
10. **Do not write a JWT implementation.** A qualified native verifier must
    reject duplicate JSON members and prove cryptography before the independent
    identity policy sees structured claims. Exact role mapping, time policy,
    sender proof, and privileged step-up remain deterministic AIEng policy.

## Open research before topology lock

- Complete the disposable-VM qualification gate for the provisional Drogon
  transport candidate: pinned source/package provenance, compiler hardening,
  malformed-request corpus, resource ceilings, TLS/ingress behavior, security
  response process, and license inventory. No dependency is admitted before
  that evidence passes.
- Select PostgreSQL migration and connection approach for native C++ without
  introducing a scripting runtime.
- Execute the documented Ubuntu 26.04 KVM/libvirt/AppArmor qualification plan
  against concrete hostile-build fixtures once host device, memory, package,
  and storage prerequisites are explicitly authorized and satisfied.
- Select the Git forge, OCI/artifact registry, OIDC provider, secrets manager,
  and signing/attestation implementation using pinned compatibility matrices.
- Threat-model browser ticket intake separately from the Qt Creator extension.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

