# AIEng local-development policy

## Hard no-Python rule

- Do not add, generate, vendor, install, or retain Python source, bytecode,
  virtual environments, package metadata, build steps, launchers, or runtime
  dependencies in this project.
- Do not invoke Python from scripts, CMake, tests, services, containers, CI, or
  application code.
- Algorithm experiments may occur only outside this repository and must be
  translated into C++, Qt 6, C, or another approved compiled C-like language
  before admission.
- Prefer modern C++ with Qt 6 for applications and substantial tools. Bash is
  limited to small orchestration tasks.
- Every checkpoint requires a no-Python artifact and invocation audit.

## Standard five-hour development procedure

Hard-wrap prose intended for gedit at approximately 140 characters per line. Preserve runnable commands, paths and URLs.

For each substantive continuation:

1. Reconstruct the hierarchy, verified state, active subproject, supporting
   test beds, and explicitly out-of-scope projects.
2. Create a timestamped Markdown work-window charter under `docs/work-windows/`
   documenting decisions, evidence authority, goals, ordered steps, acceptance
   evidence, boundaries, stop conditions, blockers, and deliverables.
3. Open the charter in gedit and establish/update the persistent goal.
4. Implement immediately, preserving failed evidence and never weakening a
   gate to claim success.
5. Give milestone updates and align the charter/checkpoint with material
   decisions.
6. Validate proportionally, run the no-Python audit, and write a timestamped
   resume checkpoint with the next authorized action.


## Progress stops and handoff

Keep one timestamped resume record under docs/checkpoints/ for the active window. Before each substantive operation, write the
last verified revision, intended change or check, and next safe action. Update the record after a failed check, a scope change,
and before switching units. Record the failure and the unfinished paths. Mark a capability verified only after its check passes.

Use the most recent allowance the owner reports. At 15% switch to closing the current small unit. At 10% start no new feature
work. At 5% save the exact state and end the window. Honor an explicit stop immediately. These are project operating defaults.
A handoff identifies where the governing plan lives, the verified baseline, unverified work, its acceptance test and the first
command or action for resumption. Run the repository artifact audit before recording a checkpoint as complete.
