# Who builds, runs and operates AIEng

Samuel A. Gray III directs the project and owns the software. Codex supplies development assistance. Building a product with an AI
does not give that AI an account, a running process, or authority in the installed product.

| Baseline | What runs when installed | Who authorizes changes and operates it |
| --- | --- | --- |
| Rev 0.1 review bundle | Native ticket service, staff form and CLI. The sample repair uses a supplied patch and a scripted rehearsal. | Staff submit and queue tickets. The local operator runs the example. No corporate production deployment was demonstrated. |
| Post-0.1 development series | Native control plane and CLI. An optional service endpoint accepts scoped worker claims and proposals. The installed service launches no model. | The host operator selects accounts and listeners. QA admits and reviews the candidate. A separate release identity authorizes it. The operator installs and confirms it on the target. Corporate operations remain with the organization. |

### Why introduce a runtime agent?

In the post-0.1 native service, omitting the worker listener keeps worker pickup off. A designated human developer may submit a repair from
the same queue. Starting the worker listener enables its protocol. A stopped worker's ticket becomes available for manual repair at lease
expiry. Both routes converge at the same independent QA admission gate. A shell client can exercise the worker protocol in full without
starting any inference engine. The standalone staff form is optional at runtime and the CLI handles intake.

Give it a job where judgment can save human effort. For the carton example, a worker could inspect the ticket, reproduce the partial-carton
failure, propose a rounding fix, and run the assigned acceptance tests. The same ticket can go to a developer. Compare both paths on
accepted fixes, reviewer time, regressions and total cost before expanding the agent's role.

DevSecOps can use ordinary CI/CD. Deterministic tools build, test and package changes, enforce policy, and produce evidence for a release
decision. Agentic AI is an optional producer of candidate changes in AIEng's design. This is our architectural interpretation of
[NIST SP 800-204D](https://csrc.nist.gov/pubs/sp/800/204/d/final) and [NIST SP 800-218](https://csrc.nist.gov/pubs/sp/800/218/final).

### Minimum contract for an active repair agent

1. A project owner defines the allowed repository, base revision, goal, acceptance tests and escalation contact.
2. An opt-in worker receives a scoped identity and an expiring ticket claim. Its isolated workspace has explicit tool, network, credential,
   time and cost limits. An operator can stop further pickup and route work to a developer.
3. The agent may select its next allowed action, inspect results, revise a candidate or return the ticket. Capture its model, inputs,
   tool calls, patch, build and test evidence so another party can reproduce the work.
4. A deterministic service validates the candidate and records its digest. Independent QA reviews the exact artifact and test evidence.
5. A separate release authority approves an artifact and environment. Operations owns rollout, monitoring, rollback, incident response
   and the decision to restore service. The Carton Count experiment exercises this sequence on a local target with test identities.

### What every release records

Record the release tag or source commit, who authored it, whether a model runs at installation or on demand, what each optional feature
can do, its default, how to turn it off, and the tested fallback for in-flight work. Name who owns QA, release, deployment, on-call and
rollback. Distinguish observed behavior, rehearsals and planned features. Cite the tests or checkpoint for both enabled and disabled
operation. Any future proposal to transfer operational authority to AI requires an explicit owner decision for that version.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
