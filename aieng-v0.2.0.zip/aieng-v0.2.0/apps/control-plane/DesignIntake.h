// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include <QJsonObject>
#include <optional>

namespace intake {
std::optional<QJsonObject> designTicket(bool useDefaults);
}
