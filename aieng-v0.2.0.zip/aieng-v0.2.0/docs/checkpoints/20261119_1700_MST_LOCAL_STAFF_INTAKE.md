# Native staff intake

Staff can create and read their own work orders through two Ubuntu processes.
The service accepts one bounded packet, derives the reporter from the local
socket peer and assigns the configured project. The ticket summary and multiline
description commit with the row and its audit event. The row MAC covers the
text. Denied workflow transitions return an empty ticket.

All four CTest suites passed in debug, ASan/UBSan and hardened release, including
the private socket test and the durable reopen/privacy/tamper regressions. The
first socket test encountered EPERM in the restricted sandbox. The approved run
exercised the real transport. The no-Python audit passed. Leak detection remains
pending in the standard sanitizer preset.

Resume with the staff intake user interface and project assignment workflow.
The README contains a repeatable local demo. Production identity, agent patch
generation and deployment remain outstanding.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
