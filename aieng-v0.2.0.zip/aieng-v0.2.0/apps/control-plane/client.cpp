// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "Packet.h"
#include "CandidateTransfer.h"
#include "DesignIntake.h"
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QFile>
#include <sys/un.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>

int main(int argc, char **argv)
{
    QCoreApplication process(argc, argv);
    const auto args = process.arguments();
    const auto op = args.value(2);
    const bool design = op == "design" && (args.size() == 3 || (args.size() == 4 && args[3] == "--defaults"));
    const bool transition = (op == "triage" || op == "queue") && args.size() == 5;
    const bool list = op == "list" && (args.size() == 4 || args.size() == 5);
    const bool workerAction = (op == "claim" && args.size() == 5) || (op == "propose" && args.size() == 6);
    const bool admit = op == "qa-admit" && args.size() == 6;
    const bool manual = op == "propose-file" && args.size() == 6;
    const bool checkout = (op == "qa-checkout" || op == "deploy-fetch") && args.size() == 5;
    const bool approve = (op == "qa-pass" || op == "release-approve" || op == "deploy-start" || op == "deploy-confirm") && args.size() == 6;
    if (!design && !list && !transition && !workerAction && !admit && !manual && !checkout && !approve
        && (args.size() != 4 || (op != "create" && op != "show"))) {
        std::fputs("Usage: aieng-ticket SOCKET design [--defaults]\n"
                   "       aieng-ticket SOCKET create SUMMARY < description.txt\n"
                   "       aieng-ticket SOCKET show TICKET-ID\n"
                   "       aieng-ticket SOCKET list STATE [AFTER-ID]\n"
                   "       aieng-ticket SOCKET triage|queue TICKET-ID VERSION < rationale.txt\n"
                   "       aieng-ticket SOCKET claim TICKET-ID VERSION < proof.hex\n"
                   "       aieng-ticket SOCKET propose TICKET-ID VERSION sha256:DIGEST < proof.hex\n"
                   "       aieng-ticket SOCKET qa-admit|propose-file TICKET-ID VERSION CANDIDATE-FILE\n"
                   "       aieng-ticket SOCKET qa-checkout|deploy-fetch TICKET-ID NEW-FILE\n"
                   "       aieng-ticket SOCKET qa-pass|release-approve|deploy-start|deploy-confirm TICKET-ID VERSION sha256:DIGEST < note.txt\n", stderr);
        return 2;
    }
    QJsonObject request{{"op", args[2]}};
    QByteArray candidate;
    if (design) {
        const auto interview = intake::designTicket(args.size() == 4);
        if (!interview) return 2;
        request = *interview;
    } else if (admit || manual) {
        candidate = intake::readCandidateFile(args[5]);
        if (candidate.isEmpty()) {
            std::fputs("Select a readable regular candidate file between 1 byte and 16 MiB.\n", stderr);
            return 2;
        }
        request.insert("id", args[3]);
        request.insert("version", args[4]);
        if (admit) request.insert("size", static_cast<qint64>(candidate.size()));
        else request.insert("digest", QStringLiteral("sha256:") + QString::fromLatin1(
            QCryptographicHash::hash(candidate, QCryptographicHash::Sha256).toHex()));
    } else if (checkout) {
        request.insert("id", args[3]);
    } else if (list) {
        request.insert("state", args[3]);
        request.insert("after", args.value(4));
    } else if (op != "show") {
        QFile input;
        if (!input.open(stdin, QIODevice::ReadOnly)) return 2;
        const auto bytes = input.read(32769);
        if (bytes.size() > 32768 || !bytes.isValidUtf8()) {
            std::fputs("Enter bounded UTF-8 text on standard input.\n", stderr);
            return 2;
        }
        if (workerAction) {
            request.insert("id", args[3]);
            request.insert("version", args[4]);
            request.insert("proof", QString::fromUtf8(bytes).trimmed());
            if (op == "propose") request.insert("digest", args[5]);
        } else if (transition || approve) {
            request.insert("id", args[3]);
            request.insert("version", args[4]);
            request.insert("rationale", QString::fromUtf8(bytes).trimmed());
            if (approve) request.insert("digest", args[5]);
        } else {
            request.insert("summary", args[3]);
            request.insert("description", QString::fromUtf8(bytes));
        }
    } else {
        request.insert("id", args[3]);
    }
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    const auto path = QFile::encodeName(args[1]);
    if (path.isEmpty() || path.size() >= static_cast<qsizetype>(sizeof(address.sun_path))) return 2;
    std::memcpy(address.sun_path, path.constData(), static_cast<size_t>(path.size()));
    const int fd = socket(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0);
    if (fd < 0 || !intake::setTimeouts(fd) || connect(fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)) != 0
        || !intake::sendPacket(fd, request)) {
        std::perror("Ticket service connection");
        return 1;
    }
    auto response = intake::receivePacket(fd);
    if (admit && response.value("ready").toBool()) {
        if (!intake::sendCandidate(fd, candidate)) {
            close(fd);
            std::fputs("Candidate transfer failed.\n", stderr);
            return 1;
        }
        response = intake::receivePacket(fd);
    }
    if (checkout && !response.contains("error")) {
        const auto bytes = intake::receiveCandidate(fd, response.value("size").toInteger());
        const auto digest = QStringLiteral("sha256:") + QString::fromLatin1(QCryptographicHash::hash(bytes, QCryptographicHash::Sha256).toHex());
        if (bytes.isEmpty() || response.value("artifact_digest") != digest || !intake::saveNewCandidateFile(args[4], bytes)) {
            close(fd);
            std::fputs("Could not verify the download or create a new destination file.\n", stderr);
            return 1;
        }
    }
    close(fd);
    if (response.isEmpty()) {
        std::fputs("Ticket service did not confirm the request.\n", stderr);
        return 1;
    }
    const bool failed = response.contains("error");
    std::fputs(QJsonDocument(response).toJson().constData(), failed ? stderr : stdout);
    return failed ? 1 : 0;
}
