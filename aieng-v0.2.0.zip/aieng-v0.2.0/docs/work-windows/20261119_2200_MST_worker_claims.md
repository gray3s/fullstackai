# Resume worker pickup

Resume from 6682730 in the native AIEng control plane. Rev 0.1 covers intake, support triage and queue discovery.
The Carton Count rehearsal and its publication ZIP are historical release evidence. The LinkedIn brief confirms the native stack,
self-QA and independent release authority. DTA/DTE integration, CarCase and corporate deployment are outside this change.

Give a dedicated project worker access to queued work through the Unix socket. Persist a bounded lease on the authenticated ticket
row. Serialize acquisition, bind the lease to worker identity and proof of possession, and fence stale submissions after takeover.
Exercise two independent clients, service restart, expiry, competing subjects and project isolation. Preserve old ticket MACs.
Run the debug, sanitizer, hardened release and no-Python gates and checkpoint the next authorized action. Preserve failed evidence if
a gate fails. A claim authorizes a patch proposal only. Human QA and release authority remain separate.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
