# AIEng specification research

Starting point 964918f and the working glossary from the November 20 discussion. The saved discussion is the record of the owner's
question. The persistent objective for this research window is a set of testable draft clauses for live-worker QA and deployment.
Preserve the reply and glossary first. Next, inspect primary sources on test oracles, proof scope, security assurance, change assessment
and worker evaluation. Distinguish source findings, proposed project rules and observed pilot evidence. Save the research as a second
restore point. Apply the clauses to one known case and record the remaining decisions in a final checkpoint. The product implementation,
inference trials, external publication and DTA/DTE work are outside this research window.
