# First native-ticket Carton Count deployment

Ticket 35718821-6c34-45c5-9641-cb393abaaac8 reached DEPLOYED at version 9 in a disposable local installation with the worker off.
The example reproduces the original prompt's partial-carton bug. A supplied C++ patch is compiled for the candidate. Project-scoped
native commands handle QA admission, checked file retrieval, review, authorization to fetch for deployment, and operator confirmation.
On this single-login host, the developer and release identities are controlled test principals. QA and the local operator used the kernel
Unix UID. The shell harness performs the independent test cases and the target-specific install. No model participates at runtime.

Security observations: QA refused the original executable in place of the proposed candidate. The operator could not fetch the candidate
before release approval. Separate socket tests refused QA self-review and release approval by the QA approver.

Reliability observations: the original command returned 2 cartons for 25 items at capacity 12. The candidate returned 3. Five valid cases
passed and zero capacity returned exit 2. An injected failing smoke expectation restored the old executable and its result of 2. The
same installation procedure with the correct expectation activated the fix and returned 3. SHA-256 of both QA and installed files:
`353ad9e63ae59ac0deee6d58008756ce13478a0709e874db26ba2a5b325cbf9c`.

All five suites passed in debug, ASan/UBSan and hardened release, including the release hardening and no-Python checks. A direct sandbox
run could not bind its private socket. It passed with local socket permission. A first retained run revealed that cleanup missed the
retention argument. The corrected release run kept evidence and the installed executable under /tmp/tmp.V9zaVw3Fn0. Temporary files may
be cleaned by the host. Reproduce from the README's Carton Count commands.

The local test covers one C++ command on one host. Fresh-machine installation, distinct operating accounts and a second prompt-built
project are the next useful product tests. The project's experimental goals and per-version operating model govern future scope.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
