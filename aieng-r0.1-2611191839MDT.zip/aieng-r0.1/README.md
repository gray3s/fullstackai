# AIEng

AIEng is a secure, self-hosted engineering workstation and DevSecOps control
plane for Ubuntu. It combines C, C++, C#, and Qt 6 development, corporate
support-ticket intake, a local patch-generation agent, isolated test execution,
human QA approval, signed artifacts, and controlled production promotion.

> Project viewpoint: December 2026. The architecture assumes modern software-
> supply-chain controls while remaining deployable on an Ubuntu server today.

## Core safety rule

The local AI can read an assigned ticket, create a branch, propose a patch, and
run approved tests in an isolated worker. It cannot approve its own work, access
production credentials, or deploy to production. QA and production promotion
are separate, attributable human actions.

The intended developer experience is a native AIEng extension to Qt Creator,
backed by independently deployable native C++ services. AIEng is also its own
first governed project: it must QA and secure itself through the same evidence
pipeline it generates for other projects, without allowing AI self-approval.

## Current verified state

The project is in architecture/research baseline and native bootstrap. No
production-ready service is claimed yet. See the dated charter, primary-source
research baseline, QA plan, security model, and checkpoints under `docs/`.

## Repository map

- `apps/control-plane`: native ticket, approval, deployment, and audit service
- `apps/agent`: native local-model orchestration and deterministic tool broker
- `apps/creator-plugin`: native AIEng Qt Creator integration
- `libs`: reusable native domain, policy, evidence, and protocol libraries
- `tests`: deterministic, adversarial, integration, and golden-project suites
- `toolchains`: reproducible C/C++/Qt 6 and .NET build images
- `infra`: local turnkey deployment configuration
- `docs`: architecture, security model, operations, and decision records
- `scripts`: bootstrap, verification, backup, and recovery commands

## Development

```bash
make check
```

This runs the no-Python audit, builds the native targets and executes CTest. The
intake integration suite uses systemd-socket-activate, openssl, jq and a private
Unix socket to file and retrieve a ticket across two service invocations.

## Try staff ticket intake on Ubuntu

From the repository root, build with `make check`. Start a private development
instance with the following commands. The printed directory identifies this
instance and holds its database and key. Keep both together for recovery.

```bash
umask 077
intake_dir=$(mktemp -d)
printf '%s\n' "$intake_dir"
openssl rand -out "$intake_dir/key" 32
systemd-socket-activate --seqpacket --accept --inetd -l "$intake_dir/socket" \
    build/dev/apps/control-plane/aieng-ticket-service "$intake_dir/tickets.db" "$intake_dir/key" demo
```

In another terminal at the repository root, set `intake_dir` to the printed
directory. The first command returns the ticket ID. Use that ID in the second.

```bash
printf '%s\n' 'Opening the Qt kit closes the editor.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" create 'Qt kit closes editor'
build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" show TICKET-ID
```

Ctrl+C stops the listener. Reuse the directory and key to reopen the instance.
To file and look up tickets in the Qt staff form, run
`build/dev/apps/control-plane/aieng-staff "$intake_dir/socket"` while the listener runs.
After filing, use **Copy ticket ID** to save the reference for follow-up.
The local service associates each reporter with the kernel-supplied Unix UID.
Use a dedicated database per host identity domain. This development transport
supports filing and reading your own tickets. Corporate remote login and
agent processing are pending.

### Triage a ticket and queue it for repair

To designate a local support operator for the listener's project, append
`--support-uid NUMERIC-UID` to the **service** command at startup. For a private
demo, use your own numeric UID from `id -u`. The service matches this setting
against the UID supplied by the kernel for each connection. Omitting the setting
keeps the listener in reporter mode.

Use `aieng-ticket SOCKET list OPEN` to find reports that need triage. Use
`TRIAGED` or `AGENT_QUEUED` to inspect the later queues. Results include up to
25 ticket IDs, summaries and versions ordered by ticket ID. When `next_after`
contains an ID, pass it as the final argument to fetch the next page. Each
request reflects current state, so restart the listing to include newly queued
items whose IDs sort before the cursor.

Use the version returned by `show` or by the last successful transition. For a
new ticket the sequence is:

```bash
printf '%s\n' 'Confirmed the failure with the Qt kit.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" triage TICKET-ID 1
printf '%s\n' 'Prepare a candidate fix for this build failure.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" queue TICKET-ID 2
```

If another operator acts first, re-read the ticket before deciding whether
the action is still appropriate. A successful queue command records
`AGENT_QUEUED` and its rationale. Worker pickup and patch generation are pending.

See [Architecture](docs/ARCHITECTURE.md), [Security model](docs/SECURITY.md),
[QA plan](docs/QA_PLAN.md), and the
[research baseline](docs/research/20261119_AIENG_PRIMARY_SOURCE_RESEARCH_BASELINE.md)
before enabling an agent or connecting any external environment.

The [product requirements](docs/PRODUCT_REQUIREMENTS.md) define the guided
production path for inexperienced creators and the CTO-grade controls that may
not be bypassed.

## Ownership

Copyright © 2026 Samuel A. Gray III. All rights reserved.

This repository is proprietary. No license to copy, modify, distribute,
sublicense, or operate this software for third parties is granted without the
copyright holder's written permission.

