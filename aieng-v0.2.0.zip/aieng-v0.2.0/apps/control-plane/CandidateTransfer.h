// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include "aieng/domain/Workflow.h"

#include <QDeadlineTimer>
#include <QFile>
#include <QFileInfo>
#include <QTemporaryFile>
#include <algorithm>
#include <cerrno>
#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

namespace intake {
inline constexpr qsizetype chunkSize = 32768;

inline QByteArray readCandidateFile(const QString &path)
{
    const int fd = open(QFile::encodeName(path).constData(), O_RDONLY | O_NONBLOCK | O_NOFOLLOW | O_CLOEXEC);
    if (fd < 0) return {};
    QFile file;
    if (!file.open(fd, QIODevice::ReadOnly, QFileDevice::AutoCloseHandle)) {
        close(fd);
        return {};
    }
    struct stat info{};
    if (fstat(fd, &info) || !S_ISREG(info.st_mode) || info.st_size < 1
        || info.st_size > aieng::domain::maxCandidateBytes) return {};
    auto bytes = file.read(info.st_size + 1);
    if (bytes.size() != info.st_size || file.error() != QFileDevice::NoError) return {};
    return bytes;
}

inline bool sendCandidate(int fd, const QByteArray &bytes)
{
    for (qsizetype offset = 0; offset < bytes.size();) {
        const auto count = std::min(chunkSize, bytes.size() - offset);
        ssize_t sent;
        do {
            sent = send(fd, bytes.constData() + offset, static_cast<size_t>(count), MSG_NOSIGNAL);
        } while (sent < 0 && errno == EINTR);
        if (sent != count) return false;
        offset += count;
    }
    return true;
}

inline bool saveNewCandidateFile(const QString &path, const QByteArray &bytes)
{
    QTemporaryFile temporary(QFileInfo(path).absolutePath() + QStringLiteral("/.aieng-XXXXXX"));
    if (!temporary.open() || temporary.write(bytes) != bytes.size() || !temporary.flush()) return false;
    const auto source = QFile::encodeName(temporary.fileName());
    const auto target = QFile::encodeName(path);
    return link(source.constData(), target.constData()) == 0;
}

inline QByteArray receiveCandidate(int fd, qsizetype size)
{
    if (size < 1 || size > aieng::domain::maxCandidateBytes) return {};
    QByteArray bytes(size, Qt::Uninitialized);
    QDeadlineTimer deadline(10000);
    for (qsizetype offset = 0; offset < size;) {
        const auto timeout = deadline.remainingTime();
        if (timeout <= 0) return {};
        pollfd descriptor{fd, POLLIN, 0};
        const int ready = poll(&descriptor, 1, static_cast<int>(timeout));
        if (ready < 0 && errno == EINTR) continue;
        if (ready <= 0) return {};
        const auto count = std::min(chunkSize, size - offset);
        const auto received = recv(fd, bytes.data() + offset, static_cast<size_t>(count), MSG_TRUNC | MSG_DONTWAIT);
        if (received < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (received != count) return {};
        offset += count;
    }
    return bytes;
}
} // namespace intake
