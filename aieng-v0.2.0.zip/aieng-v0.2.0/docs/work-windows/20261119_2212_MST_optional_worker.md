# Operate with the worker disabled

Start at 870c300. Provide a human developer path from the conventional repair queue to the same independently reviewed proposal.
Use a dedicated project-scoped developer listener. Preserve worker exclusivity while its lease is valid. Verify manual takeover at the
expiry boundary. Run the socket path with the worker absent and exercise the complete path with distinct native test principals.
Update the version record with authorship, runtime capability, production authority, optional features and supporting evidence.
Run the three verification profiles and audit. Checkpoint before starting QA checkout.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
