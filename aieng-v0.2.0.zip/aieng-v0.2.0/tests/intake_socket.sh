#!/usr/bin/env bash
# Copyright © 2026 Samuel A. Gray III. All rights reserved.
set -euo pipefail
umask 077
client=$1
service=$2
scratch=$(mktemp -d)
openssl rand -out "$scratch/key" 32
systemd-socket-activate --seqpacket --accept --inetd -l "$scratch/socket" \
    "$service" "$scratch/db" "$scratch/key" sample >"$scratch/log" 2>&1 &
listener=$!
listeners=("$listener")
cleanup() {
    for pid in "${listeners[@]}"; do
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
    done
    rm -f -- "$scratch/support" "$scratch/other" "$scratch/mismatch" "$scratch/socket" "$scratch/db" "$scratch/db-wal" "$scratch/db-shm" "$scratch/key" "$scratch/log" \
        "$scratch/worker" "$scratch/foreign-worker" "$scratch"/race-{a,b} "$scratch"/proof-{a,b} \
        "$scratch"/{qa,foreign-qa,candidate,substitute,link,fifo,developer,manual,checked-out,release}
    rmdir -- "$scratch"
}
trap cleanup EXIT
trap 'cat "$scratch/log" >&2' ERR
for (( i=0; i<100; i++ )); do
    [[ -S "$scratch/socket" ]] && break
    kill -0 "$listener"
    sleep 0.03
done
order=$(printf '%s\n' 'Select Build.' 'The window closes.' | "$client" "$scratch/socket" create "Build window closes")
id=$(jq -er '.id | select(length == 36)' <<< "$order")
saved=$("$client" "$scratch/socket" show "$id")
jq -e '.project == "sample" and .state == "OPEN" and .summary == "Build window closes" and .description == "Select Build.\nThe window closes.\n"' <<< "$saved"
if "$client" "$scratch/socket" show nonexistent; then exit 1; fi
quick=$(printf '%s\n' 'My algorithm' | "$client" "$scratch/socket" design --defaults)
quick_id=$(jq -er '.id' <<<"$quick")
"$client" "$scratch/socket" show "$quick_id" | jq -e '.state == "OPEN" and .summary == "My algorithm"
    and (.description | contains("Implementation (AIEng default)") and contains("Open question (Inputs)") and contains("Open question (R1 failure)"))'
interview=$(printf '%s\n' 'User selected behavior' 'Business purpose' 'Input X' 'Output Y' 'Device Z' ':split' 'First behavior' \
    'Rule X to Y' 'X yields Y' 'Y missing' '' 'Short iterations' 'IT wants bounded downtime' 'Restore within the agreed window' \
    '2' 'Use the existing build' 'Fast turnaround but integration testing required' '?' 'no' 'yes' '' | "$client" "$scratch/socket" design)
jq -e '.description | contains("R1.1 failure (developer): Y missing") and contains("Implementation (developer): Use the existing build")
    and contains("Open question (QA)") and contains("Design (developer): Prototype") and contains("blocked by reported constraint")
    and contains("Deployment (AIEng default): maintenance window") and contains("R1.1 next step: implement")' <<<"$interview"
if printf '%s\n' '?' | "$client" "$scratch/socket" design --defaults; then exit 1; fi
if printf '%s\n' 'Unfinished' | "$client" "$scratch/socket" design; then exit 1; fi
QT_QPA_PLATFORM=offscreen AIENG_TEST_SOCKET="$scratch/socket" "$3"
if "$client" "$scratch/socket" triage "$id" 1 <<< "Reviewed the report"; then exit 1; fi
support_listener() {
    systemd-socket-activate --seqpacket --accept --inetd -l "$scratch/$1" \
        "$service" "$scratch/db" "$scratch/key" "$2" "${4:---support-uid}" "$3" >>"$scratch/log" 2>&1 &
    local pid=$!
    listeners+=("$pid")
    for (( i=0; i<100; i++ )); do
        [[ -S "$scratch/$1" ]] && return 0
        kill -0 "$pid"
        sleep 0.03
    done
    return 1
}
test_uid=$(id -u)
support_listener mismatch sample "$((test_uid == 0 ? 1 : 0))"
if denied=$("$client" "$scratch/mismatch" triage "$id" 1 <<< "Reviewed the report" 2>&1); then exit 1; fi
jq -e '.error == "Project support access required"' <<< "$denied"
support_listener other unrelated "$test_uid"
if "$client" "$scratch/other" triage "$id" 1 <<< "Reviewed the report"; then exit 1; fi
support_listener support sample "$test_uid"
"$client" "$scratch/support" triage "$id" 1 <<< "Reproduced build failure" | jq -e '.state == "TRIAGED" and .version == "2"'
if "$client" "$scratch/support" queue "$id" 1 <<< "Assigned for repair"; then exit 1; fi
"$client" "$scratch/support" queue "$id" 2 <<< "Assigned for repair" | jq -e '.state == "AGENT_QUEUED" and .version == "3"'
"$client" "$scratch/socket" show "$id" | jq -e '.state == "AGENT_QUEUED" and .version == "3"'
if "$client" "$scratch/socket" list AGENT_QUEUED; then exit 1; fi
if "$client" "$scratch/support" list INVALID; then exit 1; fi
"$client" "$scratch/other" list AGENT_QUEUED | jq -e '.tickets == []'
"$client" "$scratch/support" list AGENT_QUEUED | jq -e --arg id "$id" '.tickets == [{id:$id,summary:"Build window closes",version:"3"}]'
# Exercise manual repair before enabling a worker listener.
support_listener developer sample "$test_uid" --developer-uid
printf 'human candidate bytes' >"$scratch/manual"
manual_sha="sha256:$(sha256sum "$scratch/manual" | cut -d' ' -f1)"
manual_id=$("$client" "$scratch/socket" create "Manual repair" <<<"Repair with worker pickup disabled." | jq -er '.id')
"$client" "$scratch/support" triage "$manual_id" 1 <<<"Reproduced issue" >/dev/null
"$client" "$scratch/support" queue "$manual_id" 2 <<<"Assign for manual repair" >/dev/null
"$client" "$scratch/developer" list AGENT_QUEUED | jq -e --arg id "$manual_id" 'any(.tickets[]; .id == $id)'
if "$client" "$scratch/support" propose-file "$manual_id" 3 "$scratch/manual"; then exit 1; fi
"$client" "$scratch/developer" propose-file "$manual_id" 3 "$scratch/manual" | \
    jq -e --arg digest "$manual_sha" '.state == "PATCH_PROPOSED" and .version == "4" and .artifact_digest == $digest'
support_listener worker sample "$test_uid" --worker-uid
support_listener foreign-worker unrelated "$test_uid" --worker-uid
for name in a b; do openssl rand -hex 32 >"$scratch/proof-$name"; done
if "$client" "$scratch/support" claim "$id" 3 <"$scratch/proof-a"; then exit 1; fi
if "$client" "$scratch/foreign-worker" claim "$id" 3 <"$scratch/proof-a"; then exit 1; fi
if "$client" "$scratch/worker" list OPEN; then exit 1; fi
"$client" "$scratch/worker" list AGENT_QUEUED | jq -e --arg id "$id" '.tickets[0].id == $id'
"$client" "$scratch/worker" claim "$id" 3 <"$scratch/proof-a" >"$scratch/race-a" 2>&1 &
pid_a=$!
"$client" "$scratch/worker" claim "$id" 3 <"$scratch/proof-b" >"$scratch/race-b" 2>&1 &
pid_b=$!
rc_a=0
rc_b=0
wait "$pid_a" || rc_a=$?
wait "$pid_b" || rc_b=$?
[[ $((rc_a + rc_b)) == 1 ]]
winner=a loser=b
if ((rc_a)); then winner=b loser=a; fi
jq -e '.error == "ticket version conflicts with current state"' "$scratch/race-$loser"
jq -e '.version == "4" and .lease_expires_utc and .description != ""' "$scratch/race-$winner"
if "$client" "$scratch/developer" propose-file "$id" 4 "$scratch/manual"; then exit 1; fi
# A fresh process can retry the acknowledged claim using the original proof and version.
"$client" "$scratch/worker" claim "$id" 3 <"$scratch/proof-$winner" | diff "$scratch/race-$winner" -
digest="sha256:$(printf 'demo candidate' | sha256sum | cut -d' ' -f1)"
if "$client" "$scratch/worker" propose "$id" 4 "$digest" <"$scratch/proof-$loser"; then exit 1; fi
"$client" "$scratch/worker" propose "$id" 4 "$digest" <"$scratch/proof-$winner" | \
    jq -e --arg digest "$digest" '.state == "PATCH_PROPOSED" and .version == "5" and .artifact_digest == $digest'
support_listener qa sample "$test_uid" --qa-uid
support_listener foreign-qa unrelated "$test_uid" --qa-uid
dd if=/dev/urandom of="$scratch/candidate" bs=90001 count=1 status=none
printf 'demo candidate' > "$scratch/substitute"
candidate_sha="sha256:$(sha256sum "$scratch/candidate" | cut -d' ' -f1)"
"$4" "$scratch/db" "$scratch/key" seed "$candidate_sha"
qa_id=independent-proposal
if "$client" "$scratch/worker" qa-admit "$qa_id" 4 "$scratch/candidate"; then exit 1; fi
if "$client" "$scratch/foreign-qa" qa-admit "$qa_id" 4 "$scratch/candidate"; then exit 1; fi
if denial=$("$client" "$scratch/qa" qa-admit "$id" 5 "$scratch/substitute" 2>&1); then exit 1; fi
jq -e '.error == "Independent QA requires a current patch proposal"' <<<"$denial"
"$client" "$scratch/qa" list PATCH_PROPOSED | jq -e --arg id "$qa_id" 'any(.tickets[]; .id == $id)'
if denial=$("$client" "$scratch/qa" qa-admit "$qa_id" 4 "$scratch/substitute" 2>&1); then exit 1; fi
jq -e '.error == "candidate bytes do not match the proposed artifact"' <<<"$denial"
ln -s "$scratch/candidate" "$scratch/link"
mkfifo "$scratch/fifo"
for file in link fifo; do
    if "$client" "$scratch/qa" qa-admit "$qa_id" 4 "$scratch/$file"; then exit 1; fi
done
"$client" "$scratch/qa" qa-admit "$qa_id" 4 "$scratch/candidate" | jq -e '.state == "QA_RUNNING" and .version == "5"'
if "$client" "$scratch/qa" qa-admit "$qa_id" 4 "$scratch/candidate"; then exit 1; fi
"$4" "$scratch/db" "$scratch/key" verify "$scratch/candidate"
"$client" "$scratch/qa" qa-checkout "$qa_id" "$scratch/checked-out" | jq -e --arg digest "$candidate_sha" '.artifact_digest == $digest'
cmp "$scratch/candidate" "$scratch/checked-out"
if "$client" "$scratch/qa" qa-checkout "$qa_id" "$scratch/checked-out"; then exit 1; fi
if "$client" "$scratch/worker" qa-pass "$qa_id" 5 "$candidate_sha" <<<"Review complete"; then exit 1; fi
if "$client" "$scratch/qa" qa-pass "$qa_id" 5 "$manual_sha" <<<"Reviewed different file"; then exit 1; fi
"$client" "$scratch/qa" qa-pass "$qa_id" 5 "$candidate_sha" <<<"Independently compared the fixture bytes" | jq -e '.state == "QA_APPROVED"'
support_listener release sample "$test_uid" --release-uid
"$client" "$scratch/release" list QA_APPROVED | jq -e --arg id "$qa_id" 'any(.tickets[]; .id == $id)'
if "$client" "$scratch/release" release-approve "$qa_id" 6 "$candidate_sha" <<<"Same user attempts release"; then exit 1; fi
for (( i=0; i<26; i++ )); do
    "$client" "$scratch/socket" create "Pagination $i" <<< "Sample report" >/dev/null
done
page=$("$client" "$scratch/support" list OPEN)
cursor=$(jq -er 'select((.tickets | length) == 25 and .next_after == .tickets[-1].id) | .next_after' <<< "$page")
"$client" "$scratch/support" list OPEN "$cursor" | jq -e --arg cursor "$cursor" \
    '(.tickets|length) >= 1 and all(.tickets[]; .id > $cursor) and .next_after == ""'
