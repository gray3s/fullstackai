cmake_minimum_required(VERSION 3.22)

project(AIEng VERSION 0.1.0 LANGUAGES CXX)

option(AIENG_ENABLE_SANITIZERS "Enable AddressSanitizer and UndefinedBehaviorSanitizer" OFF)
option(AIENG_ENABLE_HARDENING "Enable supported compiler and linker hardening" ON)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_AUTOMOC ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

include(CTest)
find_package(Qt6 6.4 REQUIRED COMPONENTS Core Sql Test)

add_library(aieng_warnings INTERFACE)
target_compile_options(aieng_warnings INTERFACE
    $<$<CXX_COMPILER_ID:GNU,Clang>:-Wall -Wextra -Wpedantic -Werror -Wconversion -Wsign-conversion>
)

add_library(aieng_security_flags INTERFACE)
if(AIENG_ENABLE_HARDENING)
    target_compile_options(aieng_security_flags INTERFACE
        $<$<CXX_COMPILER_ID:GNU,Clang>:-fstack-protector-strong -fPIC>
    )
    target_compile_definitions(aieng_security_flags INTERFACE
        $<$<CONFIG:Release,RelWithDebInfo>:_FORTIFY_SOURCE=3>
    )
    target_link_options(aieng_security_flags INTERFACE
        $<$<CXX_COMPILER_ID:GNU,Clang>:-Wl,-z,relro -Wl,-z,now -pie>
    )
endif()

if(AIENG_ENABLE_SANITIZERS)
    target_compile_options(aieng_security_flags INTERFACE
        $<$<CXX_COMPILER_ID:GNU,Clang>:-fno-omit-frame-pointer -fsanitize=address,undefined>
    )
    target_link_options(aieng_security_flags INTERFACE
        $<$<CXX_COMPILER_ID:GNU,Clang>:-fsanitize=address,undefined>
    )
endif()

add_subdirectory(libs/domain)
add_subdirectory(libs/application)
add_subdirectory(apps/control-plane)

if(BUILD_TESTING)
    add_subdirectory(tests/domain)
    add_subdirectory(tests/application)
endif()

