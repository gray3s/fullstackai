# Carton Count | observed rehearsal

Executed on Ubuntu on 19 November 2026 using the Rev 0.1 release client and service. All four release CTest suites passed before replay.
The ticket ID was `40dad2b7-54df-4f11-8210-37a5e30a50f1`. Ticket versions advanced from 1 (OPEN) to 2 (TRIAGED) to 3 (AGENT_QUEUED).

The candidate returned 0, 1, 2 and 3 cartons for 0, 1, 24 and 25 items at capacity 12. At capacity 3 it returned 333333334 cartons for
one billion items. Zero capacity, negative quantity and malformed quantity returned exit code 2. The fixture refused the original artifact
when given the candidate digest, then activated the candidate, restored the original and activated the candidate again.

| Object | Observed SHA-256 |
| --- | --- |
| QA binary and final active executable | `353ad9e63ae59ac0deee6d58008756ce13478a0709e874db26ba2a5b325cbf9c` |
| Original and rollback executable | `2b53fbbc8a8071a772da63117391c2c0d6e6f4ce1b2de2419cf654c216473033` |

All deployment operations used a disposable local production directory. The release receipt labels the approval as a fixture.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
