// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "Questions.h"
#include <QFile>
#include <QStringList>

QString intake::questions(const QString &role)
{
    QFile source(QStringLiteral(":/aieng/STAKEHOLDER_QUESTIONS.md"));
    if (!source.open(QIODevice::ReadOnly)) return {};
    const auto contents = QString::fromUtf8(source.readAll());
    if (role == "all") return contents;
    QStringList roles;
    for (const auto &section : contents.split(QStringLiteral("\n## ")).mid(1)) {
        const auto name = section.section(' ', 0, 0);
        if (name == role) return section.trimmed() + '\n';
        roles << name;
    }
    return role.isEmpty() ? QStringLiteral("Stakeholder question lists: ") + roles.join(", ") + "\n" : QString{};
}
