#!/usr/bin/env bash
# Copyright © 2026 Samuel A. Gray III. All rights reserved.
set -euo pipefail
umask 077
client=$1 service=$2 fixture=$3
retention=${4:-}
example=$(cd "$(dirname "$0")/../misc/rev-0.1/carton-count" && pwd)
run=$(mktemp -d)
listeners=()
cleanup() {
    local status=$?
    for pid in "${listeners[@]}"; do
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
    done
    if ((status == 0)) && [[ $retention != --keep ]]; then
        rm -rf -- "$run"
    else
        echo "Retained local delivery evidence in $run"
    fi
}
trap cleanup EXIT
mkdir "$run/work" "$run/qa" "$run/releases" "$run/evidence"
openssl rand -out "$run/key" 32
listener() {
    systemd-socket-activate --seqpacket --accept --inetd -l "$run/$1.sock" \
        "$service" "$run/db" "$run/key" sample "--$1-uid" "$(id -u)" >>"$run/service.log" 2>&1 &
    local pid=$!
    listeners+=("$pid")
    for ((i=0;i<100;i++)); do
        [[ -S "$run/$1.sock" ]] && return 0
        kill -0 "$pid"
        sleep 0.03
    done
    return 1
}
ticket() {
    local role=$1
    shift
    "$client" "$run/$role.sock" "$@"
}
digest() { sha256sum "$1" | cut -d' ' -f1; }
activate() {
    ln -s "releases/$1" "$run/next" || return 1
    mv -Tf "$run/next" "$run/current"
}
install_and_check() {
    local release=$1 expected=$2 previous observed
    previous=$(readlink "$run/current") || return 1
    [[ $(digest "$run/releases/$release") == "$release" ]] || return 1
    activate "$release" || return 1
    if observed=$("$run/current" 25 12) && [[ $observed == "$expected" ]]; then
        echo "installed $release returned $observed" >>"$run/evidence/health.txt"
        return 0
    fi
    activate "${previous#releases/}" || return 2
    echo "health check expected $expected, observed $observed, restored $previous" >>"$run/evidence/health.txt"
    return 1
}
compile() { c++ -std=c++20 -O2 -Wall -Wextra -Werror "$1" -o "$2"; }

for role in support qa operator; do listener "$role"; done
compile "$example/cartons.cpp" "$run/releases/original"
activate original
[[ $("$run/current" 25 12) == 2 ]]
ticket support create "Count a partial carton" <<<"25 items at 12 per carton require three cartons." >"$run/evidence/open.json"
id=$(jq -er '.id' "$run/evidence/open.json")
ticket support triage "$id" 1 <<<"Reproduced the missing carton" >/dev/null
ticket support queue "$id" 2 <<<"Repair the rounding error" >/dev/null
cp "$example/cartons.cpp" "$run/work/"
patch --batch --fuzz=0 -d "$run/work" -p1 < "$example/partial-carton.patch"
compile "$run/work/cartons.cpp" "$run/work/candidate"
sha=$(digest "$run/work/candidate")
"$fixture" "$run/db" "$run/key" propose "$id" "sha256:$sha"
if ticket qa qa-admit "$id" 4 "$run/releases/original"; then exit 1; fi
ticket qa qa-admit "$id" 4 "$run/work/candidate" >"$run/evidence/admitted.json"
ticket qa qa-checkout "$id" "$run/qa/cartons" >"$run/evidence/checkout.json"
if ticket operator deploy-fetch "$id" "$run/too-early"; then exit 1; fi
chmod 0500 "$run/qa/cartons"
for spec in '0 12 0' '1 12 1' '24 12 2' '25 12 3' '1000000000 3 333333334'; do
    read -r items capacity expected <<<"$spec"
    observed=$("$run/qa/cartons" "$items" "$capacity")
    [[ $observed == "$expected" ]]
    echo "$items $capacity -> $observed" >>"$run/evidence/qa.txt"
done
rc=0
"$run/qa/cartons" 1 0 >/dev/null 2>&1 || rc=$?
[[ $rc == 2 ]]
echo "1 0 -> rejected with exit $rc" >>"$run/evidence/qa.txt"
qa_log=$(digest "$run/evidence/qa.txt")
ticket qa qa-pass "$id" 5 "sha256:$sha" <<<"Five quantity checks passed, zero capacity rejected. QA log sha256:$qa_log" >"$run/evidence/qa.json"
"$fixture" "$run/db" "$run/key" release "$id" "sha256:$sha"
ticket operator deploy-start "$id" 7 "sha256:$sha" <<<"Install into disposable local carton target" >"$run/evidence/deploying.json"
ticket operator deploy-fetch "$id" "$run/releases/$sha" >"$run/evidence/fetched.json"
[[ $(digest "$run/releases/$sha") == "$sha" ]]
chmod 0500 "$run/releases/$sha"
# Inject a failing health expectation into the same install path used for a successful rollout.
rc=0
install_and_check "$sha" 99 || rc=$?
[[ $rc == 1 ]]
[[ $(readlink "$run/current") == releases/original && $("$run/current" 25 12) == 2 ]]
install_and_check "$sha" 3
[[ $(digest "$run/current") == "$sha" && $("$run/current" 25 12) == 3 ]]
ticket operator deploy-confirm "$id" 8 "sha256:$sha" <<<"Installed smoke test passed after rollback and restore drill" >"$run/evidence/deployed.json"
jq -e --arg digest "sha256:$sha" '.state == "DEPLOYED" and .version == "9" and .artifact_digest == $digest' "$run/evidence/deployed.json"
jq -n --arg id "$id" --arg digest "sha256:$sha" --arg previous "sha256:$(digest "$run/releases/original")" \
    '{ticket:$id,target:"disposable local directory",state:"DEPLOYED",active_digest:$digest,previous_digest:$previous,
      before:2,installed:3,rollback:2,restored:3,substitution_rejected:true,early_fetch_rejected:true,
      developer_and_release:"test principals",qa_and_operator:"local Unix UID",runtime_model:false}' | tee "$run/evidence/result.json"
