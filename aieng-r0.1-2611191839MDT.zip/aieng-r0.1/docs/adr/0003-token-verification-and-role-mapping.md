# ADR 0003: Separate token verification from role mapping

- Status: accepted architecture; verifier dependency unresolved
- Date: 2026-11-19
- Decision owner: Samuel A. Gray III

## Decision

AIEng will not implement JWT/JWS/JWK parsing or cryptography itself. A qualified
native verification adapter must reject malformed and duplicate JSON members,
enforce an explicit access-token type and algorithm allowlist, resolve only
trusted issuer keys, validate the signature and sender proof, and then emit
structured `CryptographicallyVerifiedClaims`.

A separate deterministic `IdentityPolicy` validates exact issuer and resource
audience, bounded subject/group claims, issued/not-before/expiry times, maximum
token lifetime, configured group-to-role mappings, sender constraint, and
recent step-up authentication for QA, release, operator, and administrator
roles. Only an accepted decision creates an `AuthenticatedPrincipal`.

Group names never become roles by string similarity. Unknown groups are
ignored; an identity with no exact configured mapping is rejected. Privileged
role tokens require the exact configured authentication-context value and a
fresh authentication time. Production policy requires sender-constrained
proof; a replayable bearer token is insufficient.

## Security boundary

The structured claims type is an internal adapter contract, not proof by
itself. Only the admitted verifier may populate it in a running service. Unit
tests construct it directly solely to exercise deterministic policy. Future
process/module boundaries must keep raw token bytes and verified claims out of
untrusted plugin and model contexts.

## Verifier admission gate

Before a native JWT/OIDC dependency is admitted, record and pass:

1. exact version, source/package digest, license, maintainership, security
   response process, transitive dependencies, SBOM, and vulnerability scan;
2. RFC 8725 algorithm-confusion, explicit-typing, cross-JWT substitution,
   issuer, audience, key-selection, malformed key, and duplicate-member tests;
3. JWK retrieval allowlist, TLS validation, response-size/time/cache ceilings,
   rotation overlap, unknown-key refresh throttling, and stale-key fail-closed
   tests;
4. RFC 9449 DPoP method/URI/access-token-hash/key/nonce/time/replay validation;
5. corpus/fuzz, ASan, UBSan, LeakSanitizer, and resource-exhaustion evidence in
   the disposable qualification VM; and
6. proof that ID tokens, access tokens, DPoP proofs, service credentials, and
   agent workload identities use mutually exclusive validation profiles.

Ubuntu 24.04 offers `libjwt`, `jose`, `liboauth2`, and `cjose` development
packages, but package presence is not approval. None is installed or selected
by this decision.

## Primary evidence

- https://www.rfc-editor.org/rfc/rfc8725.html
- https://www.rfc-editor.org/rfc/rfc9700.html
- https://www.rfc-editor.org/rfc/rfc9449.html
- https://openid.net/specs/openid-connect-core-1_0-final.html

Copyright © 2026 Samuel A. Gray III. All rights reserved.
