# AIEng stakeholder interviews

One person can answer for several roles in a small team. Record which role they are speaking for, the source of each constraint and
who has authority to change it. Invite affected specialists as needed. This is a question bank; use the questions relevant to the
current decision and return to the owner when evidence is missing.

## developer — Creator or vibecoder
- What algorithm do you want developed into code, and what purpose should it serve?
- What are its inputs, prior state, outputs and transfer functions? Which part needs further decomposition?
- Give one example and one observation that would show the result is wrong.
- Which implementation ideas do you want preserved? Which design or testing choices do you delegate?

## user — Intended user or domain expert
- In what real situation would you use the result, and what action would you take?
- Which unusual case is easy for a developer to misunderstand? Who decides the correct outcome?
- What user-visible failure would make the system unusable, and what held-back example would expose it?

## product — Product or business owner
- What outcome matters, to whom, and how will we tell it was achieved?
- What is mandatory for this release? What can be delayed, and at what cost?
- Who owns ambiguous business rules and who can accept a change of scope?

## engineering — Implementer or maintainer
- What is the smallest independently testable behavior? What are its dependencies and interfaces?
- Which hardware, toolchain, licenses or protocols constrain the design, and who selected them?
- Which alternatives are feasible? What measurement would change your recommendation?

## qa — Independent QA
- For each requirement, where does its expected result come from?
- Which normal, boundary, invalid and recovery cases distinguish a correct implementation from a plausible faulty one?
- What would count as failure, insufficient evidence or a successful retest on these exact bytes?

## security — Security and privacy owner
- Which assets, data and privileges does the change introduce? What access is intended?
- What should be denied? Which configuration, dependency or authorization check would demonstrate that boundary?
- Which constraints are mandatory policy? Who can interpret them and where do unresolved findings go?

## operations — Platform operator or IT
- Which target and workload do you operate, and what already fails before the change?
- What capacity, change window and recovery time are actually available? Can versions coexist?
- What will you measure from the installed path? Who can stop rollout and restore service or data?

## release — Accountable release authority
- Which named target and exact artifact are you authorizing, subject to which policy?
- Which evidence establishes readiness? Which risks remain and who owns them?
- When should authorization expire or the decision be sent back? Who can grant any relevant exception?

## support — Service or incident owner
- Who receives reports after rollout and how can they identify the affected release?
- What symptoms trigger escalation, mitigation or rollback? Who is on call?
- How will an observed incident become a reproducible regression case?

## conflict — Secondary interview for a disputed decision
1. Which decision and which requirement IDs conflict? Are the parties talking about the same target, workload and time window?
2. What harm is each person trying to prevent? Which constraints are binding policy, and which are preferences?
3. What source or measurement would distinguish a factual disagreement from a genuine trade-off? Who can obtain it?
4. Can we split scope, sequence the work or introduce another option that meets both requirements? What would that cost each side?
5. Who has delegated authority over this decision? Does changing a constraint require a different owner's approval?
6. Which option did the accountable owner select, for what reason, and which concerns remain? Record dissent and relevant references.
7. What test will show the decision worked for each affected stakeholder? Who acts if that test fails?
