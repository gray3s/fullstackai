# Support queue discovery

Project support can list open, triaged and agent-queued work orders over the local service. Each page includes up to 25 ticket IDs, versions
and summaries. The repository verifies row integrity before constructing the page. Pages reflect committed state at each query.

All four suites passed in debug, ASan/UBSan and hardened release. Tests exercised multiple pages, a second project against the same
database, reporter denial and corruption rejection. Release hardening and the no-Python audit passed.

The Rev 0.1 design review can use this baseline. Exclusive worker claims, patch generation, independent QA and production promotion remain
implementation work. DTA/DTE is on the future-revision roadmap.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
