// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once
#include <QWidget>

class StaffForm final : public QWidget {
public:
    explicit StaffForm(const QString &socket);
};
