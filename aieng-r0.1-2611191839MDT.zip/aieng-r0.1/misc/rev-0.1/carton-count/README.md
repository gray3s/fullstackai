# Carton Count | from a warehouse request to a running release

**The request.** “Tell me how many cartons to set aside. We pack 12 items per carton. Yesterday we had 25 items and ran out of boxes.”
The warehouse clerk owns the expected behavior. The agreed rule is one carton per full or partial group. An empty order needs zero.
The example uses synthetic quantities and has no customer records.

**Prompt set for a vibecoder**

1. “Build a small Ubuntu tool for packing one order. Tell me how many cartons to reserve for the item count and capacity I enter.”
2. “One order ships alone. Reserve a carton for any remainder. Show me what happens with 0, 24 and 25 items at 12 per carton.”
3. “Reject invalid quantities. Give support a reproducible ticket, test the smallest fix and show me the executable that passed.”
4. “Rehearse deploying those exact bytes. Run my 25-item example in production, restore the old version, then put the fix back.”

**Replay on Ubuntu.** Unzip the review bundle and enter its top-level directory. Use a local user account with private Unix socket access.
Dependencies include GCC with C++20, CMake 3.28+, Ninja, Qt 6 Core/Sql/Test/Widgets with QSQLITE and the offscreen plugin, Bash, systemd's
socket activation utility, jq, OpenSSL CLI, patch, ripgrep, binutils and GNU coreutils. On the reviewed host Ubuntu supplies these tools.

```bash
bash scripts/release-check.sh
bash misc/rev-0.1/carton-count/rehearse.sh
```

**What to look for.** The script first runs the original executable. It passes “24 at 12” and undercounts “25 at 12.” It files that defect
through AIEng, triages it, and queues it. Three JSON responses preserve the ID and ticket versions. In this local test, one Unix user fills
the reporter and support roles. AIEng's last persisted ticket state is AGENT_QUEUED.

The script then applies the supplied one-line candidate patch in a disposable work directory. It compiles the candidate once, checks five
valid cases and three invalid inputs, and records the QA binary's SHA-256. It deliberately submits the old binary for promotion. After the
digest check refuses that file, it installs the tested candidate and switches the active production link. It runs the clerk's acceptance
case there, rolls back to the previous binary, repeats the original observation, then restores the candidate and verifies three cartons.

**Inspect the result.** Use the directory printed by the script. Run `prod/current 25 12` from that directory. Inspect
`evidence/release.json` and compare `sha256sum qa/cartons prod/current`. Each run creates a fresh private directory and retains the
database and temporary audit key there. Keep that directory local. The ZIP contains source and a sanitized run record.

**Production handoff.** The production target here is a real executable in a temporary local directory. Patch authorship, approval and
promotion after queuing are rehearsal steps. Corporate use needs a sandboxed worker, independent QA and release identities, signed
provenance and an environment-scoped deployment runner. The design review assigns acceptance tests to those gaps.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
