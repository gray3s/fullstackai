# Ubuntu 26.04 Disposable Qualification VM Plan

**Recorded:** 2026-11-19 12:50 MST  
**Owner:** Samuel A. Gray III  
**Status:** planned; host prerequisites not authorized or satisfied

## Purpose

This disposable guest is an evidence runner for AIEng's untrusted native
dependencies and hostile fixtures. It is not a production topology and is not
a substitute for later independent QA infrastructure.

Initial subjects are:

- the proposed Drogon control-API transport under ADR 0002;
- a native JOSE/OAuth verifier under ADR 0003;
- LeakSanitizer outside the current ptrace environment;
- malformed HTTP/token corpora and bounded resource-exhaustion tests; and
- AppArmor/libvirt isolation evidence for hostile build-runner design.

## Read-only host inventory

Observed on 2026-11-19 without changing the host:

- CPU: Intel Core i3-N305, 8 physical cores, VT-x/VMX exposed.
- Kernel modules: `kvm` and `kvm_intel` loaded.
- `/dev/kvm`: not visible to this session; hardware acceleration is therefore
  not usable until the device/access boundary is deliberately resolved.
- QEMU, libvirt/virsh, virt-install, Podman, and Docker: not found in `PATH`.
- Memory: 7.4 GiB total, approximately 1.2 GiB available at observation time;
  insufficient headroom for the proposed guest without first reducing host
  pressure.
- System-drive free space: approximately 52 GiB.
- Lexar CarCase mirror: 3.1 GiB free, mounted `ro,nosuid,nodev`; prohibited for
  VM disks, images, caches, build trees, or swap changes.

No package, group, device permission, service, mount, firewall, or VM was
changed during this inventory.

## Required authorization gate

Before provisioning, obtain explicit approval for the exact host changes:

1. install the selected Ubuntu-supported QEMU/libvirt packages;
2. expose `/dev/kvm` through the current execution boundary and grant the
   minimum operator authorization without broad ambient group access;
3. start only the required libvirt daemons/sockets;
4. allocate a system-drive-only VM directory with a hard quota; and
5. create the isolated libvirt network and firewall rules.

Recheck the CarCase Lexar backup immediately before any package/storage action
that could risk shared system state. Do not repartition, remount read-write, or
consume `/dev/sdb1` or `/dev/sdb2`.

## Guest envelope

- Ubuntu Server 26.04 LTS AMD64 minimal image, exact download URL and SHA-256
  recorded from Canonical before use.
- 4 vCPU, 4 GiB RAM only when the host has at least 5 GiB genuinely available;
  otherwise postpone rather than swap-thrash the workstation.
- 24 GiB maximum sparse qcow2 on the system drive, with an independently
  checked free-space floor of 20 GiB after allocation.
- UEFI, secure boot when supported by the packaged stack, no device passthrough,
  no USB, audio, clipboard, display sharing, or host directory sharing.
- libvirt NAT with deny-by-default guest ingress. Qualification phases use
  either no network or an explicit destination allowlist.
- Unique unprivileged guest identities; no host credentials, SSH agent,
  corporate secrets, production data, or CarCase content.
- AppArmor sVirt enforcing with a unique per-guest profile. Never set the
  libvirt QEMU security driver to `none`.
- Fixed CPU/memory/process/disk/network ceilings and a wall-clock destroy
  timeout for hostile cases.

## Snapshot and evidence sequence

1. `S0-clean-install`: verified Canonical image, package manifest, clock, kernel,
   firmware, guest-agent state, and no project material.
2. `S1-build-baseline`: pinned compiler/CMake/Qt/OpenSSL packages and hashes;
   no candidate framework.
3. `S2-candidate`: one exact candidate plus transitive dependency/SBOM/license
   inventory. Never mix transport and JOSE qualification in one snapshot.
4. Run deterministic build/tests, ASan, UBSan, LeakSanitizer, fuzz corpus,
   malformed-input corpus, load/resource ceilings, and confinement escapes.
5. Export logs, commands, exit status, environment manifest, and artifact
   digests to a new evidence bundle; the guest never signs its own claims.
6. Revert to `S1` between candidates. Destroy the guest after evidence export
   and independently verify the bundle.

Snapshots are convenience rollback points, not backups or proof. Evidence must
be content-addressed outside the guest, and a separate trusted verifier must
recheck it.

## Stop conditions

Stop immediately on host swapping/resource starvation, missing sVirt
confinement, unexpected host mounts/devices, unrestricted guest egress,
unverified image digest, test escape, evidence ambiguity, or system-drive free
space below the floor. Preserve logs and do not weaken the control to obtain a
passing result.

## Primary sources

- https://documentation.ubuntu.com/release-notes/26.04/summary-for-lts-users/
- https://documentation.ubuntu.com/security/security-features/privilege-restriction/apparmor/
- https://documentation.ubuntu.com/security/security-features/platform-protections/cpu/
- https://libvirt.org/drvqemu

Copyright © 2026 Samuel A. Gray III. All rights reserved.
