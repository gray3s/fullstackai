# What engineering work makes a vibecoded release production-ready?

AIEng specification discussion · 2026-11-20 06:57 MST · Original reply

AIEng’s first design question should be **“What work does this particular release need, and what evidence would show that the work was done competently?”** If we define an engineer as a human, the experiment is decided by vocabulary. If we assume that every vibecoded project needs correction, we have also decided in advance what the engineer must find. Sometimes the sound engineering conclusion will be “ship it as built.” Sometimes it will be “we don’t know enough to decide.”

I wrote a [first-pass working glossary for AIEng](/home/sag/aieng/docs/WORKING_DEFINITIONS.md). These are the definitions I would build the experiment around.

| Term | Working definition |
|---|---|
| **Vibecoded project** | A project whose creator directs implementation principally through natural-language interaction with a code-generating model and steers it through feedback. This describes how the project originated. Its quality is measured separately. |
| **Engineering work** | Turning an intended use into checkable requirements, identifying consequential ways the system could fail, gathering evidence, and deciding what to change or justify leaving alone. A human, an AI, or a team can attempt this work. |
| **Production** | An environment where a person or downstream process relies on the software for an actual task. Last night’s Carton Count run demonstrated installation and rollback. A warehouse relying on its answer to pack an order would establish production use. |
| **Production-ready** | A particular release has sufficient evidence to meet the agreed criteria for a named use on a named target. Readiness, permission to deploy, actual installation, and successful operation are four distinct claims. |
| **Bug-free** | Every behavior within a stated domain satisfies the applicable requirements under stated execution assumptions. One valid counterexample refutes that claim. Passing six tests establishes what happened in those six tests. |
| **Secure** | A meaningful security claim names the asset, the protection it requires, the relevant threat, and the operating assumptions. “Only a designated release identity can authorize this artifact for this target” is specific enough to examine. [NIST information security](https://csrc.nist.gov/glossary/term/information_security) |
| **Verification and validation** | Verification asks whether the implementation meets its specified requirements. Validation asks whether the resulting system meets the intended need in its operating context. [NIST verification](https://csrc.nist.gov/glossary/term/verification) · [NIST validation](https://csrc.nist.gov/glossary/term/validation) |
| **Without human intervention** | Between a declared start and finish, the worker completes the assigned judgment and actions without human assistance. Record who set the rules beforehand, who intervened during the run, and who graded it afterward. Last night’s manual repair of the worker’s malformed output counts as assistance for the diagnostic replay. |

**Can a machine answer these questions definitively?** Some of them, yes. For 25 items at a capacity of 12, an answer of two cartons definitively violates the requirement to accommodate every item. An AI can establish that independently. Whether *two separate six-item orders* may share one carton is a different question. Either answer can be correct under a different shipping policy. If the policy is silent, the technically competent verdict is **undetermined**. A human engineer has the same limitation.

Your before-and-after point adds a requirement that testing the application alone misses. **AIEng must evaluate the application, the existing platform, and the combined deployed system.** Before installation, record existing failures, workload, access permissions, and the changes the installation is expected to make. Afterward, repeat comparable checks and exercise the new service. That lets us distinguish three findings with different consequences:

- An existing service failed at the same rate before and after deployment. The defect may still matter, but the baseline supplies evidence that it predates this release.
- An account gained access after installation. The agreed access policy determines whether that change was required or constitutes a security regression.
- The failure rate rose after deployment. That establishes an observed difference. Reproduction under comparable load or reversal after rollback strengthens the case that deployment caused it.

I would qualify one part of the industry critique. A release owner can have the **authority to accept a risk**. That authority cannot make an incorrect carton count correct. The real concentration of power occurs when one party writes the acceptance rule, chooses every test, interprets the results, and declares success. Giving all four powers to an AI would reproduce the same problem.

That yields a concrete first design goal for AIEng: **give human and AI workers the same intended use, platform baseline, and resources. Let each choose its tests and reach a verdict. Have an independent evaluator check both against held-back cases and the observed post-deployment state.** Then we can ask where human intervention actually changed the outcome. That is an empirical question AIEng can answer.
