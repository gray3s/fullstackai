# AIEng Project Scope and Ticket Row Integrity Checkpoint

**Recorded:** 2026-11-19 12:47 MST  
**Owner:** Samuel A. Gray III  
**Window report:** 35% remaining before this bounded increment

## Preserved result

- Every authenticated project role is now keyed by an exact project ID.
- Ticket creation requires the reporter role in the target project.
- Ticket transitions derive actor roles from the integrity-verified ticket's
  project; a support role in another project is denied.
- Platform roles are stored separately and do not automatically confer any
  workflow approval role.
- Identity-provider group mappings now produce explicit project-role grants.
- Ticket schema version 2 adds an immutable project ID and a current-row
  HMAC-SHA-256 tag over ticket ID, project, workflow state/version, reporter,
  patch author, QA approver, release approver, and artifact digest.
- Every ticket load verifies the tag before the row can drive authorization or
  mutation. Constant-length MAC comparison avoids content-dependent early exit.
- Audit creation now records the project ID as part of the chained event.
- Unsupported/incomplete legacy schemas fail closed and demand an explicit
  offline migration; no unverified state is silently upgraded.

## Verification evidence

- Strict debug build and all three CTest targets passed.
- 52 QtTest phases passed locally, including new cross-project denial, current
  row tampering, and legacy-schema fail-closed tests.
- Direct modification of `project_id` makes both read and transition fail with
  `ticket integrity verification failed`; no audit event is appended.
- No-Python checks and `git diff --check` passed before the full gate run.
- ASan/UBSan and hardened release results are recorded by the commands run
  immediately before this checkpoint commit; LeakSanitizer remains explicitly
  pending outside ptrace.
- No package, VM, listener, CarCase file, Lexar partition, or external system
  was changed.

## Honest current state

The HMAC protects against undetected database-row modification by an actor who
does not possess the application key. It is not a substitute for PostgreSQL
permissions, off-host append-only audit export, key custody/rotation, backup,
or reconciliation. An application-process compromise that can read the HMAC
key remains in the threat model and requires the later secrets/confinement
architecture.

## Next authorized action

Stop expanding scope until the next checkpoint is confirmed. Then design the
schema-v2-to-PostgreSQL repository port and key-custody interface, preserving
project scope and row/audit integrity without embedding secrets in databases or
configuration files.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

