// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/AuditChain.h"

#include <QMessageAuthenticationCode>

namespace aieng::domain {
namespace {

void appendField(QByteArray &body, const QByteArray &value)
{
    body.append(QByteArray::number(value.size()));
    body.append(':');
    body.append(value);
}

[[nodiscard]] QByteArray bodyFor(const AuditEvent &event)
{
    QByteArray body;
    appendField(body, QByteArray::number(event.sequence));
    appendField(body, event.eventId.toUtf8());
    appendField(body, event.occurredAtUtc.toUtf8());
    appendField(body, event.actorId.toUtf8());
    appendField(body, event.action.toUtf8());
    appendField(body, event.objectType.toUtf8());
    appendField(body, event.objectId.toUtf8());
    appendField(body, event.canonicalPayload);
    appendField(body, event.previousMacHex);
    return body;
}

[[nodiscard]] QByteArray macFor(const AuditEvent &event, const QByteArray &secret)
{
    return QMessageAuthenticationCode::hash(bodyFor(event), secret, QCryptographicHash::Sha256)
        .toHex();
}

} // namespace

AuditChain::AuditChain(QByteArray secret)
    : m_secret(std::move(secret))
{
}

AuditEvent AuditChain::append(
    const QString &eventId,
    const QString &occurredAtUtc,
    const QString &actorId,
    const QString &action,
    const QString &objectType,
    const QString &objectId,
    const QByteArray &canonicalPayload)
{
    AuditEvent event;
    event.sequence = static_cast<quint64>(m_events.size()) + 1U;
    event.eventId = eventId;
    event.occurredAtUtc = occurredAtUtc;
    event.actorId = actorId;
    event.action = action;
    event.objectType = objectType;
    event.objectId = objectId;
    event.canonicalPayload = canonicalPayload;
    event.previousMacHex = m_events.isEmpty() ? QByteArray(64, '0') : m_events.constLast().macHex;
    event.macHex = macFor(event, m_secret);
    m_events.append(event);
    return event;
}

bool AuditChain::verify() const
{
    return verify(m_events, m_secret);
}

bool AuditChain::verify(const QList<AuditEvent> &events, const QByteArray &secret)
{
    QByteArray previous(64, '0');
    quint64 expectedSequence = 1;
    for (const auto &event : events) {
        if (event.sequence != expectedSequence || event.previousMacHex != previous
            || event.macHex != macFor(event, secret)) {
            return false;
        }
        previous = event.macHex;
        ++expectedSequence;
    }
    return true;
}

} // namespace aieng::domain

