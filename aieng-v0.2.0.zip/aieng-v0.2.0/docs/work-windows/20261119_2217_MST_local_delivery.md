# Deliver Carton Count to a local target

From 84bcf03, demonstrate one repair from a business acceptance test to a running local installation. Use the published Carton Count
source and correction. Put the authenticated QA candidate back into a reviewer's hands. Exercise the same native application policy
with separate test identities for developer, QA, release and operations. Verify the reviewer's bytes when reopened from SQLite.

Use a fresh temporary deployment directory, retain the previous executable, and activate by atomic rename. Show a mismatched executable
being refused. Run the installed command before declaring success. Exercise rollback by observing the old behavior and restore the fix.
Record what ran, the digest and the limitations of the simulation. The operator owns the host and deployment directory. No external
deployment, model integration or certification exercise is part of this checkpoint.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
