# AIEng Product Requirements

## Product promise

Each release must declare its operating model and verify an operational path
with optional AI features disabled. Use the [version operating model](VERSION_OPERATING_MODEL.md)
to record the default, fallback, decision owners and demonstrated scope.

AIEng lets a novice “vibe coder” express software intent and iterate quickly
while automatically supplying the engineering, IT operations, security, QA,
and release discipline an experienced CTO would require before production.

The user may be inexperienced. The platform must not be careless, deceptive,
or silently permissive.

## Primary persona: guided creator

The guided creator can describe desired behavior and evaluate whether a result
meets their business need, but may not understand source control, architecture,
testing, identity, secrets, dependency risk, deployment, monitoring, backup, or
incident response. AIEng therefore:

- asks business-impact questions in plain language;
- converts intent into linked requirements, risks, tasks, and acceptance tests;
- explains consequential choices without forcing jargon;
- selects reversible, least-privilege, secure defaults;
- creates a source-controlled branch and never edits production directly;
- generates implementation and self-QA together, not tests as an afterthought;
- previews in an isolated environment with synthetic data;
- reports readiness as evidence and remaining work, not an AI confidence score;
- blocks unsafe promotion and provides actionable remediation;
- requires attributable human QA and separate release approval;
- deploys an immutable approved artifact with monitoring and tested rollback.

## Guided production path

1. **Describe:** capture goal, users, data sensitivity, business criticality,
   expected behavior, and explicit non-goals.
2. **Plan:** show proposed architecture, threat model, dependencies, cost/risk,
   acceptance tests, and rollback approach for confirmation.
3. **Build:** work only in an isolated branch/workspace through deterministic
   tool adapters; no model text is executed as a shell command.
4. **Self-QA and self-secure:** compile, test, analyze, fuzz where applicable,
   scan secrets/dependencies, generate SBOM/provenance, and remediate failures.
5. **Preview:** deploy the immutable candidate to an isolated QA environment;
   guide the creator through business acceptance scenarios.
6. **Independent QA:** a qualified human reviews the exact artifact and evidence.
7. **Release approval:** a distinct authorized human approves the exact digest,
   environment, time window, migration, monitoring, and rollback plan.
8. **Deploy and observe:** controlled rollout, health/SLO checks, audit records,
   and automatic stop/rollback recommendation on failed guardrails.
9. **Operate:** vulnerability intake, patching, backups, restore drills, incident
   response, ownership, support tickets, and end-of-life management.

## Readiness contract

The UI presents five evidence-backed states:

- `IDEA`: intent is incomplete; nothing executable is trusted.
- `DEVELOPMENT`: isolated work exists; it is not production eligible.
- `CANDIDATE`: deterministic mandatory gates pass for an immutable digest.
- `QA_APPROVED`: independent QA approved that digest in a named QA environment.
- `RELEASE_APPROVED`: a different authority approved deployment of that digest.

No “100% secure,” “guaranteed safe,” or model-confidence language is permitted.
Every green state links to reproducible evidence; every exception names an
owner, scope, reason, expiry, and compensating control.

## CTO safety defaults

- Passkeys/MFA for privileged users; short-lived workload identity.
- Deny-by-default authorization and environment/network segmentation.
- No production secrets or customer data in prompts, tickets, builds, or QA.
- Pinned dependencies, verified sources, license/vulnerability policy.
- Protected branches, signed commits/releases where policy requires them.
- Clean reproducible builds, immutable artifacts, SBOM, provenance, signature.
- Synthetic/redacted QA data and no QA-to-production credential reuse.
- Progressive delivery, health gates, observability, backup, restore, rollback.
- Complete attributable audit evidence exported outside the primary host.

## Accessibility and learning

Safety controls explain what they protect and how to resolve a block. AIEng
offers an advanced evidence view without making expertise a prerequisite for
the guided path. Destructive/irreversible actions use clear consequences,
specific targets, reviewable diffs, and explicit confirmation. Accessibility
and keyboard navigation are release requirements, not optional polish.

## Acceptance journey

A first-time user must be able to describe a small C++, Qt 6, or C# application,
receive a reviewable plan, create and test it, inspect an isolated preview, file
and resolve a defect, and assemble a release candidate without learning the
internal toolchain. They must be unable to bypass mandatory security/QA gates,
expose a secret to the model, approve the AI's patch as the AI, or deploy an
unapproved digest—even if a prompt or repository instructs the agent to do so.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

