add_executable(aieng-ticket client.cpp DesignIntake.cpp)
target_link_libraries(aieng-ticket PRIVATE aieng_domain aieng_warnings aieng_security_flags)
add_executable(aieng-ticket-service service.cpp)
target_link_libraries(aieng-ticket-service PRIVATE aieng_application aieng_warnings aieng_security_flags)
find_package(Qt6 6.4 REQUIRED COMPONENTS Widgets)
add_executable(aieng-staff staff.cpp StaffForm.cpp)
target_link_libraries(aieng-staff PRIVATE Qt6::Widgets aieng_warnings aieng_security_flags)
add_dependencies(aieng-staff aieng-ticket)
install(TARGETS aieng-ticket aieng-ticket-service aieng-staff RUNTIME DESTINATION bin)
if(BUILD_TESTING)
    add_executable(aieng-qa-fixture ${PROJECT_SOURCE_DIR}/tests/qa_fixture.cpp)
    target_link_libraries(aieng-qa-fixture PRIVATE aieng_application aieng_warnings aieng_security_flags)
    add_executable(aieng-staff-test ${PROJECT_SOURCE_DIR}/tests/staff_form.cpp StaffForm.cpp)
    target_include_directories(aieng-staff-test PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    target_link_libraries(aieng-staff-test PRIVATE Qt6::Widgets Qt6::Test aieng_warnings aieng_security_flags)
    add_test(NAME aieng.intake_socket COMMAND bash
        ${PROJECT_SOURCE_DIR}/tests/intake_socket.sh
        $<TARGET_FILE:aieng-ticket> $<TARGET_FILE:aieng-ticket-service> $<TARGET_FILE:aieng-staff-test> $<TARGET_FILE:aieng-qa-fixture>)
    set_tests_properties(aieng.intake_socket PROPERTIES TIMEOUT 30)
    add_test(NAME aieng.carton_delivery COMMAND bash
        ${PROJECT_SOURCE_DIR}/tests/carton_delivery.sh
        $<TARGET_FILE:aieng-ticket> $<TARGET_FILE:aieng-ticket-service> $<TARGET_FILE:aieng-qa-fixture>)
    set_tests_properties(aieng.carton_delivery PROPERTIES TIMEOUT 45)
endif()
