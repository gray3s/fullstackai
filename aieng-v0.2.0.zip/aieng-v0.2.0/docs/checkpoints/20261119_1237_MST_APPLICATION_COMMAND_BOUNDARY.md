# AIEng Application Command Boundary Checkpoint

**Recorded:** 2026-11-19 12:37 MST  
**Owner:** Samuel A. Gray III

## Preserved result

- Added a native C++ application library between future transports and the
  domain/store layer.
- Ticket reporters and transition actors are derived only from a typed,
  post-authentication principal; commands contain no actor field.
- Unauthenticated, whitespace-only, roleless, or trust-domain-less principals
  fail before persistence.
- Ticket/event identifiers, UTC timestamps, rationales, and lowercase SHA-256
  digests are length- and syntax-bounded before the domain is invoked.
- Public errors do not contain SQLite diagnostics; operator diagnostics remain
  separate.
- Audit corruption maps to an explicit integrity failure and leaves ticket
  state unchanged.
- Optimistic version failures map to conflicts without appending audit state.
- The patch proposal now binds the immutable artifact digest. Earlier workflow
  transitions reject digest injection; every later gate must use the same
  digest.

## Verification evidence

- Debug strict-warning build: passed.
- Domain/store CTest target: passed.
- Application-boundary CTest target: passed.
- Total QtTest phases: 32 passed, 0 failed, 0 skipped.
- ASan/UBSan build and both test targets: passed.
- LeakSanitizer: not run and not claimed; scheduled for a non-ptrace VM or
  bare-metal runner.
- Hardened `RelWithDebInfo` build and both test targets: passed.
- Release binary checks: PIE, RELRO, immediate binding, and non-executable
  stack passed.
- No-Python artifact/invocation audit: passed.
- `git diff --check`: passed.
- No package, VM, listener, CarCase file, Lexar partition, or external system
  was changed.

## Honest current state

This checkpoint verifies an in-process application boundary, not network
authentication. The future OIDC adapter still must validate signature,
algorithm, issuer, audience, lifetime, replay controls, and role mapping before
it may construct an `AuthenticatedPrincipal`. ADR 0002's transport
qualification remains unfulfilled.

## Next authorized action

Define and test the identity claim-mapping port independently of any JWT
library, including exact issuer/audience policy, reserved role mapping,
duplicate/ambiguous claim rejection, and fail-closed key-rotation states. Then
prepare its native cryptographic/JWT dependency qualification record.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

