// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "StaffForm.h"
#include <QApplication>
#include <QClipboard>
#include <QFormLayout>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QProcess>
#include <QPushButton>
#include <QTabWidget>
#include <QVBoxLayout>

StaffForm::StaffForm(const QString &socket)
{
    setWindowTitle(tr("AIEng staff tickets"));
    resize(560, 450);
    auto *layout = new QVBoxLayout(this);
    auto *tabs = new QTabWidget;
    layout->addWidget(tabs);
    auto *compose = new QWidget;
    auto *form = new QFormLayout(compose);
    auto *summary = new QLineEdit;
    summary->setMaxLength(160);
    auto *description = new QPlainTextEdit;
    description->setPlaceholderText(tr("What happened, and what did you expect?"));
    auto *file = new QPushButton(tr("File ticket"));
    form->addRow(tr("&Summary"), summary);
    form->addRow(tr("&Description"), description);
    form->addRow(file);
    tabs->addTab(compose, tr("New ticket"));
    auto *lookup = new QWidget;
    auto *query = new QFormLayout(lookup);
    auto *id = new QLineEdit;
    id->setMaxLength(128);
    auto *show = new QPushButton(tr("Look up ticket"));
    auto *copy = new QPushButton(tr("Copy ticket ID"));
    auto *detail = new QPlainTextEdit;
    detail->setReadOnly(true);
    copy->setEnabled(false);
    query->addRow(tr("Ticket &ID"), id);
    query->addRow(copy, show);
    query->addRow(detail);
    tabs->addTab(lookup, tr("Find ticket"));
    auto *status = new QLabel;
    status->setTextFormat(Qt::PlainText);
    status->setWordWrap(true);
    layout->addWidget(status);

    auto *client = new QProcess(this);
    client->setProgram(QCoreApplication::applicationDirPath() + QStringLiteral("/aieng-ticket"));
    auto enable = [=] {
        const bool idle = client->state() == QProcess::NotRunning;
        const auto body = description->toPlainText();
        file->setEnabled(idle && !summary->text().trimmed().isEmpty()
                         && !body.trimmed().isEmpty() && body.size() <= 8192);
        show->setEnabled(idle && !id->text().trimmed().isEmpty());
        copy->setEnabled(!id->text().trimmed().isEmpty());
    };
    connect(description, &QPlainTextEdit::textChanged, this, enable);
    connect(summary, &QLineEdit::textChanged, this, enable);
    connect(id, &QLineEdit::textChanged, this, [=] { detail->clear(); enable(); });
    connect(copy, &QPushButton::clicked, this, [=] { QApplication::clipboard()->setText(id->text()); });
    auto busy = [=](bool active) {
        tabs->setEnabled(!active);
        enable();
    };
    connect(client, &QProcess::errorOccurred, this, [=](QProcess::ProcessError error) {
        if (error == QProcess::FailedToStart) {
            status->setText(tr("Could not start the AIEng ticket client."));
            busy(false);
        }
    });
    connect(client, &QProcess::finished, this, [=](int code, QProcess::ExitStatus exitStatus) {
        const bool created = client->arguments().value(1) == QStringLiteral("create");
        const auto record = QJsonDocument::fromJson(client->readAllStandardOutput()).object();
        const auto errors = client->readAllStandardError();
        if (code == 0 && exitStatus == QProcess::NormalExit && !record.value("id").toString().isEmpty()) {
            id->setText(record.value("id").toString());
            detail->setPlainText(record.value("state").toString() + QStringLiteral(" · ")
                + record.value("summary").toString() + QStringLiteral("\n\n") + record.value("description").toString());
            if (created) {
                summary->clear();
                description->clear();
                tabs->setCurrentWidget(lookup);
            }
            status->setText(created ? tr("Ticket filed. Keep the ID for follow-up.") : tr("Ticket retrieved."));
        } else {
            detail->clear();
            status->setText(QJsonDocument::fromJson(errors).object().value("error")
                .toString(tr("The service did not confirm the request. Check the connection.")));
        }
        busy(false);
    });
    connect(file, &QPushButton::clicked, this, [=] {
        busy(true);
        status->setText(tr("Filing ticket…"));
        client->setArguments({socket, QStringLiteral("create"), summary->text().trimmed()});
        client->start();
        client->write(description->toPlainText().toUtf8());
        client->closeWriteChannel();
    });
    connect(show, &QPushButton::clicked, this, [=] {
        busy(true);
        status->setText(tr("Looking up ticket…"));
        client->setArguments({socket, QStringLiteral("show"), id->text().trimmed()});
        client->start();
        client->closeWriteChannel();
    });
    enable();
}
