// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/TicketStore.h"

#include <QJsonDocument>
#include <QJsonObject>
#include <QMessageAuthenticationCode>
#include <QSqlError>
#include <QSqlQuery>
#include <QUuid>

namespace aieng::domain {
namespace {

void setError(QString *destination, const QString &message)
{
    if (destination != nullptr) {
        *destination = message;
    }
}

[[nodiscard]] QString queryError(const QSqlQuery &query, const QString &context)
{
    return context + QStringLiteral(": ") + query.lastError().text();
}

[[nodiscard]] QString nonNull(const QString &value)
{
    return value.isNull() ? QStringLiteral("") : value;
}

void appendIntegrityField(QByteArray &body, const QByteArray &value)
{
    body.append(QByteArray::number(value.size()));
    body.append(':');
    body.append(value);
}

[[nodiscard]] QByteArray ticketIntegrityBody(const Ticket &ticket)
{
    QByteArray body;
    appendIntegrityField(body, ticket.id.toUtf8());
    appendIntegrityField(body, ticket.projectId.toUtf8());
    appendIntegrityField(body, Workflow::stateName(ticket.state).toUtf8());
    appendIntegrityField(body, QByteArray::number(ticket.version));
    appendIntegrityField(body, ticket.reporterId.toUtf8());
    appendIntegrityField(body, ticket.patchAuthorId.toUtf8());
    appendIntegrityField(body, ticket.qaApproverId.toUtf8());
    appendIntegrityField(body, ticket.releaseApproverId.toUtf8());
    appendIntegrityField(body, ticket.artifactDigest.toUtf8());
    // Preserve the canonical form for metadata-only tickets from schema 2.
    if (!ticket.summary.isEmpty() || !ticket.description.isEmpty()) {
        appendIntegrityField(body, ticket.summary.toUtf8());
        appendIntegrityField(body, ticket.description.toUtf8());
    }
    return body;
}

[[nodiscard]] QByteArray ticketIntegrityMac(const Ticket &ticket, const QByteArray &secret)
{
    return QMessageAuthenticationCode::hash(
               ticketIntegrityBody(ticket), secret, QCryptographicHash::Sha256)
        .toHex();
}

[[nodiscard]] QByteArray deriveSubkey(const QByteArray &masterSecret, const QByteArray &purpose)
{
    QByteArray context("AIEng-HMAC-subkey-v1");
    appendIntegrityField(context, purpose);
    return QMessageAuthenticationCode::hash(
        context, masterSecret, QCryptographicHash::Sha256);
}

[[nodiscard]] QByteArray auditMacKey(const QByteArray &masterSecret)
{
    return deriveSubkey(masterSecret, QByteArray("audit-chain/v1"));
}

[[nodiscard]] QByteArray ticketMacKey(const QByteArray &masterSecret)
{
    return deriveSubkey(masterSecret, QByteArray("ticket-row/v1"));
}

[[nodiscard]] bool constantTimeEqual(const QByteArray &left, const QByteArray &right)
{
    if (left.size() != right.size()) {
        return false;
    }
    unsigned char difference = 0;
    for (qsizetype index = 0; index < left.size(); ++index) {
        difference = static_cast<unsigned char>(
            difference | static_cast<unsigned char>(left.at(index) ^ right.at(index)));
    }
    return difference == 0;
}

void bindTicket(QSqlQuery &query, const Ticket &ticket, const QByteArray &secret)
{
    query.bindValue(QStringLiteral(":id"), ticket.id);
    query.bindValue(QStringLiteral(":project"), ticket.projectId);
    query.bindValue(QStringLiteral(":state"), Workflow::stateName(ticket.state));
    query.bindValue(QStringLiteral(":version"), QVariant::fromValue(ticket.version));
    query.bindValue(QStringLiteral(":reporter"), nonNull(ticket.reporterId));
    query.bindValue(QStringLiteral(":patch_author"), nonNull(ticket.patchAuthorId));
    query.bindValue(QStringLiteral(":qa_approver"), nonNull(ticket.qaApproverId));
    query.bindValue(QStringLiteral(":release_approver"), nonNull(ticket.releaseApproverId));
    query.bindValue(QStringLiteral(":digest"), nonNull(ticket.artifactDigest));
    query.bindValue(QStringLiteral(":integrity_mac"), ticketIntegrityMac(ticket, secret));
}

} // namespace

TicketStore::TicketStore(QString databaseName, QByteArray auditSecret, QString connectionName)
    : m_connectionName(
          connectionName.isEmpty()
              ? QStringLiteral("aieng-") + QUuid::createUuid().toString(QUuid::WithoutBraces)
              : std::move(connectionName))
    , m_databaseName(std::move(databaseName))
    , m_auditSecret(std::move(auditSecret))
{
}

TicketStore::~TicketStore()
{
    if (m_database.isValid()) {
        m_database.close();
    }
    m_database = QSqlDatabase();
    QSqlDatabase::removeDatabase(m_connectionName);
}

bool TicketStore::open(QString *error)
{
    if (m_auditSecret.size() < 32) {
        setError(error, QStringLiteral("audit secret must contain at least 32 bytes"));
        return false;
    }
    m_database = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), m_connectionName);
    m_database.setDatabaseName(m_databaseName);
    if (!m_database.open()) {
        setError(error, m_database.lastError().text());
        return false;
    }

    QSqlQuery pragma(m_database);
    if (!pragma.exec(QStringLiteral("PRAGMA foreign_keys = ON"))) {
        setError(error, queryError(pragma, QStringLiteral("enable foreign keys")));
        return false;
    }
    if (m_databaseName != QStringLiteral(":memory:")
        && !pragma.exec(QStringLiteral("PRAGMA journal_mode = WAL"))) {
        setError(error, queryError(pragma, QStringLiteral("enable WAL")));
        return false;
    }
    pragma.finish();
    return migrate(error);
}

bool TicketStore::migrate(QString *error)
{
    if (!m_database.transaction()) {
        setError(error, m_database.lastError().text());
        return false;
    }
    QSqlQuery query(m_database);
    const QStringList statements{
        QStringLiteral(
            "CREATE TABLE IF NOT EXISTS schema_metadata ("
            " singleton INTEGER PRIMARY KEY CHECK (singleton = 1),"
            " schema_version INTEGER NOT NULL CHECK (schema_version = 2))"),
        QStringLiteral(
            "INSERT OR IGNORE INTO schema_metadata(singleton, schema_version) VALUES(1, 2)"),
        QStringLiteral(
            "CREATE TABLE IF NOT EXISTS tickets ("
            " id TEXT PRIMARY KEY NOT NULL CHECK (length(id) > 0),"
            " project_id TEXT NOT NULL CHECK (length(project_id) > 0),"
            " state TEXT NOT NULL CHECK (state IN ("
            " 'OPEN','TRIAGED','AGENT_QUEUED','PATCH_PROPOSED','QA_RUNNING',"
            " 'QA_APPROVED','RELEASE_APPROVED','DEPLOYING','DEPLOYED',"
            " 'NEEDS_HUMAN','REJECTED','ROLLBACK_REQUIRED'))," 
            " version INTEGER NOT NULL CHECK (version >= 1),"
            " reporter_id TEXT NOT NULL,"
            " patch_author_id TEXT NOT NULL DEFAULT '',"
            " qa_approver_id TEXT NOT NULL DEFAULT '',"
            " release_approver_id TEXT NOT NULL DEFAULT '',"
            " artifact_digest TEXT NOT NULL DEFAULT '',"
            " integrity_mac_hex BLOB NOT NULL CHECK (length(integrity_mac_hex) = 64))"),
        QStringLiteral(
            "CREATE TABLE IF NOT EXISTS audit_events ("
            " sequence INTEGER PRIMARY KEY AUTOINCREMENT,"
            " event_id TEXT NOT NULL UNIQUE,"
            " occurred_at_utc TEXT NOT NULL,"
            " actor_id TEXT NOT NULL,"
            " action TEXT NOT NULL,"
            " object_type TEXT NOT NULL,"
            " object_id TEXT NOT NULL,"
            " canonical_payload BLOB NOT NULL,"
            " previous_mac_hex BLOB NOT NULL,"
            " mac_hex BLOB NOT NULL UNIQUE)"),
    };
    for (const QString &statement : statements) {
        if (!query.exec(statement)) {
            m_database.rollback();
            setError(error, queryError(query, QStringLiteral("schema migration")));
            return false;
        }
    }
    if (!query.exec(QStringLiteral(
            "SELECT schema_version FROM schema_metadata WHERE singleton = 1"))
        || !query.next() || query.value(0).toInt() != 2) {
        m_database.rollback();
        setError(error, QStringLiteral("unsupported database schema; offline migration required"));
        return false;
    }
    if (!query.exec(QStringLiteral("PRAGMA table_info(tickets)"))) {
        m_database.rollback();
        setError(error, queryError(query, QStringLiteral("inspect ticket schema")));
        return false;
    }
    QSet<QString> ticketColumns;
    while (query.next()) {
        ticketColumns.insert(query.value(1).toString());
    }
    const QSet<QString> requiredColumns{
        QStringLiteral("id"),
        QStringLiteral("project_id"),
        QStringLiteral("state"),
        QStringLiteral("version"),
        QStringLiteral("reporter_id"),
        QStringLiteral("patch_author_id"),
        QStringLiteral("qa_approver_id"),
        QStringLiteral("release_approver_id"),
        QStringLiteral("artifact_digest"),
        QStringLiteral("integrity_mac_hex"),
    };
    for (const QString &required : requiredColumns) {
        if (!ticketColumns.contains(required)) {
            m_database.rollback();
            setError(error, QStringLiteral("ticket schema is incomplete; offline migration required"));
            return false;
        }
    }
    query.finish();
    const bool hasSummary = ticketColumns.contains(QStringLiteral("summary"));
    if (hasSummary != ticketColumns.contains(QStringLiteral("description"))) {
        m_database.rollback();
        setError(error, QStringLiteral("incomplete ticket content schema"));
        return false;
    }
    if (!hasSummary
        && (!query.exec(QStringLiteral("ALTER TABLE tickets ADD COLUMN summary TEXT NOT NULL DEFAULT ''"))
            || !query.exec(QStringLiteral("ALTER TABLE tickets ADD COLUMN description TEXT NOT NULL DEFAULT ''")))) {
        m_database.rollback();
        setError(error, queryError(query, QStringLiteral("add work-order content")));
        return false;
    }
    if (!query.exec(QStringLiteral("CREATE INDEX IF NOT EXISTS tickets_queue ON tickets(project_id,state,id)"))) {
        m_database.rollback();
        setError(error, queryError(query, QStringLiteral("index queue")));
        return false;
    }
    if (!m_database.commit()) {
        setError(error, m_database.lastError().text());
        return false;
    }
    return true;
}

bool TicketStore::createTicket(
    const Ticket &ticket,
    const QString &eventId,
    const QString &occurredAtUtc,
    QString *error)
{
    if (ticket.id.isEmpty() || ticket.projectId.isEmpty()
        || ticket.state != TicketState::Open || ticket.version != 1U) {
        setError(
            error,
            QStringLiteral("new ticket must have ticket/project ids, OPEN state, and version 1"));
        return false;
    }
    if (!m_database.transaction()) {
        setError(error, m_database.lastError().text());
        return false;
    }
    QSqlQuery insert(m_database);
    insert.prepare(QStringLiteral(
        "INSERT INTO tickets(id, project_id, state, version, reporter_id, patch_author_id,"
        " qa_approver_id, release_approver_id, artifact_digest, integrity_mac_hex, summary, description)"
        " VALUES(:id, :project, :state, :version, :reporter, :patch_author, :qa_approver,"
        " :release_approver, :digest, :integrity_mac, :summary, :description)"));
    bindTicket(insert, ticket, ticketMacKey(m_auditSecret));
    insert.bindValue(QStringLiteral(":summary"), nonNull(ticket.summary));
    insert.bindValue(QStringLiteral(":description"), nonNull(ticket.description));
    if (!insert.exec()) {
        m_database.rollback();
        setError(error, queryError(insert, QStringLiteral("create ticket")));
        return false;
    }
    const QJsonObject payload{{QStringLiteral("project_id"), ticket.projectId},
                              {QStringLiteral("state"), Workflow::stateName(ticket.state)},
                              {QStringLiteral("version"), static_cast<qint64>(ticket.version)}};
    if (!appendAudit(
            eventId,
            occurredAtUtc,
            ticket.reporterId,
            QStringLiteral("ticket.created"),
            QStringLiteral("ticket"),
            ticket.id,
            QJsonDocument(payload).toJson(QJsonDocument::Compact),
            error)) {
        m_database.rollback();
        return false;
    }
    if (!m_database.commit()) {
        setError(error, m_database.lastError().text());
        return false;
    }
    return true;
}

static const QString ticketSelect = QStringLiteral(
    "SELECT id, project_id, state, version, reporter_id, patch_author_id, qa_approver_id,"
    " release_approver_id, artifact_digest, integrity_mac_hex, summary, description FROM tickets ");

std::optional<Ticket> TicketStore::loadTicket(const QString &ticketId, QString *error) const
{
    QSqlQuery query(m_database);
    query.prepare(ticketSelect + QStringLiteral("WHERE id = :id"));
    query.bindValue(QStringLiteral(":id"), ticketId);
    if (!query.exec()) {
        setError(error, queryError(query, QStringLiteral("load ticket")));
        return std::nullopt;
    }
    if (!query.next()) {
        return std::nullopt;
    }
    return decodeRow(query, error);
}

std::optional<QueuePage> TicketStore::listTickets(
    const QString &project, TicketState state, const QString &after, QString *error) const
{
    QSqlQuery query(m_database);
    query.prepare(ticketSelect + QStringLiteral(
        "WHERE project_id = ? AND state = ? AND id > ? ORDER BY id LIMIT 26"));
    query.addBindValue(project);
    query.addBindValue(Workflow::stateName(state));
    query.addBindValue(nonNull(after));
    if (!query.exec()) {
        setError(error, queryError(query, QStringLiteral("list tickets")));
        return std::nullopt;
    }
    QueuePage page;
    while (query.next()) {
        const auto ticket = decodeRow(query, error);
        if (!ticket) return std::nullopt;
        if (page.entries.size() == 25) {
            page.nextAfter = page.entries.last().id;
            break;
        }
        page.entries.append({ticket->id, ticket->summary, ticket->version});
    }
    if (query.lastError().isValid()) {
        setError(error, queryError(query, QStringLiteral("read queue page")));
        return std::nullopt;
    }
    return page;
}

std::optional<Ticket> TicketStore::decodeRow(const QSqlQuery &query, QString *error) const
{
    const auto state = Workflow::stateFromName(query.value(2).toString());
    if (!state.has_value()) {
        setError(error, QStringLiteral("database contains an unknown ticket state"));
        return std::nullopt;
    }
    Ticket ticket;
    ticket.id = query.value(0).toString();
    ticket.projectId = query.value(1).toString();
    ticket.state = *state;
    ticket.version = query.value(3).toULongLong();
    ticket.reporterId = query.value(4).toString();
    ticket.patchAuthorId = query.value(5).toString();
    ticket.qaApproverId = query.value(6).toString();
    ticket.releaseApproverId = query.value(7).toString();
    ticket.artifactDigest = query.value(8).toString();
    ticket.summary = query.value(10).toString();
    ticket.description = query.value(11).toString();
    if (!constantTimeEqual(
            query.value(9).toByteArray(),
            ticketIntegrityMac(ticket, ticketMacKey(m_auditSecret)))) {
        setError(error, QStringLiteral("ticket integrity verification failed"));
        return std::nullopt;
    }
    return ticket;
}

StoreResult TicketStore::transition(
    const QString &ticketId,
    const TransitionRequest &request,
    const Actor &actor,
    const QString &eventId,
    const QString &occurredAtUtc)
{
    StoreResult result;
    if (!m_database.transaction()) {
        result.error = m_database.lastError().text();
        return result;
    }

    QString loadError;
    const auto loaded = loadTicket(ticketId, &loadError);
    if (!loaded.has_value()) {
        m_database.rollback();
        result.error = loadError.isEmpty() ? QStringLiteral("ticket not found") : loadError;
        return result;
    }
    result.ticket = *loaded;
    const TicketState from = result.ticket.state;
    result.decision = Workflow::apply(result.ticket, request, actor);
    if (!result.decision.allowed()) {
        m_database.rollback();
        return result;
    }

    QString auditError;
    if (!verifyAudit(&auditError)) {
        m_database.rollback();
        result.error = QStringLiteral("audit chain verification failed: ") + auditError;
        return result;
    }

    QSqlQuery update(m_database);
    update.prepare(QStringLiteral(
        "UPDATE tickets SET state = :state, version = :version,"
        " patch_author_id = :patch_author, qa_approver_id = :qa_approver,"
        " release_approver_id = :release_approver, artifact_digest = :digest,"
        " integrity_mac_hex = :integrity_mac"
        " WHERE id = :id AND version = :expected_version"));
    bindTicket(update, result.ticket, ticketMacKey(m_auditSecret));
    update.bindValue(QStringLiteral(":expected_version"), QVariant::fromValue(request.expectedVersion));
    if (!update.exec() || update.numRowsAffected() != 1) {
        m_database.rollback();
        result.error = update.lastError().isValid()
            ? queryError(update, QStringLiteral("transition ticket"))
            : QStringLiteral("concurrent update rejected");
        return result;
    }

    if (!appendAudit(
            eventId,
            occurredAtUtc,
            actor.id,
            QStringLiteral("ticket.transitioned"),
            QStringLiteral("ticket"),
            ticketId,
            transitionPayload(from, result.ticket, request),
            &result.error)) {
        m_database.rollback();
        return result;
    }
    if (!m_database.commit()) {
        result.error = m_database.lastError().text();
        return result;
    }
    result.persisted = true;
    return result;
}

QList<AuditEvent> TicketStore::auditEvents(QString *error) const
{
    QList<AuditEvent> events;
    QSqlQuery query(m_database);
    if (!query.exec(QStringLiteral(
            "SELECT sequence, event_id, occurred_at_utc, actor_id, action, object_type,"
            " object_id, canonical_payload, previous_mac_hex, mac_hex"
            " FROM audit_events ORDER BY sequence"))) {
        setError(error, queryError(query, QStringLiteral("load audit events")));
        return events;
    }
    while (query.next()) {
        AuditEvent event;
        event.sequence = query.value(0).toULongLong();
        event.eventId = query.value(1).toString();
        event.occurredAtUtc = query.value(2).toString();
        event.actorId = query.value(3).toString();
        event.action = query.value(4).toString();
        event.objectType = query.value(5).toString();
        event.objectId = query.value(6).toString();
        event.canonicalPayload = query.value(7).toByteArray();
        event.previousMacHex = query.value(8).toByteArray();
        event.macHex = query.value(9).toByteArray();
        events.append(event);
    }
    return events;
}

bool TicketStore::verifyAudit(QString *error) const
{
    QString loadError;
    const QList<AuditEvent> events = auditEvents(&loadError);
    if (!loadError.isEmpty()) {
        setError(error, loadError);
        return false;
    }
    if (!AuditChain::verify(events, auditMacKey(m_auditSecret))) {
        setError(error, QStringLiteral("stored audit MAC chain is invalid"));
        return false;
    }
    return true;
}

bool TicketStore::appendAudit(
    const QString &eventId,
    const QString &occurredAtUtc,
    const QString &actorId,
    const QString &action,
    const QString &objectType,
    const QString &objectId,
    const QByteArray &canonicalPayload,
    QString *error)
{
    QString loadError;
    const QList<AuditEvent> stored = auditEvents(&loadError);
    const QByteArray auditKey = auditMacKey(m_auditSecret);
    if (!loadError.isEmpty() || !AuditChain::verify(stored, auditKey)) {
        setError(
            error,
            loadError.isEmpty() ? QStringLiteral("refusing to append to invalid audit chain") : loadError);
        return false;
    }

    AuditChain chain(auditKey);
    for (const AuditEvent &event : stored) {
        (void)chain.append(
            event.eventId,
            event.occurredAtUtc,
            event.actorId,
            event.action,
            event.objectType,
            event.objectId,
            event.canonicalPayload);
    }
    const AuditEvent event = chain.append(
        eventId,
        occurredAtUtc,
        actorId,
        action,
        objectType,
        objectId,
        canonicalPayload);

    QSqlQuery insert(m_database);
    insert.prepare(QStringLiteral(
        "INSERT INTO audit_events(sequence, event_id, occurred_at_utc, actor_id, action,"
        " object_type, object_id, canonical_payload, previous_mac_hex, mac_hex)"
        " VALUES(:sequence, :event_id, :occurred, :actor, :action, :object_type,"
        " :object_id, :payload, :previous_mac, :mac)"));
    insert.bindValue(QStringLiteral(":sequence"), QVariant::fromValue(event.sequence));
    insert.bindValue(QStringLiteral(":event_id"), event.eventId);
    insert.bindValue(QStringLiteral(":occurred"), event.occurredAtUtc);
    insert.bindValue(QStringLiteral(":actor"), event.actorId);
    insert.bindValue(QStringLiteral(":action"), event.action);
    insert.bindValue(QStringLiteral(":object_type"), event.objectType);
    insert.bindValue(QStringLiteral(":object_id"), event.objectId);
    insert.bindValue(QStringLiteral(":payload"), event.canonicalPayload);
    insert.bindValue(QStringLiteral(":previous_mac"), event.previousMacHex);
    insert.bindValue(QStringLiteral(":mac"), event.macHex);
    if (!insert.exec()) {
        setError(error, queryError(insert, QStringLiteral("append audit event")));
        return false;
    }
    return true;
}

QByteArray TicketStore::transitionPayload(
    TicketState from,
    const Ticket &updated,
    const TransitionRequest &request)
{
    const QJsonObject payload{
        {QStringLiteral("artifact_digest"), request.artifactDigest},
        {QStringLiteral("from"), Workflow::stateName(from)},
        {QStringLiteral("rationale"), request.rationale},
        {QStringLiteral("to"), Workflow::stateName(updated.state)},
        {QStringLiteral("version"), static_cast<qint64>(updated.version)},
    };
    return QJsonDocument(payload).toJson(QJsonDocument::Compact);
}

} // namespace aieng::domain

