// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/TicketStore.h"
#include "aieng/application/TicketApplication.h"

#include <QCoreApplication>
#include <QFile>

using namespace aieng::domain;

// Seed a proposal attributed to a separate test principal on a single-UID test host.
int main(int argc, char **argv)
{
    QCoreApplication process(argc, argv);
    const auto args = process.arguments();
    if (args.size() != 5 && args.size() != 6) return 2;
    QFile key(args[2]);
    if (!key.open(QIODevice::ReadOnly)) return 1;
    TicketStore store(args[1], key.readAll(), QStringLiteral("qa-fixture"));
    QString error;
    if (!store.open(&error)) return 1;
    Ticket ticket;
    ticket.id = QStringLiteral("independent-proposal");
    ticket.projectId = QStringLiteral("sample");
    ticket.reporterId = QStringLiteral("staff-fixture");
    ticket.summary = QStringLiteral("Independent QA fixture");
    const auto time = QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs);
    if (args.size() == 6) {
        using namespace aieng::application;
        const bool release = args[3] == QStringLiteral("release");
        if (!release && args[3] != QStringLiteral("propose")) return 2;
        const auto current = store.loadTicket(args[4], &error);
        if (!current || current->projectId != ticket.projectId) return 1;
        AuthenticatedPrincipal principal;
        principal.subject = release ? QStringLiteral("release-fixture") : QStringLiteral("developer-fixture");
        principal.trustDomain = QStringLiteral("local-rehearsal");
        principal.projectRoles[ticket.projectId].insert(release ? Role::Release : Role::Developer);
        principal.authenticated = true;
        return TicketApplication(store).transitionTicket(
            {current->id, release ? TicketState::ReleaseApproved : TicketState::PatchProposed, current->version,
             release ? QStringLiteral("Fixture release approval for disposable local target") : QStringLiteral("Fixture developer submitted fix"),
             args[5]}, principal, {args[3] + current->id, time}).succeeded() ? 0 : 1;
    }
    if (args[3] == QStringLiteral("seed")) {
        const Actor support{QStringLiteral("triager-fixture"), {Role::Support}};
        const Actor author{QStringLiteral("developer-fixture"), {Role::Developer}};
        if (!store.createTicket(ticket, "fixture-open", time, &error)) return 1;
        if (!store.transition(ticket.id, {TicketState::Triaged, 1, "Triage sample", {}}, support, "fixture-triage", time).persisted) return 1;
        if (!store.transition(ticket.id, {TicketState::AgentQueued, 2, "Queue sample", {}}, support, "fixture-queue", time).persisted) return 1;
        return store.transition(ticket.id, {TicketState::PatchProposed, 3, "Sample candidate", args[4]},
                                author, "fixture-proposal", time).persisted ? 0 : 1;
    }
    if (args[3] != QStringLiteral("verify")) return 2;
    QFile expected(args[4]);
    if (!expected.open(QIODevice::ReadOnly)) return 1;
    const auto saved = store.loadTicket(ticket.id, &error);
    if (!saved || saved->state != TicketState::QaRunning || saved->version != 5 || !store.verifyAudit(&error)) return 1;
    QSqlQuery query(QSqlDatabase::database(QStringLiteral("qa-fixture")));
    query.prepare(QStringLiteral("SELECT content FROM qa_candidates WHERE ticket_id=?"));
    query.addBindValue(ticket.id);
    return query.exec() && query.next() && query.value(0).toByteArray() == expected.readAll() ? 0 : 1;
}
