// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include <QSet>
#include <QString>

#include <optional>

namespace aieng::domain {

inline constexpr qsizetype maxCandidateBytes = 16 * 1024 * 1024;

enum class Role {
    Reporter,
    Support,
    Developer,
    Agent,
    Qa,
    Release,
    Operator,
    Auditor,
    Administrator,
};

enum class TicketState {
    Open,
    Triaged,
    AgentQueued,
    PatchProposed,
    QaRunning,
    QaApproved,
    ReleaseApproved,
    Deploying,
    Deployed,
    NeedsHuman,
    Rejected,
    RollbackRequired,
};

struct Actor final {
    QString id;
    QSet<Role> roles;
};

struct WorkerLease final {
    QString owner;
    QByteArray proofHash;
    qint64 expiresAtMs{0};
};

struct Ticket final {
    QString id;
    QString projectId;
    TicketState state{TicketState::Open};
    quint64 version{1};
    QString reporterId;
    QString patchAuthorId;
    QString qaApproverId;
    QString releaseApproverId;
    QString artifactDigest;
    QString summary;
    QString description;
    WorkerLease lease{};
};

struct TransitionRequest final {
    TicketState target{TicketState::Open};
    quint64 expectedVersion{0};
    QString rationale;
    QString artifactDigest;
    QByteArray claimProof{};
    QByteArray qaCandidate{};
};

enum class DecisionCode {
    Allowed,
    InvalidTransition,
    MissingRole,
    StaleVersion,
    MissingRationale,
    MissingArtifactDigest,
    UnexpectedArtifactDigest,
    ArtifactDigestChanged,
    SeparationOfDuties,
    ClaimConflict,
    CandidateMismatch,
};

struct Decision final {
    DecisionCode code{DecisionCode::InvalidTransition};
    QString message;

    [[nodiscard]] bool allowed() const noexcept { return code == DecisionCode::Allowed; }
};

class Workflow final {
public:
    [[nodiscard]] static Decision evaluate(
        const Ticket &ticket,
        const TransitionRequest &request,
        const Actor &actor);

    [[nodiscard]] static Decision apply(
        Ticket &ticket,
        const TransitionRequest &request,
        const Actor &actor);

    [[nodiscard]] static QString stateName(TicketState state);
    [[nodiscard]] static std::optional<TicketState> stateFromName(const QString &name);
};

} // namespace aieng::domain

