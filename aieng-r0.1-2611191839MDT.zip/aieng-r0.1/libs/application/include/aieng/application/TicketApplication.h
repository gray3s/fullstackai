// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include "aieng/application/Principal.h"
#include "aieng/domain/TicketStore.h"

#include <QString>

namespace aieng::application {

struct TrustedCommandContext final {
    QString eventId;
    QString occurredAtUtc;
};

struct CreateTicketCommand final {
    QString ticketId;
    QString projectId;
    QString summary;
    QString description;
};

struct TransitionTicketCommand final {
    QString ticketId;
    domain::TicketState target{domain::TicketState::Open};
    quint64 expectedVersion{0};
    QString rationale;
    QString artifactDigest;
};

enum class ApplicationCode {
    Succeeded,
    Unauthenticated,
    Forbidden,
    InvalidCommand,
    Conflict,
    NotFound,
    IntegrityFailure,
    StorageFailure,
};

struct ApplicationResult final {
    ApplicationCode code{ApplicationCode::StorageFailure};
    domain::DecisionCode decisionCode{domain::DecisionCode::InvalidTransition};
    domain::Ticket ticket;
    QString publicMessage;
    QString operatorDiagnostic;
    domain::QueuePage page;

    [[nodiscard]] bool succeeded() const noexcept
    {
        return code == ApplicationCode::Succeeded;
    }
};

class TicketApplication final {
public:
    explicit TicketApplication(domain::TicketStore &store);

    [[nodiscard]] ApplicationResult listQueue(const QString &project, const QString &state,
        const QString &after, const AuthenticatedPrincipal &principal) const;

    [[nodiscard]] ApplicationResult readTicket(
        const QString &ticketId, const AuthenticatedPrincipal &principal) const;

    [[nodiscard]] ApplicationResult createTicket(
        const CreateTicketCommand &command,
        const AuthenticatedPrincipal &principal,
        const TrustedCommandContext &context);

    [[nodiscard]] ApplicationResult transitionTicket(
        const TransitionTicketCommand &command,
        const AuthenticatedPrincipal &principal,
        const TrustedCommandContext &context);

private:
    [[nodiscard]] static ApplicationResult validatePrincipal(
        const AuthenticatedPrincipal &principal);
    [[nodiscard]] static ApplicationResult validateContext(
        const TrustedCommandContext &context);
    [[nodiscard]] static bool isBoundedText(
        const QString &value,
        qsizetype minimum,
        qsizetype maximum);
    [[nodiscard]] static bool isIdentifier(const QString &value);
    [[nodiscard]] static bool isSha256Digest(const QString &value);
    [[nodiscard]] static ApplicationResult invalid(const QString &message);

    domain::TicketStore &m_store;
};

} // namespace aieng::application
