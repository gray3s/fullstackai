# AIEng experimental goals

Can an AI worker supply the engineering judgment needed to qualify a vibecoded project, and can a worker perform the IT work of
deploying the qualified product? The project being delivered is the variable. Test the same QA and deployment services against
different projects. Begin with known ground truth so an incorrect recommendation is visible.

## 1. Can a live worker do satisfactory QA?

Give the worker a behavior contract and access to a controlled test runner. Withhold source fixes, fixture labels, expected test
vectors and the grading key. The worker must choose tests, predict results, execute or request their execution, interpret observations
and decide whether there is enough evidence to ship. Record its raw output, tool actions, runtime and every intervention.

For the first pilot, a satisfactory trial distinguishes the working build from the defective one, gives correct expected results for
the decisive cases, and explains which observed behavior justifies each verdict. Insufficient evidence should lead to a hold or another
test. A failed trial is a result. Before making a general claim, repeat blind trials on an unfamiliar project and vary the defects.
Report false passes, false rejections, abstentions and human minutes. The owner sets acceptable rates for the intended environment.

## 2. Can a live worker deploy the qualified product?

Supply a named target, an independent release decision, an immutable artifact digest and a known previous release. Ask the worker to
choose an action, request installation, inspect the installed smoke result and decide whether to retain or roll back the release.
A bounded installer performs the physical operation. Record the decision maker and executor for each step.

Pass a pilot when the QA-approved bytes run at the intended target, a substitution is refused, and a failing smoke check leads to
verified recovery. Score artifact selection, installation and recovery separately. Record whether a human approval was required by
this version and whether someone had to perform engineering or IT work during the trial.

## 3. Does the same flow work for an unfamiliar vibecoded project?

Repeat both trials on a second small program described in plain language. Have someone other than the implementer supply a held-back
acceptance case. Retain the change request, code revision, tests, deployed digest, result from the installed path and any manual rescue.
A clean Ubuntu install and distinct real accounts make the subsequent portability and authority checks meaningful.

## Baseline and ownership

The worker-off Carton Count experiment reached a local deployed state. The submitted patch and role fixtures made it repeatable.
It establishes the benchmark for an autonomous worker. Code authorship, runtime AI, approval authority and production management
are distinct facts that every revision records. Optional AI features must preserve the conventional path when disabled.
[Local delivery checkpoint](checkpoints/20261119_2222_MST_local_delivery.md) · [Version operating model](VERSION_OPERATING_MODEL.md)

Security evidence covers authority and artifact identity. Reliability evidence covers observed behavior, interruption and recovery.
Each pilot states the target and remaining risks. The owner decides whether the result is sufficient for that environment.

## How AIEng will take a developer's idea through deployment

Use this sequence for AIEng itself and for projects it handles. A new project starts with the developer's answer to
“What algorithm do you want developed into code?” Project-specific constraints enter as the team learns the intended use.

| Work to do | Who contributes or decides | Evidence needed to finish |
| --- | --- | --- |
| Define the behavior | Developer and intended user | Purpose, inputs, prior state, transfer rule, outputs and one observation that would prove the behavior wrong. |
| Hear each affected stakeholder | Product owner, engineering, QA, security, IT, release and support | Each concern has a source, an owner and an observable acceptance condition. |
| Determine which standards apply | Owner of each rule, with a qualified interpreter where needed | Source, edition or effective date, applicable clause, jurisdiction or scope, reason it applies and evidence it requires. |
| Divide the work and delegate | Project owner and authorized subplan owners | Each part has a bounded deliverable, authorization to act, a reviewer, an acceptance check and a route back to its parent. |
| Resolve competing requirements | Named decision owner and owners of affected rules | Alternatives, consequences, binding constraints, reason for the decision and any unresolved dissent. |
| Build and test | Assigned individual or subteam and delegated reviewer | A test derived from each leaf requirement, actual result, evidence reference and disposition. Integration tests cover interactions between children. |
| Authorize and deploy | Named development signatory, release authority and operator | Reviewed candidate digest, target baseline, rollout and recovery checks, approval for this release, and observations from the installed path. |

**Reduction rule.** Keep dividing a requirement while two reasonable implementers could disagree about the expected result or the
reviewer could not identify a failing observation. Stop at a leaf when its assignee can act, its inputs and expected result are
clear, and its reviewer can distinguish pass, fail and insufficient evidence. Ask the developer about open intent. Offer reversible
method defaults and explain their costs when the developer delegates a choice. Record who selected the method.

**Delegation rule.** One accountable owner can retain the whole project or delegate work, review and sign-off separately to people
or subteams. Record the grantor, grantee, scope, permitted actions, limits, review authority and expiration or revocation condition.
For a team, identify who can sign on its behalf. A further delegation stays within its parent's grant. A parent closes after all
mandatory children pass review and their combined result meets its acceptance condition. Name the overall development signatory
and the deployment signatory explicitly, even when the same accountable owner oversees both. A version that allows an AI signatory
must authenticate its delegated identity and enforce the grant at the point of action. The present operating model retains its
existing QA and release controls.

**Delegate decisions that simplify the plan.** The coordinator gives an individual or subagent the smallest question whose answer
can eliminate work or settle a dependency. Record which alternatives the answer removes and which work it enables. A role names
who may act. Each decision specifies the authority to decide or recommend, the scope, and each condition that could change the
answer. Give measurable limits units, boundaries and an observation method. Route an unknown or out-of-scope condition to its owner.

**Decision audit trail.** At decision time, record the timestamp, parent decision, grantor and delegate, applicable grant version,
conditions, evidence then available, outcome and rationale. Link the resulting subplan or action and its later measurements.
Append a linked revision when an owner changes a condition so reviewers can reconstruct the authorization in force at the time.
For instance, an owner may allow five minutes of unavailable writes on one service during a named window while reads stay available.
Record how to measure the interruption, then attach the observed start, recovery and read checks. Reviewers can establish separately
whether the operator had authority to act and whether the service stayed within the allowance. This is a planned capability.

**Standards rule.** Consider individual practices, corporate policies and contracts, industry standards, and applicable law.
Record whether each item is a preference, a binding obligation or awaiting an applicability decision. An industry practice may
become binding through a contract or an applicable rule. Document that basis. An unknown jurisdiction, missing corporate policy
or disputed interpretation stays open with a named owner. Use the publisher crosswalk as a starting point.
[Lifecycle standards and sources](research/20261120_1017_MST_lifecycle_standards.md)

**Conflict rule.** Ask which observations would settle a factual dispute. For a genuine trade-off, compare feasible alternatives
against each mandatory constraint, then document preferences and consequences. Route unresolved conflicts to the authority that
can interpret or change the relevant constraint. Recheck the decision against the acceptance conditions. A majority vote confers
no authority to grant an exception. [Stakeholder and conflict questions](specifications/STAKEHOLDER_QUESTIONS.md)

**First implementation milestone.** The native design interview captures the developer's algorithm, reduces behaviors into
testable leaves and records method alternatives. The question bank and offline concern evaluator are drafts. Next, exercise them
with one feasible rollout and one incompatible pair of stakeholder constraints. Then persist and authorize a project plan, bind
subplan review to authenticated delegates and verify that a failed child blocks the relevant sign-off. Rehearse missing evidence,
revocation and rollback on a disposable target before the live-worker experiment. Track implemented authority for each version.
[Operating model](VERSION_OPERATING_MODEL.md) · [Work-window progress and handoff](checkpoints/20261120_1035_MST_stakeholder_handoff.md)

Copyright © 2026 Samuel A. Gray III. All rights reserved.
