# AIEng Transactional Persistence Checkpoint

**Created:** 2026-11-19 12:27 MST  
**Parent checkpoint:** `d0e7166`

## Implemented

- Native QtSql/SQLite repository with private named connections.
- Versioned schema metadata and constrained ticket/audit tables.
- Parameter-bound SQL; no values are interpolated into statements.
- Ticket creation and initial audit record in one transaction.
- Policy evaluation, compare-and-swap ticket update, and audit append in one
  transaction.
- Audit-chain verification before every state mutation.
- Fail-closed behavior on unknown stored state, bad audit key/history, stale
  version, database constraint failure, or concurrent update.
- WAL mode for file-backed development databases; in-memory mode for tests.

## Fresh acceptance evidence

`./scripts/verify.sh` completed successfully and fail-fast:

- no-Python gate: pass;
- CMake configure: pass;
- strict C++ build: pass;
- CTest/Qt Test: pass;
- 12 domain/persistence test functions plus suite setup/cleanup: pass.

The new tests prove:

- ticket transition and audit append commit together;
- stale transition leaves both ticket and audit unchanged;
- modified stored audit payload blocks all later mutation;
- forced duplicate audit event failure rolls the ticket update back and keeps a
  valid one-event audit chain.

## Preserved failed evidence

1. The first persistence test build failed due to a missing direct `QSqlQuery`
   include. A stale earlier test binary ran afterward in the ad-hoc command, so
   that result was rejected and the fail-fast verifier was used thereafter.
2. The first fresh persistence test run failed because null `QString` optionals
   bound as SQL `NULL`. The database constraint was retained; the storage
   boundary now canonicalizes optional text to non-null empty strings.

## Limitations

SQLite is the local development/reference store. Corporate multi-user topology
still targets PostgreSQL through a separately tested adapter. Database files,
audit HMAC keys, and audit-chain heads are not yet protected by the future
secrets/audit-export infrastructure. Schema version 1 has no upgrade path yet;
later migrations must be forward-only, tested from every supported version,
and backed up before application.

## Next authorized action

Add security-focused build profiles (ASan/UBSan and release hardening),
property/table-driven transition coverage, durable file reopen/recovery tests,
and the service-framework ADR. Do not expose a network listener until identity,
request limits, TLS termination, parser behavior, and authorization tests are
specified.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

