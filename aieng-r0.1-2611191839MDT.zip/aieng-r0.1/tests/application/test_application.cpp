// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/application/TicketApplication.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QTest>
#include <QTemporaryDir>

using namespace aieng::application;
using namespace aieng::domain;

namespace {

constexpr auto auditKey = "01234567890123456789012345678901";
const QString projectId = QStringLiteral("PROJECT-1");

[[nodiscard]] AuthenticatedPrincipal principal(
    const QString &subject,
    std::initializer_list<Role> roles,
    const QString &scope = projectId)
{
    AuthenticatedPrincipal value;
    value.subject = subject;
    value.trustDomain = QStringLiteral("https://id.example.invalid/realms/aieng");
    value.authenticated = true;
    for (const Role role : roles) {
        value.projectRoles[scope].insert(role);
    }
    return value;
}

[[nodiscard]] CreateTicketCommand createCommand(const QString &ticketId)
{
    return {ticketId, projectId, QStringLiteral("Build fails"), QStringLiteral("Open the kit.\nSelect Build.")};
}

[[nodiscard]] TrustedCommandContext context(const QString &eventId)
{
    return {eventId, QStringLiteral("2026-11-19T19:32:00.000Z")};
}

[[nodiscard]] TransitionTicketCommand triage(const QString &ticketId)
{
    return {
        ticketId,
        TicketState::Triaged,
        1,
        QStringLiteral("validated support triage"),
        {},
    };
}

} // namespace

class ApplicationTest final : public QObject {
    Q_OBJECT

private slots:
    void workOrderSurvivesReopenAndStaysPrivate();
    void invalidWorkOrderLeavesNoHistory();
    void unauthenticatedCreateDoesNotWrite();
    void reporterIdentityOwnsCreatedTicket();
    void reporterCannotCreateInAnotherProject();
    void authorizedSupportTransitionPersists();
    void supportRoleIsProjectScoped();
    void clientCannotSupplyActorIdentity();
    void invalidTrustedContextDoesNotWrite();
    void malformedAuthenticatedIdentityDoesNotWrite();
    void oversizedRationaleDoesNotReachDomain();
    void malformedDigestDoesNotReachDomain();
    void staleVersionBecomesConflict();
    void storageDiagnosticIsNotPublic();
    void auditCorruptionBecomesIntegrityFailure();
};

void ApplicationTest::workOrderSurvivesReopenAndStaysPrivate()
{
    QTemporaryDir dir;
    QVERIFY(dir.isValid());
    const auto path = dir.filePath(QStringLiteral("orders.db"));
    const auto owner = principal(QStringLiteral("alice"), {Role::Reporter});
    const auto cmd = createCommand(QStringLiteral("W-1"));
    QString error;
    {
        TicketStore store(path, QByteArray(auditKey));
        QVERIFY2(store.open(&error), qPrintable(error));
        QVERIFY(TicketApplication(store).createTicket(cmd, owner, context(QStringLiteral("created"))).succeeded());
    }
    const QString connection = QStringLiteral("reopened-order");
    TicketStore store(path, QByteArray(auditKey), connection);
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication app(store);
    QCOMPARE(app.readTicket(cmd.ticketId, owner).ticket.description, cmd.description);
    QCOMPARE(app.readTicket(cmd.ticketId, principal(QStringLiteral("sam"), {Role::Support})).ticket.summary, cmd.summary);
    const auto stranger = principal(QStringLiteral("bob"), {Role::Reporter});
    QCOMPARE(app.readTicket(cmd.ticketId, stranger).code, ApplicationCode::NotFound);
    QVERIFY(app.transitionTicket(triage(cmd.ticketId), stranger, context(QStringLiteral("denied"))).ticket.description.isEmpty());
    const auto outside = principal(QStringLiteral("sam"), {Role::Support}, QStringLiteral("OTHER"));
    QCOMPARE(app.readTicket(cmd.ticketId, outside).code, ApplicationCode::NotFound);
    QSqlQuery altered(QSqlDatabase::database(connection));
    QVERIFY(altered.exec(QStringLiteral("UPDATE tickets SET description = 'changed'")));
    QCOMPARE(app.readTicket(cmd.ticketId, owner).code, ApplicationCode::IntegrityFailure);
    QCOMPARE(app.listQueue(projectId, QStringLiteral("OPEN"), {}, outside).code, ApplicationCode::Forbidden);
    const auto deniedPage = app.listQueue(projectId, QStringLiteral("OPEN"), {}, principal(QStringLiteral("sam"), {Role::Support}));
    QCOMPARE(deniedPage.code, ApplicationCode::IntegrityFailure);
    QVERIFY(deniedPage.page.entries.isEmpty());
}

void ApplicationTest::invalidWorkOrderLeavesNoHistory()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    auto cmd = createCommand(QStringLiteral("W-2"));
    cmd.description = QString(8193, QLatin1Char('x'));
    const auto response = TicketApplication(store).createTicket(cmd,
        principal(QStringLiteral("alice"), {Role::Reporter}), context(QStringLiteral("invalid")));
    QCOMPARE(response.code, ApplicationCode::InvalidCommand);
    QVERIFY(store.auditEvents().isEmpty());
}

void ApplicationTest::unauthenticatedCreateDoesNotWrite()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    AuthenticatedPrincipal anonymous;

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-1")),
        anonymous,
        context(QStringLiteral("evt-app-1")));

    QCOMPARE(response.code, ApplicationCode::Unauthenticated);
    QCOMPARE(store.auditEvents().size(), 0);
    QVERIFY(!store.loadTicket(QStringLiteral("T-APP-1")).has_value());
}

void ApplicationTest::reporterIdentityOwnsCreatedTicket()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-2")),
        principal(QStringLiteral("reporter-2"), {Role::Reporter}),
        context(QStringLiteral("evt-app-2")));

    QVERIFY(response.succeeded());
    QCOMPARE(response.ticket.reporterId, QStringLiteral("reporter-2"));
    QCOMPARE(store.loadTicket(QStringLiteral("T-APP-2"))->reporterId,
             QStringLiteral("reporter-2"));
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::reporterCannotCreateInAnotherProject()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-WRONG-PROJECT")),
        principal(
            QStringLiteral("reporter-other"),
            {Role::Reporter},
            QStringLiteral("PROJECT-OTHER")),
        context(QStringLiteral("evt-app-wrong-project")));

    QCOMPARE(response.code, ApplicationCode::Forbidden);
    QCOMPARE(store.auditEvents().size(), 0);
}

void ApplicationTest::authorizedSupportTransitionPersists()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-AUTHORIZED")),
        principal(QStringLiteral("reporter-authorized"), {Role::Reporter}),
        context(QStringLiteral("evt-app-authorized-create"))).succeeded());

    const ApplicationResult response = application.transitionTicket(
        triage(QStringLiteral("T-APP-AUTHORIZED")),
        principal(QStringLiteral("support-authorized"), {Role::Support}),
        context(QStringLiteral("evt-app-authorized-triage")));

    QVERIFY(response.succeeded());
    QCOMPARE(response.ticket.state, TicketState::Triaged);
    QCOMPARE(response.ticket.version, quint64{2});
    QCOMPARE(store.auditEvents().size(), 2);
    QVERIFY2(store.verifyAudit(&error), qPrintable(error));
}

void ApplicationTest::supportRoleIsProjectScoped()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-SCOPE")),
        principal(QStringLiteral("reporter-scope"), {Role::Reporter}),
        context(QStringLiteral("evt-app-scope-create"))).succeeded());

    const ApplicationResult response = application.transitionTicket(
        triage(QStringLiteral("T-APP-SCOPE")),
        principal(
            QStringLiteral("support-other"),
            {Role::Support},
            QStringLiteral("PROJECT-OTHER")),
        context(QStringLiteral("evt-app-scope-triage")));

    QCOMPARE(response.code, ApplicationCode::Forbidden);
    QCOMPARE(response.decisionCode, DecisionCode::MissingRole);
    QCOMPARE(store.loadTicket(QStringLiteral("T-APP-SCOPE"))->state, TicketState::Open);
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::clientCannotSupplyActorIdentity()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-3")),
        principal(QStringLiteral("reporter-3"), {Role::Reporter}),
        context(QStringLiteral("evt-app-create-3"))).succeeded());

    const ApplicationResult denied = application.transitionTicket(
        triage(QStringLiteral("T-APP-3")),
        principal(QStringLiteral("agent-3"), {Role::Agent}),
        context(QStringLiteral("evt-app-triage-3")));

    QCOMPARE(denied.code, ApplicationCode::Forbidden);
    QCOMPARE(denied.decisionCode, DecisionCode::MissingRole);
    QCOMPARE(store.loadTicket(QStringLiteral("T-APP-3"))->state, TicketState::Open);
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::invalidTrustedContextDoesNotWrite()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-4")),
        principal(QStringLiteral("reporter-4"), {Role::Reporter}),
        {QStringLiteral("bad event id"), QStringLiteral("2026-11-19T19:32:00-07:00")});

    QCOMPARE(response.code, ApplicationCode::InvalidCommand);
    QCOMPARE(store.auditEvents().size(), 0);
}

void ApplicationTest::malformedAuthenticatedIdentityDoesNotWrite()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    AuthenticatedPrincipal malformed = principal(QStringLiteral("   "), {Role::Reporter});

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-IDENTITY")),
        malformed,
        context(QStringLiteral("evt-app-identity")));

    QCOMPARE(response.code, ApplicationCode::Unauthenticated);
    QCOMPARE(store.auditEvents().size(), 0);
}

void ApplicationTest::oversizedRationaleDoesNotReachDomain()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-5")),
        principal(QStringLiteral("reporter-5"), {Role::Reporter}),
        context(QStringLiteral("evt-app-create-5"))).succeeded());
    TransitionTicketCommand command = triage(QStringLiteral("T-APP-5"));
    command.rationale = QString(2049, QLatin1Char('x'));

    const ApplicationResult response = application.transitionTicket(
        command,
        principal(QStringLiteral("support-5"), {Role::Support}),
        context(QStringLiteral("evt-app-triage-5")));

    QCOMPARE(response.code, ApplicationCode::InvalidCommand);
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::malformedDigestDoesNotReachDomain()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-6")),
        principal(QStringLiteral("reporter-6"), {Role::Reporter}),
        context(QStringLiteral("evt-app-create-6"))).succeeded());
    TransitionTicketCommand command = triage(QStringLiteral("T-APP-6"));
    command.artifactDigest = QStringLiteral("sha256:not-a-digest");

    const ApplicationResult response = application.transitionTicket(
        command,
        principal(QStringLiteral("support-6"), {Role::Support}),
        context(QStringLiteral("evt-app-triage-6")));

    QCOMPARE(response.code, ApplicationCode::InvalidCommand);
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::staleVersionBecomesConflict()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-7")),
        principal(QStringLiteral("reporter-7"), {Role::Reporter}),
        context(QStringLiteral("evt-app-create-7"))).succeeded());
    TransitionTicketCommand command = triage(QStringLiteral("T-APP-7"));
    command.expectedVersion = 77;

    const ApplicationResult response = application.transitionTicket(
        command,
        principal(QStringLiteral("support-7"), {Role::Support}),
        context(QStringLiteral("evt-app-triage-7")));

    QCOMPARE(response.code, ApplicationCode::Conflict);
    QCOMPARE(response.decisionCode, DecisionCode::StaleVersion);
    QCOMPARE(store.auditEvents().size(), 1);
}

void ApplicationTest::storageDiagnosticIsNotPublic()
{
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    const auto reporter = principal(QStringLiteral("reporter-8"), {Role::Reporter});
    const auto duplicate = context(QStringLiteral("evt-app-duplicate"));
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-8A")), reporter, duplicate).succeeded());

    const ApplicationResult response = application.createTicket(
        createCommand(QStringLiteral("T-APP-8B")), reporter, duplicate);

    QCOMPARE(response.code, ApplicationCode::StorageFailure);
    QVERIFY(response.operatorDiagnostic.contains(QStringLiteral("UNIQUE constraint failed")));
    QVERIFY(!response.publicMessage.contains(QStringLiteral("UNIQUE")));
    QVERIFY(!store.loadTicket(QStringLiteral("T-APP-8B")).has_value());
}

void ApplicationTest::auditCorruptionBecomesIntegrityFailure()
{
    const QString connectionName = QStringLiteral("application-integrity-test");
    TicketStore store(QStringLiteral(":memory:"), QByteArray(auditKey), connectionName);
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    TicketApplication application(store);
    QVERIFY(application.createTicket(
        createCommand(QStringLiteral("T-APP-9")),
        principal(QStringLiteral("reporter-9"), {Role::Reporter}),
        context(QStringLiteral("evt-app-create-9"))).succeeded());
    QSqlDatabase database = QSqlDatabase::database(connectionName);
    QSqlQuery tamper(database);
    QVERIFY(tamper.exec(QStringLiteral(
        "UPDATE audit_events SET canonical_payload = X'00' WHERE sequence = 1")));

    const ApplicationResult response = application.transitionTicket(
        triage(QStringLiteral("T-APP-9")),
        principal(QStringLiteral("support-9"), {Role::Support}),
        context(QStringLiteral("evt-app-triage-9")));

    QCOMPARE(response.code, ApplicationCode::IntegrityFailure);
    QCOMPARE(response.publicMessage, QStringLiteral("integrity verification failed"));
    QVERIFY(response.operatorDiagnostic.contains(QStringLiteral("audit chain")));
    QCOMPARE(store.loadTicket(QStringLiteral("T-APP-9"))->state, TicketState::Open);
    database = QSqlDatabase();
}

QTEST_APPLESS_MAIN(ApplicationTest)

#include "test_application.moc"
