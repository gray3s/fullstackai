// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "Packet.h"
#include "aieng/application/TicketApplication.h"
#include <QCoreApplication>
#include <QJsonArray>
#include <QDateTime>
#include <QFile>
#include <QUuid>
#include <sys/stat.h>
#include <unistd.h>

using namespace aieng::application;
using namespace aieng::domain;

static QString newId()
{
    return QUuid::createUuid().toString(QUuid::WithoutBraces);
}

int main(int argc, char **argv)
{
    QCoreApplication process(argc, argv);
    const auto args = process.arguments();
    const bool supportConfigured = args.size() == 6 && args[4] == "--support-uid";
    if (args.size() != 4 && !supportConfigured) return 2;
    uint supportUid = 0;
    if (supportConfigured) {
        bool valid = false;
        supportUid = args[5].toUInt(&valid);
        if (!valid || args[5] != QString::number(supportUid)) return 2;
    }
    umask(0077);
    constexpr int fd = STDIN_FILENO;
    ucred peer{};
    socklen_t length = sizeof(peer);
    sockaddr_storage address{};
    socklen_t addrLength = sizeof(address);
    int type = 0;
    socklen_t typeLength = sizeof(type);
    if (getpeername(fd, reinterpret_cast<sockaddr *>(&address), &addrLength) != 0
        || address.ss_family != AF_UNIX || getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &typeLength) != 0
        || type != SOCK_SEQPACKET || getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &peer, &length) != 0
        || peer.pid <= 0 || !intake::setTimeouts(fd)) return 2;
    const auto request = intake::receivePacket(fd);
    const auto op = request.value("op").toString();
    const bool create = op == "create" && request.size() == 3
        && request.value("summary").isString() && request.value("description").isString();
    const bool show = op == "show" && request.size() == 2 && request.value("id").isString();
    const bool list = op == "list" && request.size() == 3 && request.value("state").isString() && request.value("after").isString();
    const bool supportAction = op == "triage" || op == "queue";
    bool versionValid = false;
    const auto versionText = request.value("version").toString();
    const auto version = versionText.toULongLong(&versionValid);
    const bool transition = supportAction && request.size() == 4 && request.value("id").isString()
        && request.value("rationale").isString() && versionValid && version > 0 && QString::number(version) == versionText;
    if (!create && !show && !transition && !list) {
        intake::sendPacket(fd, {{"error", "Invalid ticket request"}});
        return 1;
    }
    const bool support = supportConfigured && peer.uid == supportUid;
    if ((transition || list) && !support) {
        intake::sendPacket(fd, {{"error", "Project support access required"}});
        return 1;
    }
    QFile key(args[2]);
    struct stat info{};
    if (!key.open(QIODevice::ReadOnly) || fstat(key.handle(), &info) != 0 || !S_ISREG(info.st_mode)
        || (info.st_mode & 0077) != 0 || info.st_size != 32) return 2;
    TicketStore store(args[1], key.read(33));
    QString error;
    if (!store.open(&error)) {
        intake::sendPacket(fd, {{"error", "Ticket storage is unavailable"}});
        return 1;
    }
    AuthenticatedPrincipal principal;
    principal.subject = QStringLiteral("local-uid-%1").arg(peer.uid);
    principal.trustDomain = QStringLiteral("local-unix");
    principal.projectRoles[args[3]].insert(Role::Reporter);
    if (support) principal.projectRoles[args[3]].insert(Role::Support);
    principal.authenticated = true;
    TicketApplication app(store);
    const TrustedCommandContext context{newId(), QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs)};
    const auto ticketId = request.value("id").toString();
    ApplicationResult response;
    if (create) {
        response = app.createTicket({newId(), args[3], request.value("summary").toString(), request.value("description").toString()},
                                    principal, context);
    } else if (list) {
        response = app.listQueue(args[3], request.value("state").toString(), request.value("after").toString(), principal);
    } else if (show) {
        response = app.readTicket(ticketId, principal);
    } else {
        const auto target = op == "triage" ? TicketState::Triaged : TicketState::AgentQueued;
        response = app.transitionTicket({ticketId, target, version, request.value("rationale").toString(), {}}, principal, context);
    }
    if (!response.succeeded()) {
        intake::sendPacket(fd, {{"error", response.publicMessage}});
        return 1;
    }
    const auto &ticket = response.ticket;
    if (list) {
        QJsonArray entries;
        for (const auto &entry : response.page.entries) {
            entries.append(QJsonObject{{"id", entry.id}, {"summary", entry.summary}, {"version", QString::number(entry.version)}});
        }
        return intake::sendPacket(fd, {{"tickets", entries}, {"next_after", response.page.nextAfter}}) ? 0 : 1;
    }
    return intake::sendPacket(fd, {{"id", ticket.id}, {"state", Workflow::stateName(ticket.state)},
        {"version", QString::number(ticket.version)}, {"project", ticket.projectId},
        {"summary", ticket.summary}, {"description", ticket.description}}) ? 0 : 1;
}
