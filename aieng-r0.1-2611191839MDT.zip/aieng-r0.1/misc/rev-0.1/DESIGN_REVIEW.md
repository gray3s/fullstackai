# AIEng Rev 0.1 | Proof-of-concept design review

**19 November 2026 · Samuel A. Gray III · Product baseline `29c6c56`**

**Verdict.** Codex built a working slice of an engineering platform from a product brief. A staff member can report a defect in a Qt form.
Support can triage it, find it in the correct project, and queue it for repair. The release example picks up there and demonstrates how to
test, deploy and roll back a fix. This is enough to evaluate the idea and the collaboration. Corporate rollout is a later decision.

## What competent vibecoding looks like

“Set aside enough cartons for 25 items, 12 per carton.” The first C++ program returned two. It compiled and passed the easy case of 24.
The clerk supplied the missing acceptance test: one item left over still needs a box. Codex turned that observation into a ticket, a
one-line candidate fix, boundary tests and a repeatable release rehearsal.

The candidate returned three. The rehearsal rejected the old binary when given the candidate's digest, activated the exact tested bytes in
a local production directory, rolled back to the old answer, then restored the fix. AIEng handled the real ticket through AGENT_QUEUED.
The subsequent steps used a supplied patch and scripted approval. [Try the example](carton-count/README.md) · [See the run](carton-count/RUN_RECORD.md)

## Who decides what

Codex can choose a reversible implementation, build it, test failure cases, preserve a checkpoint and show its work. The owner supplies
business intent. If two orders can share a carton, two orders of six need one box. If they ship separately, they need two. I would ask
the warehouse owner before changing that rule. Choosing an integer formula or adding a regression test can proceed independently.

## Engineering judgment

The native C++20/Qt 6 client talks to a local Ubuntu service. The service identifies the Unix user, checks project roles, and commits ticket
changes and audit events together in SQLite. Four test suites cover the staff form and socket, workflow and storage, application commands,
and identity policy. The design targets C, C++, C# and Qt development through Qt Creator. The standalone staff form works today.

One concrete finding merits fixing before live approvals: a developer who also holds the QA role can approve their own patch at the QA step.
Release approval already excludes both the patch author and QA approver. Other open work includes exclusive worker claims, isolated local
agent builds, corporate login, signed artifacts and a production deployment runner. The next product demonstration should take a queued
AIEng defect through an isolated worker and hand its candidate to an independent QA reviewer.

## Near-term future revision

Start DTA (Decision-Tree Analysis) and DTE (Decision-Tree Engine) integration at that QA handoff. Freeze the original requirement, record
what each test proves, and keep missing or conflicting evidence visible. Run DTE in shadow mode first. Claim conformance for this decision
only after a separate runner reproduces the canonical result from identical frozen inputs. Human reviewers retain release authority.
[Future-revision QA plan](../../docs/QA_PLAN.md)

Copyright © 2026 Samuel A. Gray III. All rights reserved.
