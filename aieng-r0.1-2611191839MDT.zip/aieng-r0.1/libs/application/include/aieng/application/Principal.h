// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include "aieng/domain/Workflow.h"

#include <QHash>
#include <QSet>
#include <QString>

namespace aieng::application {

struct AuthenticatedPrincipal final {
    QString subject;
    QHash<QString, QSet<domain::Role>> projectRoles;
    QSet<domain::Role> platformRoles;
    QString trustDomain;
    bool authenticated{false};

    [[nodiscard]] QSet<domain::Role> rolesForProject(const QString &projectId) const
    {
        return projectRoles.value(projectId);
    }
};

} // namespace aieng::application
