# Independent QA admission

The service now receives the reviewer's candidate, verifies its SHA-256 and stores the exact bytes in the SQLite transaction that
advances the ticket to QA_RUNNING. The maximum file size is 16 MiB. Inputs are inert throughout admission.

All four suites passed in debug, ASan/UBSan and hardened release. The release hardening and no-Python checks passed. The first domain
run caught two validation-order changes. The corrected policy preserves the existing digest diagnostics and enforces human independence.
The Unix socket suite rejected a real same-UID self-review, a different project, the worker endpoint, swapped bytes, stale submission,
a symlink and a FIFO. A native fixture supplied a different author's proposal for the positive test on this single-login host. A fresh
process reopened and verified the 90,001 candidate bytes, authenticated ticket state and audit chain.

The protocol establishes custody and starts QA. Next, expose a conventional human proposal path with worker pickup disabled and record
the operating model of each version. Byte-verified QA checkout and retention of test evidence are subsequent engineering steps.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
