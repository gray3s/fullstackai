# Human repair with optional worker pickup

With no worker listener, a human developer proposed the SHA-256 of a local file over the native socket. A support-only client was refused.
With the worker enabled, a developer could not displace an active claim. A controlled-clock store test then showed that a developer could
finish abandoned work at the exact expiry boundary. The original lease implementation had also blocked the developer after expiry.

The four suites passed in debug, ASan/UBSan and hardened release. Release hardening and the no-Python gate passed.
See the version operating model for demonstrated runtime authority, conventional operation and criteria for a future active agent.
The next experiment is a complete local deployment of Carton Count. Verify service-held candidate bytes, independent QA and release
identities, a working installed executable, a rejected substitution and a recoverable prior version. Record rehearsal-only identities.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
