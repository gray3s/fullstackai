qt_add_executable(aieng_application_tests
    test_application.cpp
)

target_link_libraries(aieng_application_tests
    PRIVATE
        aieng_application
        aieng_warnings
        aieng_security_flags
        Qt6::Sql
        Qt6::Test
)

add_test(NAME aieng.application COMMAND aieng_application_tests)

qt_add_executable(aieng_identity_policy_tests
    test_identity_policy.cpp
)

target_link_libraries(aieng_identity_policy_tests
    PRIVATE
        aieng_application
        aieng_warnings
        aieng_security_flags
        Qt6::Test
)

add_test(NAME aieng.identity_policy COMMAND aieng_identity_policy_tests)
