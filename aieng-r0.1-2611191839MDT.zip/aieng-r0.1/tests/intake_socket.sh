#!/usr/bin/env bash
# Copyright © 2026 Samuel A. Gray III. All rights reserved.
set -euo pipefail
umask 077
client=$1
service=$2
scratch=$(mktemp -d)
openssl rand -out "$scratch/key" 32
systemd-socket-activate --seqpacket --accept --inetd -l "$scratch/socket" \
    "$service" "$scratch/db" "$scratch/key" sample >"$scratch/log" 2>&1 &
listener=$!
listeners=("$listener")
cleanup() {
    for pid in "${listeners[@]}"; do
        kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
    done
    rm -f -- "$scratch/support" "$scratch/other" "$scratch/mismatch" "$scratch/socket" "$scratch/db" "$scratch/db-wal" "$scratch/db-shm" "$scratch/key" "$scratch/log"
    rmdir -- "$scratch"
}
trap cleanup EXIT
trap 'cat "$scratch/log" >&2' ERR
for (( i=0; i<100; i++ )); do
    [[ -S "$scratch/socket" ]] && break
    kill -0 "$listener"
    sleep 0.03
done
order=$(printf '%s\n' 'Select Build.' 'The window closes.' | "$client" "$scratch/socket" create "Build window closes")
id=$(jq -er '.id | select(length == 36)' <<< "$order")
saved=$("$client" "$scratch/socket" show "$id")
jq -e '.project == "sample" and .state == "OPEN" and .summary == "Build window closes" and .description == "Select Build.\nThe window closes.\n"' <<< "$saved"
if "$client" "$scratch/socket" show nonexistent; then exit 1; fi
QT_QPA_PLATFORM=offscreen AIENG_TEST_SOCKET="$scratch/socket" "$3"
if "$client" "$scratch/socket" triage "$id" 1 <<< "Reviewed the report"; then exit 1; fi
support_listener() {
    systemd-socket-activate --seqpacket --accept --inetd -l "$scratch/$1" \
        "$service" "$scratch/db" "$scratch/key" "$2" --support-uid "$3" >>"$scratch/log" 2>&1 &
    local pid=$!
    listeners+=("$pid")
    for (( i=0; i<100; i++ )); do
        [[ -S "$scratch/$1" ]] && return 0
        kill -0 "$pid"
        sleep 0.03
    done
    return 1
}
test_uid=$(id -u)
support_listener mismatch sample "$((test_uid == 0 ? 1 : 0))"
if denied=$("$client" "$scratch/mismatch" triage "$id" 1 <<< "Reviewed the report" 2>&1); then exit 1; fi
jq -e '.error == "Project support access required"' <<< "$denied"
support_listener other unrelated "$test_uid"
if "$client" "$scratch/other" triage "$id" 1 <<< "Reviewed the report"; then exit 1; fi
support_listener support sample "$test_uid"
"$client" "$scratch/support" triage "$id" 1 <<< "Reproduced build failure" | jq -e '.state == "TRIAGED" and .version == "2"'
if "$client" "$scratch/support" queue "$id" 1 <<< "Assigned for repair"; then exit 1; fi
"$client" "$scratch/support" queue "$id" 2 <<< "Assigned for repair" | jq -e '.state == "AGENT_QUEUED" and .version == "3"'
"$client" "$scratch/socket" show "$id" | jq -e '.state == "AGENT_QUEUED" and .version == "3"'
if "$client" "$scratch/socket" list AGENT_QUEUED; then exit 1; fi
if "$client" "$scratch/support" list INVALID; then exit 1; fi
"$client" "$scratch/other" list AGENT_QUEUED | jq -e '.tickets == []'
"$client" "$scratch/support" list AGENT_QUEUED | jq -e --arg id "$id" '.tickets == [{id:$id,summary:"Build window closes",version:"3"}]'
for (( i=0; i<26; i++ )); do
    "$client" "$scratch/socket" create "Pagination $i" <<< "Sample report" >/dev/null
done
page=$("$client" "$scratch/support" list OPEN)
cursor=$(jq -er 'select((.tickets | length) == 25 and .next_after == .tickets[-1].id) | .next_after' <<< "$page")
"$client" "$scratch/support" list OPEN "$cursor" | jq -e --arg cursor "$cursor" \
    '(.tickets|length) >= 1 and all(.tickets[]; .id > $cursor) and .next_after == ""'
