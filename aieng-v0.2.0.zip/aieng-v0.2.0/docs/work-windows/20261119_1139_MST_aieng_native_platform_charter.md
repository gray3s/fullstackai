# AIEng Native Platform — Five-Hour Work-Window Charter

**Created:** 2026-11-19 11:39 MST  
**Owner:** Samuel A. Gray III  
**Active project:** `/home/sag/aieng`  
**Status at creation:** architecture draft exists; native implementation not yet verified

## Decisions and terminology

- `AIEng` is a secure Ubuntu client-server engineering and DevSecOps platform.
- Product implementation is native C++/Qt 6 with CMake. C is permitted where
  technically appropriate; C# is a supported guest toolchain, not the control
  plane implementation language.
- The no-Python rule is absolute inside this repository. External algorithm
  experimentation is allowed only when translated before admission.
- The local AI is a proposal-only principal. It cannot approve QA, authorize a
  release, acquire production credentials, deploy, or roll back production.
- A `checkpoint` is a verified Git commit plus a timestamped resume record.
- The December 2026 “looking glass” is a product-planning viewpoint, not a
  claim of real predictive access.
- `Reflexive QA` means AIEng develops and verifies itself through the same
  governed evidence pipeline it generates for other projects; it never means
  that an agent may certify or approve itself.
- Substantial implementation follows a dated primary-source research baseline,
  not product-memory assumptions.

## Project hierarchy and evidence authority

- Active implementation: `/home/sag/aieng`.
- Native reference authority (read-only):
  `/home/sag/RPA2/codex/flowisecpp` and
  `/home/sag/RPA2/codex/localAI/hybridAI`.
- Supporting system assets (read-only unless separately authorized): local
  llama.cpp binaries/models under `/home/sag/RPA2/devneutral`.
- Out of scope: modifying FlowiseCPP, HybridAI, chess projects, CarCase,
  system-wide packages, production networks, external repositories, and any
  corporate production environment.
- The existing Python draft in AIEng is failed/unaccepted evidence and must be
  removed before native implementation is admitted.

## Goals for this work window

1. Establish the native C++20/Qt 6 repository, build graph, strict warnings,
   test harness, and no-Python compliance gate.
2. Implement and test the security-critical workflow domain: ticket creation,
   deterministic state transitions, role authorization, optimistic versions,
   separation of duties, canonical serialization, and chained audit records.
3. Establish native service boundaries for the control daemon, local agent,
   developer desktop/client, and isolated build runner.
4. Provide reproducible Ubuntu bootstrap/build/test/install procedures without
   making unverified production-readiness claims.
5. Create regular verified Git checkpoints and a terminal resume checkpoint.

## Ordered implementation steps

1. Purge Python artifacts, packaging, invocations, and the partial venv.
2. Inventory installed CMake/Qt/compiler/crypto/database capabilities.
3. Complete primary-source research and architecture decision records.
4. Create CMake targets: domain library, control daemon, agent daemon, desktop
   client, sandbox runner, and QtTest suites.
5. Implement immutable domain types and the policy-owned state machine.
6. Implement SQLite persistence and tamper-evident chained audit storage using
   QtSql and cryptographic hashes/HMAC where the installed native stack allows.
7. Add Qt HTTP/IPC surface based on available Qt components; fail closed when
   authentication is not configured.
8. Add tests for denied agent promotion, stale updates, invalid transitions,
   separation of duties, persistence, and audit-chain verification.
9. Run configure/build/test/static scans/no-Python audit; preserve failures.
10. Commit a verified checkpoint and update the resume record.

## Acceptance evidence

- `cmake -S . -B build` and strict native build complete successfully.
- `ctest --test-dir build --output-on-failure` passes all admitted tests.
- Negative authorization and workflow tests demonstrate fail-closed behavior.
- Audit-chain verification detects a deliberately changed historical payload.
- `scripts/no-python-check.sh` reports no forbidden artifacts or invocations.
- Git status and checkpoint commit identify exactly what is preserved.
- Runtime services that cannot yet be verified are labeled scaffolds, not
  represented as production-ready.

## Boundaries and stop conditions

- No Python; no Node/TypeScript control plane; no cloud AI requirement.
- No deployment to QA or production, package installation, firewall change,
  user-account change, external push, or production credential handling in
  this window.
- Before any action that could risk the system-drive CarCase project, verify a
  current, readable Lexar mirror. Do not use the Lexar swap partition or the
  CarCase mirror as AIEng scratch/build/VM storage.
- Do not weaken TLS, authentication, authorization, audit, or approval gates to
  make a demo run.
- Stop a component when a required native dependency is absent; record the
  blocker and continue on independently verifiable work.
- Never let a model-generated string become a shell command. The future runner
  uses deterministic executable/argument allowlists and isolated identities.

## Expected blockers

- Docker is absent on this host.
- Qt HttpServer or other optional modules may be absent.
- Production PKI, corporate IdP, registry, forge, and deployment endpoints are
  intentionally unavailable and must remain adapters/interfaces.

## Terminal deliverables

- Native source/build/test baseline with evidence.
- Updated architecture and operator/developer guidance.
- One or more verified Git checkpoints.
- Timestamped resume checkpoint stating current truth and next authorized step.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

