// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/application/IdentityPolicy.h"

#include <QTest>

#include <limits>

using namespace aieng::application;
using namespace aieng::domain;

namespace {

constexpr qint64 now = 1'795'113'600;
const QString projectId = QStringLiteral("PROJECT-1");

[[nodiscard]] IdentityPolicyConfig config()
{
    IdentityPolicyConfig value;
    value.issuer = QStringLiteral("https://id.example.invalid/realms/aieng");
    value.audience = QStringLiteral("aieng-control-api");
    value.allowedAlgorithms = {QStringLiteral("PS256"), QStringLiteral("ES256")};
    value.groupRoles.insert(
        QStringLiteral("/aieng/reporters"),
        ProjectRoleGrant{projectId, QSet<Role>{Role::Reporter}});
    value.groupRoles.insert(
        QStringLiteral("/aieng/support"),
        ProjectRoleGrant{projectId, QSet<Role>{Role::Support}});
    value.groupRoles.insert(
        QStringLiteral("/aieng/qa"),
        ProjectRoleGrant{projectId, QSet<Role>{Role::Qa}});
    value.groupRoles.insert(
        QStringLiteral("/aieng/release"),
        ProjectRoleGrant{projectId, QSet<Role>{Role::Release}});
    value.privilegedAuthenticationContext = QStringLiteral("aieng-webauthn-step-up");
    return value;
}

[[nodiscard]] CryptographicallyVerifiedClaims verifiedClaims()
{
    CryptographicallyVerifiedClaims value;
    value.tokenType = QStringLiteral("at+jwt");
    value.algorithm = QStringLiteral("PS256");
    value.keyId = QStringLiteral("signing-key-2026-11");
    value.issuer = QStringLiteral("https://id.example.invalid/realms/aieng");
    value.subject = QStringLiteral("staff-123");
    value.audiences = {QStringLiteral("aieng-control-api")};
    value.groups = {QStringLiteral("/aieng/support")};
    value.issuedAtEpochSeconds = now - 60;
    value.notBeforeEpochSeconds = now - 60;
    value.expiresAtEpochSeconds = now + 300;
    value.authenticatedAtEpochSeconds = now - 60;
    value.authenticationContext = QStringLiteral("ordinary-login");
    value.confirmationThumbprint = QStringLiteral("dpop-jwk-thumbprint");
    value.signatureVerified = true;
    value.duplicateMembersRejected = true;
    value.senderProofVerified = true;
    return value;
}

} // namespace

class IdentityPolicyTest final : public QObject {
    Q_OBJECT

private slots:
    void acceptsVerifiedMappedIdentity();
    void rejectsInvalidPolicyConfiguration();
    void rejectsMissingCryptographicVerification();
    void rejectsAlgorithmConfusion();
    void rejectsWrongTokenType();
    void rejectsIssuerMixUp();
    void rejectsWrongAudience();
    void rejectsExpiredAndFutureTokens();
    void rejectsExcessiveLifetime();
    void ignoresUnknownGroupsWithoutEscalation();
    void rejectsUnmappedIdentity();
    void rejectsMissingSenderProof();
    void privilegedRoleRequiresRecentStepUp();
    void hostileExtremeTimesFailWithoutOverflow();
};

void IdentityPolicyTest::acceptsVerifiedMappedIdentity()
{
    const IdentityDecision decision = IdentityPolicy(config()).evaluate(verifiedClaims(), now);
    QVERIFY(decision.accepted());
    QVERIFY(decision.principal.authenticated);
    QCOMPARE(decision.principal.subject, QStringLiteral("staff-123"));
    QCOMPARE(decision.principal.trustDomain,
             QStringLiteral("https://id.example.invalid/realms/aieng"));
    QCOMPARE(decision.principal.rolesForProject(projectId), QSet<Role>{Role::Support});
}

void IdentityPolicyTest::rejectsInvalidPolicyConfiguration()
{
    auto invalid = config();
    invalid.allowedAlgorithms = {QStringLiteral("none")};
    QCOMPARE(
        IdentityPolicy(invalid).evaluate(verifiedClaims(), now).code,
        IdentityDecisionCode::ConfigurationInvalid);

    invalid = config();
    invalid.allowedClockSkewSeconds = -1;
    QCOMPARE(
        IdentityPolicy(invalid).evaluate(verifiedClaims(), now).code,
        IdentityDecisionCode::ConfigurationInvalid);
}

void IdentityPolicyTest::rejectsMissingCryptographicVerification()
{
    auto claims = verifiedClaims();
    claims.signatureVerified = false;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::VerificationMissing);
    claims.signatureVerified = true;
    claims.duplicateMembersRejected = false;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::VerificationMissing);
}

void IdentityPolicyTest::rejectsAlgorithmConfusion()
{
    auto claims = verifiedClaims();
    claims.algorithm = QStringLiteral("none");
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::AlgorithmRejected);
}

void IdentityPolicyTest::rejectsWrongTokenType()
{
    auto claims = verifiedClaims();
    claims.tokenType = QStringLiteral("JWT");
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::WrongTokenType);
}

void IdentityPolicyTest::rejectsIssuerMixUp()
{
    auto claims = verifiedClaims();
    claims.issuer = QStringLiteral("https://attacker.invalid/realms/aieng");
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::IssuerMismatch);
}

void IdentityPolicyTest::rejectsWrongAudience()
{
    auto claims = verifiedClaims();
    claims.audiences = {QStringLiteral("some-other-api")};
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::AudienceMismatch);
}

void IdentityPolicyTest::rejectsExpiredAndFutureTokens()
{
    auto expired = verifiedClaims();
    expired.expiresAtEpochSeconds = now - 31;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(expired, now).code,
        IdentityDecisionCode::TimeInvalid);

    auto future = verifiedClaims();
    future.issuedAtEpochSeconds = now + 31;
    future.notBeforeEpochSeconds = now + 31;
    future.expiresAtEpochSeconds = now + 331;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(future, now).code,
        IdentityDecisionCode::TimeInvalid);
}

void IdentityPolicyTest::rejectsExcessiveLifetime()
{
    auto claims = verifiedClaims();
    claims.expiresAtEpochSeconds = claims.issuedAtEpochSeconds + 901;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::LifetimeExceeded);
}

void IdentityPolicyTest::ignoresUnknownGroupsWithoutEscalation()
{
    auto claims = verifiedClaims();
    claims.groups.insert(QStringLiteral("/unrelated/system-admins"));
    const IdentityDecision decision = IdentityPolicy(config()).evaluate(claims, now);
    QVERIFY(decision.accepted());
    QCOMPARE(decision.principal.rolesForProject(projectId), QSet<Role>{Role::Support});
}

void IdentityPolicyTest::rejectsUnmappedIdentity()
{
    auto claims = verifiedClaims();
    claims.groups = {QStringLiteral("/unrelated/users")};
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::NoMappedRole);
}

void IdentityPolicyTest::rejectsMissingSenderProof()
{
    auto claims = verifiedClaims();
    claims.senderProofVerified = false;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::SenderProofRequired);
}

void IdentityPolicyTest::privilegedRoleRequiresRecentStepUp()
{
    auto claims = verifiedClaims();
    claims.groups = {QStringLiteral("/aieng/qa")};
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::PrivilegedAuthenticationRequired);

    claims.authenticationContext = QStringLiteral("aieng-webauthn-step-up");
    QVERIFY(IdentityPolicy(config()).evaluate(claims, now).accepted());

    claims.authenticatedAtEpochSeconds = now - 301;
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::PrivilegedAuthenticationRequired);
}

void IdentityPolicyTest::hostileExtremeTimesFailWithoutOverflow()
{
    auto claims = verifiedClaims();
    claims.issuedAtEpochSeconds = std::numeric_limits<qint64>::max();
    claims.notBeforeEpochSeconds = std::numeric_limits<qint64>::max();
    claims.expiresAtEpochSeconds = std::numeric_limits<qint64>::max();
    QCOMPARE(
        IdentityPolicy(config()).evaluate(claims, now).code,
        IdentityDecisionCode::TimeInvalid);
}

QTEST_APPLESS_MAIN(IdentityPolicyTest)

#include "test_identity_policy.moc"
