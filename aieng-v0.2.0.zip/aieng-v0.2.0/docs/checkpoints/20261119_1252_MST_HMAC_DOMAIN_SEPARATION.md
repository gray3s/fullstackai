# AIEng HMAC Domain-Separation Checkpoint

**Recorded:** 2026-11-19 12:52 MST  
**Owner:** Samuel A. Gray III

The ticket store now derives separate 256-bit HMAC subkeys from its injected
master secret with versioned purpose labels for `audit-chain/v1` and
`ticket-row/v1`. Audit events and current-row integrity tags no longer reuse
the same key material across protocols.

Strict debug, ASan/UBSan, and hardened release builds and all three CTest
targets passed. The domain test also proves that the injected master bytes do
not directly verify the stored audit chain. The no-Python gate passed;
LeakSanitizer remains pending outside ptrace and is not claimed.

No host, VM, package, CarCase, Lexar, network, or external-system state changed.
Production key custody, rotation, zeroization, and recovery remain future
requirements; domain separation does not solve them.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
