# AIEng Identity Policy Gate Checkpoint

**Recorded:** 2026-11-19 12:42 MST  
**Owner:** Samuel A. Gray III

## Preserved result

- Added a native, transport-independent identity authorization policy.
- Exact issuer, resource audience, explicit access-token type, signing
  algorithm allowlist, verified key identity, and bounded subject/group claims
  are mandatory.
- Issued-at, not-before, expiry, clock skew, and maximum lifetime checks fail
  closed and avoid signed arithmetic overflow on hostile extreme values.
- Only exact configured group names map to roles. Unknown groups confer no
  authority, and an identity with no mapped role is rejected.
- Production-default policy requires a sender-constrained token proof.
- QA, release, operator, and administrator roles additionally require the exact
  configured step-up authentication context and a recent authentication time.
- Missing signature verification or duplicate-JSON-member rejection prevents
  principal creation.
- Raw JWT/JWS/JWK/DPoP parsing and cryptography are intentionally absent. ADR
  0003 forbids a custom implementation and defines a dependency admission gate.
- No identity or JWT package was installed or selected.

## Verification evidence

- Three CTest targets passed in strict debug, ASan/UBSan, and hardened release
  presets: domain/store, application boundary, and identity policy.
- Total local QtTest phases: 48 passed, 0 failed, 0 skipped.
- Identity tests cover missing verification, duplicate-member rejection,
  algorithm confusion, token substitution, issuer mix-up, wrong audience,
  expiry/future/lifetime failures, exact group mapping, sender proof,
  privileged step-up, invalid policy, and extreme times.
- Release binary checks passed for PIE, RELRO, immediate binding, and
  non-executable stack.
- No-Python artifact/invocation audit passed.
- `git diff --check` passed.
- LeakSanitizer remains pending outside ptrace and is not claimed.
- No host package, VM, listener, CarCase file, Lexar partition, or external
  environment was changed.

## Honest current state

The deterministic post-verification policy is tested. Cryptographic token and
DPoP verification are not implemented, so no network identity is accepted by a
running service. A C++ struct populated by a test is not proof of identity; only
a future admitted verifier adapter may populate it in production.

## Next authorized action

Specify the verifier adapter and reusable hostile-token corpus, then qualify a
native JOSE/OAuth implementation in the disposable Ubuntu 26.04 VM. In
parallel, the transport-independent ticket read/query application boundary can
be implemented without admitting a network dependency.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

