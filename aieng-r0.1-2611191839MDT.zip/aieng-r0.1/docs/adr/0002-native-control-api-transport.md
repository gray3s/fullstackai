# ADR 0002: Qualify Drogon as the native control API transport

- Status: proposed; dependency not admitted
- Date: 2026-11-19
- Decision owner: Samuel A. Gray III

## Context

AIEng needs a native C++ control API for ticket intake and governed workflow
commands. The transport accepts untrusted input, so framework convenience is
secondary to isolation, bounded parsing, maintained Ubuntu availability, and
the ability to keep authorization policy out of handlers.

The development host has Qt 6.4.2. Its optional Qt HTTP Server module is not
installed. Current Qt documentation explicitly warns that Qt HTTP Server is
not hardened against network attacks and must not be exposed directly to the
Internet. Its configurable rate, connection, URL, header, and body limits were
added primarily in Qt 6.10 and 6.11, so they are unavailable on this baseline.

Boost.Beast is a low-level HTTP foundation, not an application server. Building
authentication filters, request ceilings, routing, lifecycle management, and
safe defaults directly on it would create a large security-sensitive surface
that AIEng would own.

Drogon is a native C++17/20 framework with routing/filter support, bounded body
and WebSocket configuration, HTTPS support, and asynchronous PostgreSQL
support. Ubuntu packages it, but its upstream repository currently publishes
no SECURITY.md policy. Package availability and feature breadth are useful
signals, not sufficient assurance.

## Proposed decision

Qualify Drogon as the first server-transport candidate in a disposable Ubuntu
26.04 VM. Do not install it on the development host or merge a Drogon-dependent
target until the qualification record passes.

If admitted, the deployment boundary is:

```text
untrusted client
    -> hardened ingress / TLS / coarse request ceilings
    -> loopback or Unix-socket Drogon listener
    -> authentication and schema-validation adapter
    -> typed application command
    -> transport-independent domain policy and transactional store
```

The listener must not be publicly bound. Browser sessions use standards-based
OIDC authorization code flow with PKCE; bearer validation and authorization
are fail-closed. The ingress does not replace application authorization.

## Qualification gate

All of the following evidence is required:

1. Pin an exact candidate version and record source/package hashes, licenses,
   transitive dependencies, Ubuntu support source, and security-update owner.
2. Build with the repository warning and hardening policy; run unit,
   integration, ASan, UBSan, and an out-of-ptrace LeakSanitizer job.
3. Exercise malformed request lines, duplicate/conflicting length headers,
   chunking, oversized URL/header/body/WebSocket input, slow clients,
   cancellation, disconnect, and parser fuzz seeds.
4. Prove finite request, header, body, pipeline, keep-alive, connection,
   thread, temporary-file, memory, and execution-time ceilings.
5. Prove the service binds only to the configured private endpoint, starts
   with no dynamic views or document root, suppresses version disclosure, and
   runs as an unprivileged confined identity.
6. Prove authentication failures, malformed identities, stale tokens, missing
   audiences, and role violations never invoke application commands.
7. Generate an SBOM, vulnerability scan, license report, and signed test
   evidence tied to the candidate digest.
8. Document an upgrade/removal path. The application/domain libraries must
   compile and test without Drogon.

Failure of any mandatory item keeps the dependency unadmitted and triggers a
new candidate review. Qt HTTP Server remains acceptable only for loopback test
fixtures or trusted-device utilities, never for the externally reachable
control API.

## Consequences

- Network development waits for evidence instead of silently blessing a
  convenient framework.
- The current native domain and persistence work continues independently.
- A reverse proxy is defense in depth, not a rationale for exposing an
  unhardened embedded server.
- Framework replacement remains bounded to a transport adapter.

## Primary evidence

- https://doc.qt.io/qt-6/qthttpserver-security.html
- https://doc.qt.io/qt-6/qthttpserver-index.html
- https://github.com/drogonframework/drogon/blob/master/config.example.json
- https://github.com/drogonframework/drogon/blob/master/lib/inc/drogon/HttpAppFramework.h
- https://github.com/drogonframework/drogon/security
- https://www.boost.org/doc/libs/release/libs/beast/doc/html/beast/introduction.html

Copyright © 2026 Samuel A. Gray III. All rights reserved.

