# Security model

## Non-negotiable controls

- OIDC authentication with phishing-resistant MFA for privileged roles.
- Deny-by-default role checks at every API operation.
- AI workers have no production network route or production credential access.
- Patch text is untrusted input; agent output never becomes a shell command.
- Builds execute as non-root in ephemeral sandboxes with dropped capabilities,
  resource limits, read-only roots, and no network unless a policy grants it.
- QA approval and release approval require distinct human identities.
- Protected branches reject direct pushes and require verified CI evidence.
- Artifacts carry SBOM, provenance attestation, vulnerability result, and a
  signature from a hardware- or vault-backed key.
- Audit events form a tamper-evident HMAC chain and are exported off-host.
- Current ticket rows are separately integrity-tagged before they may drive
  project authorization or workflow mutation.
- Audit-chain and ticket-row HMACs use purpose-labeled subkeys derived from the
  injected master secret; one MAC domain never reuses the other's key.
- Human and workload roles are scoped to exact project identifiers; platform
  administration does not imply QA, release, or deployment approval.
- Secrets never enter tickets, prompts, source trees, logs, or model context.

## Roles

| Role | Key permissions |
| --- | --- |
| `reporter` | create and read own tickets |
| `support` | triage and assign tickets |
| `developer` | inspect proposals, create human patches |
| `agent` | claim explicitly queued jobs and submit proposals only |
| `qa` | start QA, record evidence, approve/reject QA |
| `release` | approve a QA-approved immutable artifact for production |
| `operator` | execute an approved deployment/rollback |
| `auditor` | read workflow and audit evidence, mutate nothing |
| `admin` | identity/policy administration; cannot self-approve releases |

Role names are not global ambient authority. Except for explicitly modeled
platform administration/audit capabilities, every binding names one project.
Unknown identity-provider groups are ignored and cross-project use is denied.

## Prompt-injection boundary

Ticket bodies, repositories, tests, build logs, and external documentation are
all untrusted. The model receives a bounded context package. Tool calls are
selected and validated by deterministic code; prose emitted by a model cannot
grant capabilities. Requested file paths are normalized and constrained to the
job workspace. Generated patches are parsed, size-limited, secret-scanned, and
must pass policy gates before a human can review them.

## Deployment prerequisites

The sample Compose environment is a development topology, not a production
security accreditation. Production requires corporate PKI, externally managed
secrets, off-host backups and audit export, vulnerability management, tested
restore/rollback, monitoring, and an organization-specific threat assessment.

