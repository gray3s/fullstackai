#pragma once
#include <QString>
namespace intake {
QString questions(const QString &role);
}
