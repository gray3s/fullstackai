# Project support triage

Resume from 5de3381 in AIEng. Use the native service, client and private Unix socket test as the implementation and evidence sources.
Expose the existing triage and agent-queue transitions to a support UID configured on the project listener. Verify default reporter denial,
authorized writes and stale-version rejection through actual client processes. Keep production and CarCase outside the test environment.
Run the three build presets and no-Python audit, preserve failures and checkpoint the working revision.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
