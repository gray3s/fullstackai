# AIEng working definitions, draft 1

## The question under test

Given a creator's program and intended use, what engineering and operations work does this deployment require?
Can an AI worker identify and perform that work to the same independently assessed standard as a human?
Allow three possible findings at intake: a change is needed, existing evidence is sufficient, or the evidence is insufficient.
Qualifying an already suitable release is engineering work even when the warranted code change is zero.

## Objects and roles

- **Vibecoded project.** For this study, a project whose creator directs implementation principally through natural-language interaction
  with a code-generating model and steers it using feedback on the result. Record who designed, wrote, inspected and tested the code.
  This proposed inclusion criterion describes origin. Quality and readiness are outcomes to measure separately.
- **Engineering work.** Translating intended use into checkable requirements, identifying consequential failure modes, gathering
  evidence and deciding which changes or qualifications the evidence warrants. An engineering worker is the actor assigned that work.
  Whether the actor is human, AI or a team is an experimental variable. A professional credential is a separate fact about a person.
- **Production and deployment.** Production is an environment in which an intended user or downstream process relies on the service for
  an actual task. Deployment installs and activates a specified release on a specified target. A release candidate is the exact artifact
  proposed for that target. The production version is the artifact actually active there, with its effective configuration and dependencies.
  A rehearsal can reproduce deployment mechanics without establishing use under production conditions.
- **Production-ready.** For a particular use and target, the agreed release criteria have sufficient supporting evidence under a named
  policy. Record exceptions, unresolved risks and who may accept them. Readiness, authorization to deploy, actual activation and successful
  operation are four distinct claims.

## Properties and evidence

- **Requirement.** A condition the system is expected to meet, naming when it applies and how to distinguish acceptable outcomes.
  A requirement may permit several outcomes. Record conflicting or missing requirements as questions about intent.
- **Defect (bug) and failure.** A defect is a flaw that can cause a requirement to be violated under an in-scope condition. A failure
  is an occurrence of such a violation. Several failures may have one underlying defect. A bad requirement can itself be a defect in
  the specification. Identifying which artifact is faulty requires an independent basis for the expected behavior.
- **Bug-free.** Every in-scope behavior satisfies the stated requirements. This universal claim becomes precise once the requirements,
  domain and execution assumptions are explicit. One valid counterexample refutes it. Passing sampled tests supports the tested cases.
  Exhaustive checking of a finite domain or a sound proof can establish a bounded claim under its assumptions.
- **Bugginess and reliability.** Report distinct known defects by consequence and observed failures per workload, operation count and
  observation period. Reliability describes the ability to deliver the required service under stated operating conditions over a stated
  interval. A count of reports alone cannot estimate all latent defects or predict a failure rate.
- **Security and vulnerability.** Identify the assets, permitted actions, protection goals, relevant threats and assumptions. A
  vulnerability is a weakness that can lead to a violation of a protection goal. Replace a global security score with concrete claims
  about access, disclosure, integrity or availability. Record which claims were examined, how, and which remain open.
  [NIST information security](https://csrc.nist.gov/glossary/term/information_security) ·
  [NIST vulnerability](https://csrc.nist.gov/glossary/term/vulnerability)
- **Verification and validation.** Verification asks whether the implementation meets specified requirements. Validation asks whether
  the system meets the intended need in its operating context. A rule can be implemented exactly and still solve the wrong problem.
  [NIST verification](https://csrc.nist.gov/glossary/term/verification) · [NIST validation](https://csrc.nist.gov/glossary/term/validation)
- **Resolved.** A reported discrepancy has an identified disposition. For a claimed fix, establish the original failure, identify the
  changed release, repeat the decisive check and record relevant regression evidence. Acceptance of residual risk can close a release
  decision while the technical defect remains open.
- **Without human intervention.** Name the start and end of the trial. Record who set intent and policy beforehand, any human action
  that selected a test, repaired an output, interpreted evidence or approved an action during the run, and who graded it afterward.
  An independent human grade after the run can measure autonomous performance. A human rescue during the run counts as assistance.

## The platform before and after

Assess three subjects separately: the candidate application, the existing host and services, and the combined deployed system.
Before deployment, identify the baseline release, configuration, identities, existing findings, normal workload and observation window.
Measure relevant behavior and access boundaries. Write down which changes installation is expected to introduce.
After activation, repeat the baseline checks with comparable inputs, identities and workload, and test the new application's intended
use and access policy. Classify findings as pre-existing, newly observed, resolved, expected changes or inconclusive. A new service
has no pre-install service behavior to compare; its intended operating contract supplies that reference.

Example: if an existing service had intermittent errors before installation, record the pre- and post-install failure counts and request
counts. If the rate rises, record the regression and investigate changes in workload or configuration. Reproduction or controlled rollback
can strengthen attribution. Similarly, a newly observed account permission may be a required change or a policy violation; the intended
access rule distinguishes the two. An unchanged baseline can still be unacceptable in absolute terms.

## Adjudicating a claim

For each decision, record the subject and version, property, scope, expected result and its source, evidence, assumptions and verdict.
Use **supported within scope**, **refuted**, or **undetermined**. Record **authorized**, **held**, or **declined** separately for release.
A reproducible observation can settle an empirical disagreement. A missing business rule requires a source of intent. Acceptance of
residual risk requires delegated authority. Either a human or an AI can execute a fully specified decision procedure.

In Carton Count, an order of 25 items at 12 per carton refutes the old build's claim to reserve enough cartons when it returns two.
Whether two six-item orders may share one carton is a different question. The shipping policy supplies that answer. For comparative
trials, give both workers the same contract and resources, withhold the grading cases, and permit either to report insufficient evidence.
Score their conclusions against the independent reference and record interventions. This tests the necessity of human engineering
without building the answer into the definition of engineer.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
