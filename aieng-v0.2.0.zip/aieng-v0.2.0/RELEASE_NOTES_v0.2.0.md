# AIEng 0.2.0

Experimental source release prepared November 20, 2026.

## Included

- Native Qt 6 ticket intake and local control plane.
- Support triage, queued worker claims, candidate submission and independent QA admission.
- Separate QA, release and operator workflow identities with candidate digest checks.
- Local Carton Count delivery rehearsal covering a refused candidate substitution, a failed health check, rollback and successful
  reinstallation.
- Developer-guided design intake that asks for the algorithm, purpose, inputs, outputs and behavior, then records failure observations,
  implementation alternatives and deployment constraints.
- Standards crosswalk, stakeholder question bank, project goals and a staged plan for delegated review and decision audit trails.

## Scope and verification

This is a source package. It does not contain compiled binaries or production deployment credentials. The stakeholder concern evaluator
is a draft and is not connected to the CLI or normal release gates. Scoped authenticated subplan delegation and decision-record
enforcement remain planned work.

The source revision packaged is identified in the archive's GitHub commit history. Release packaging did not run the build, QA, security,
or release-check suites. Prior project checkpoints describe earlier local verification; they are not a verification claim for this
release package. Review docs/VERSION_OPERATING_MODEL.md, docs/QA_PLAN.md, and docs/PROJECT_GOALS.md before treating any capability
as deployed or authoritative.

Build prerequisites and development checks are documented in README.md. The package excludes local environment files, credentials,
build output, Git metadata and user-specific untracked files.
