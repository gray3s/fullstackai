# AIEng Self-Security Gates Checkpoint

**Created:** 2026-11-19 12:29 MST  
**Parent checkpoint:** `7e773d1`

## Added

- CMake hardening interface inherited by native code and tests.
- Stack protector, PIE, release `_FORTIFY_SOURCE=3`, RELRO, and immediate symbol
  binding for supported GCC/Clang builds.
- Dedicated ASan+UBSan configure/build/test preset.
- Fail-fast normal, sanitizer, and release verification scripts.
- Full nominal workflow transition-matrix test.
- Missing-artifact negative gate test.
- Durable file-backed database close/reopen and audit verification test.
- SQLite WAL result finalization found by the durable test.

## Acceptance evidence

- `./scripts/verify.sh`: pass.
- `./scripts/security-check.sh`: ASan and UBSan pass all 17 Qt test phases.
- `./scripts/release-check.sh`: release build/tests pass; `readelf` verifies PIE,
  GNU RELRO, `BIND_NOW`, and a non-executable stack.
- `git diff --check`: pass.
- no-Python gate runs first in every verification script: pass.

## Honest limitation

LeakSanitizer aborts under the current ptrace-based command sandbox even after
all test functions pass. The sanitizer script disables leak detection only for
this sandboxed ASan/UBSan run and reports the limitation in its success text.
LeakSanitizer remains a required VM/bare-metal CI gate; it is not recorded as
passing here.

## Failed evidence preserved

The first durable-store test failed because SQLite's `PRAGMA journal_mode=WAL`
result row remained active across migration commit. The implementation now
explicitly finalizes the PRAGMA query before beginning migration. The same
durable test then passed in normal, ASan/UBSan, and release builds.

## Next authorized action

Complete the service-framework and API-boundary ADR, including dependency and
Ubuntu-package inventory, parser/request-limit strategy, TLS topology, OIDC
verification, and fuzz targets. Then implement an authenticated loopback-only
service skeleton with no agent execution capability. LeakSanitizer should run
in the first disposable VM QA runner.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

