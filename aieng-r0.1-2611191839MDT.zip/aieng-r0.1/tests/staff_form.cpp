// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "StaffForm.h"
#include <QApplication>
#include <QClipboard>
#include <QLabel>
#include <QLineEdit>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QTabWidget>
#include <QTest>

class StaffTest final : public QObject {
    Q_OBJECT
private slots:
    void fileCopyAndRetrieve()
    {
        StaffForm ui(qEnvironmentVariable("AIENG_TEST_SOCKET"));
        ui.show();
        auto *tabs = ui.findChild<QTabWidget *>();
        auto *compose = tabs->widget(0);
        auto *lookup = tabs->widget(1);
        auto *file = compose->findChild<QPushButton *>();
        QVERIFY(!file->isEnabled());
        compose->findChild<QLineEdit *>()->setText("Cannot build");
        const QString rejected = QStringLiteral("Build log") + QChar(0x0007);
        compose->findChild<QPlainTextEdit *>()->setPlainText(rejected);
        file->click();
        QTRY_VERIFY(tabs->isEnabled());
        QCOMPARE(tabs->currentIndex(), 0);
        QCOMPARE(compose->findChild<QPlainTextEdit *>()->toPlainText(), rejected);
        QCOMPARE(compose->findChild<QLineEdit *>()->text(), QStringLiteral("Cannot build"));
        compose->findChild<QPlainTextEdit *>()->setPlainText("Select kit.\nBuild stops.");
        QVERIFY(file->isEnabled());
        file->click();
        QTRY_COMPARE(tabs->currentIndex(), 1);
        auto *id = lookup->findChild<QLineEdit *>();
        const auto filedId = id->text();
        QCOMPARE(filedId.size(), 36);
        auto *details = lookup->findChild<QPlainTextEdit *>();
        QVERIFY(details->toPlainText().contains("Build stops."));
        auto buttons = lookup->findChildren<QPushButton *>();
        QCOMPARE(buttons.size(), 2);
        if (!buttons[0]->text().contains("Copy")) buttons.swapItemsAt(0, 1);
        buttons[0]->click();
        QCOMPARE(QApplication::clipboard()->text(), filedId);
        id->setText("missing");
        buttons[1]->click();
        QTRY_VERIFY(tabs->isEnabled());
        QVERIFY(details->toPlainText().isEmpty());
        id->setText(filedId);
        buttons[1]->click();
        QTRY_VERIFY(details->toPlainText().contains("Select kit.\nBuild stops."));
    }
};
QTEST_MAIN(StaffTest)
#include "staff_form.moc"
