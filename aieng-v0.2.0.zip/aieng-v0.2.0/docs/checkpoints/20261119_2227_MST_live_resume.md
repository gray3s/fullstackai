# Live QA experiment resume point
Current product checkpoint 9bc2a23. Pilot goals baseline 023ba9f.
Owner priorities are live QA engineering first and a live worker executing an independently authorized deployment second.
Local trial directory /tmp/aieng-live-qa-nodp5l. Source rehearsal /tmp/tmp.V9zaVw3Fn0. Installed restore prefix /tmp/aieng-installed-Yh1yKP.
The local Ministral 3B worker completed a six-case plan. Preserve plan.raw including its invalid JSON comment and wrong expected values.
Next operation: prepare a diagnostic retry which removes only the trailing comment and leaves all cases and expected answers unchanged.
Then run the frozen probes, ask the model for verdicts, and separately ask it to select an already authorized artifact.
Persist a resume point before each remaining operation. No production host is involved.

Prepared diagnostic replay. Next run the installed-binary restore, frozen probes, verdict and deployment selection with per-step markers.

2026-11-19T22:29:01-07:00 — next: restore the released ticket and verify its candidate bytes

2026-11-19T22:29:01-07:00 — next: retain strict plan rejection and run the six authored cases after removing the trailing JSON comment

2026-11-19T22:29:01-07:00 — next: ask the live QA worker to interpret observations in verdict.prompt

Next operation: replace the initial pilot ranking with the owner-selected live QA and live deployment goals.

Next operation: inspect live inference progress and preserve the raw observations.

Next operation: preserve model inputs, raw plan, normalized diagnostic probes, observations and recovered ticket receipt in the project.

QA interim: three of six predictions correct, zero positive-remainder valid probes, all six observations identical between builds. The installed binaries successfully recovered DEPLOYED v9 and identical candidate bytes from a stopped DB copy. Await final model verdict and independent deployment selection.

Next operation: wait for the running model verdict and release selection, then verify its literal choice.

2026-11-19T22:30:54-07:00 — next: ask the live worker to select an independently approved release for the disposable target

Owner requested stop. Next operation: stop only this bounded local trial if still running, preserve partial output and hand off.

Stopped at owner request. Score the retained verdict output on resume. The live worker did not execute a deployment. The next open test is a worker-requested installation and recovery against a preauthorized digest. No new test should start until the owner resumes.
