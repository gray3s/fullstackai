// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once
#include <QJsonObject>

namespace aieng::domain {
// With no observations, evaluate the plan before work begins. With observations, also verify closure of every required concern.
QJsonObject reviewTeamPlan(const QJsonObject &plan, const QJsonObject *observations = nullptr);
}
