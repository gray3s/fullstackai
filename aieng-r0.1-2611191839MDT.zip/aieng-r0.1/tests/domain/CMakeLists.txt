qt_add_executable(aieng_domain_tests
    test_domain.cpp
)

target_link_libraries(aieng_domain_tests
    PRIVATE
        aieng_domain
        aieng_warnings
        aieng_security_flags
        Qt6::Test
)

add_test(NAME aieng.domain COMMAND aieng_domain_tests)

