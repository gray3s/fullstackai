// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/AuditChain.h"
#include "aieng/domain/TicketStore.h"
#include "aieng/domain/Workflow.h"

#include <QSqlQuery>
#include <QTest>
#include <QTemporaryDir>

#include <array>

using namespace aieng::domain;

namespace {

[[nodiscard]] Actor actor(const QString &id, std::initializer_list<Role> roles)
{
    Actor value;
    value.id = id;
    for (const Role role : roles) {
        value.roles.insert(role);
    }
    return value;
}

[[nodiscard]] TransitionRequest request(
    TicketState target,
    quint64 version,
    const QString &digest = {})
{
    return {target, version, QStringLiteral("verified test rationale"), digest};
}

[[nodiscard]] Ticket ticket(const QString &id, TicketState state, quint64 version)
{
    Ticket value;
    value.id = id;
    value.projectId = QStringLiteral("PROJECT-1");
    value.state = state;
    value.version = version;
    return value;
}

} // namespace

class DomainTest final : public QObject {
    Q_OBJECT

private slots:
    void agentCannotStartQa();
    void staleVersionIsRejected();
    void releaseRequiresIndependentHuman();
    void artifactDigestCannotChange();
    void agentCannotRouteAroundReview();
    void validHumanChainReachesReleaseApproval();
    void auditChainDetectsPayloadTampering();
    void auditChainDetectsDeletionAndReordering();
    void storeCommitsTicketAndAuditAtomically();
    void storeRejectsStaleTransitionWithoutAuditAppend();
    void storeFailsClosedOnAuditTampering();
    void storeFailsClosedOnTicketRowTampering();
    void storeRollsBackTicketWhenAuditAppendFails();
    void everyNominalTransitionHasAnAuthorizedPath();
    void artifactGateCannotBeOmitted();
    void patchProposalMustBindArtifact();
    void earlyTransitionCannotInjectArtifact();
    void legacySchemaFailsClosed();
    void durableStoreReopensWithValidAudit();
    void workerLeaseExpiryAndTakeover();
};

void DomainTest::agentCannotStartQa()
{
    Ticket ticketValue = ticket(QStringLiteral("T-1"), TicketState::PatchProposed, 4);
    ticketValue.reporterId = QStringLiteral("reporter");
    ticketValue.patchAuthorId = QStringLiteral("agent-1");
    const Decision decision = Workflow::evaluate(
        ticketValue,
        request(TicketState::QaRunning, 4, QStringLiteral("sha256:abc")),
        actor(QStringLiteral("agent-1"), {Role::Agent}));
    QCOMPARE(decision.code, DecisionCode::MissingRole);
}

void DomainTest::staleVersionIsRejected()
{
    const Ticket ticketValue = ticket(QStringLiteral("T-2"), TicketState::Open, 2);
    const Decision decision = Workflow::evaluate(
        ticketValue,
        request(TicketState::Triaged, 1),
        actor(QStringLiteral("support-1"), {Role::Support}));
    QCOMPARE(decision.code, DecisionCode::StaleVersion);
}

void DomainTest::releaseRequiresIndependentHuman()
{
    Ticket ticketValue = ticket(QStringLiteral("T-3"), TicketState::QaApproved, 7);
    ticketValue.patchAuthorId = QStringLiteral("developer-1");
    ticketValue.qaApproverId = QStringLiteral("qa-1");
    ticketValue.artifactDigest = QStringLiteral("sha256:abc");

    QCOMPARE(
        Workflow::evaluate(
            ticketValue,
            request(TicketState::ReleaseApproved, 7, QStringLiteral("sha256:abc")),
            actor(QStringLiteral("developer-1"), {Role::Release}))
            .code,
        DecisionCode::SeparationOfDuties);
    QCOMPARE(
        Workflow::evaluate(
            ticketValue,
            request(TicketState::ReleaseApproved, 7, QStringLiteral("sha256:abc")),
            actor(QStringLiteral("qa-1"), {Role::Release}))
            .code,
        DecisionCode::SeparationOfDuties);
}

void DomainTest::artifactDigestCannotChange()
{
    Ticket ticketValue = ticket(QStringLiteral("T-4"), TicketState::QaRunning, 5);
    ticketValue.artifactDigest = QStringLiteral("sha256:first");
    const Decision decision = Workflow::evaluate(
        ticketValue,
        request(TicketState::QaApproved, 5, QStringLiteral("sha256:second")),
        actor(QStringLiteral("qa-1"), {Role::Qa}));
    QCOMPARE(decision.code, DecisionCode::ArtifactDigestChanged);
}

void DomainTest::agentCannotRouteAroundReview()
{
    const Ticket ticketValue = ticket(QStringLiteral("T-5"), TicketState::PatchProposed, 4);
    const Decision decision = Workflow::evaluate(
        ticketValue,
        request(TicketState::NeedsHuman, 4),
        actor(QStringLiteral("agent-1"), {Role::Agent}));
    QCOMPARE(decision.code, DecisionCode::MissingRole);
}

void DomainTest::validHumanChainReachesReleaseApproval()
{
    Ticket ticketValue = ticket(QStringLiteral("T-6"), TicketState::AgentQueued, 3);
    QVERIFY(Workflow::apply(
                ticketValue,
                request(TicketState::PatchProposed, 3, QStringLiteral("sha256:fixed")),
                actor(QStringLiteral("agent-1"), {Role::Agent}))
                .allowed());
    QVERIFY(Workflow::apply(
                ticketValue,
                request(TicketState::QaRunning, 4, QStringLiteral("sha256:fixed")),
                actor(QStringLiteral("qa-1"), {Role::Qa}))
                .allowed());
    QVERIFY(Workflow::apply(
                ticketValue,
                request(TicketState::QaApproved, 5, QStringLiteral("sha256:fixed")),
                actor(QStringLiteral("qa-1"), {Role::Qa}))
                .allowed());
    QVERIFY(Workflow::apply(
                ticketValue,
                request(TicketState::ReleaseApproved, 6, QStringLiteral("sha256:fixed")),
                actor(QStringLiteral("release-1"), {Role::Release}))
                .allowed());
    QCOMPARE(ticketValue.state, TicketState::ReleaseApproved);
    QCOMPARE(ticketValue.version, quint64{7});
    QCOMPARE(ticketValue.patchAuthorId, QStringLiteral("agent-1"));
    QCOMPARE(ticketValue.qaApproverId, QStringLiteral("qa-1"));
    QCOMPARE(ticketValue.releaseApproverId, QStringLiteral("release-1"));
}

void DomainTest::auditChainDetectsPayloadTampering()
{
    const QByteArray key("test-secret-that-is-not-a-production-key");
    AuditChain chain(key);
    (void)chain.append(
        QStringLiteral("event-1"),
        QStringLiteral("2026-11-19T18:00:00Z"),
        QStringLiteral("support-1"),
        QStringLiteral("ticket.created"),
        QStringLiteral("ticket"),
        QStringLiteral("T-1"),
        QByteArray("{\"severity\":\"high\"}"));
    (void)chain.append(
        QStringLiteral("event-2"),
        QStringLiteral("2026-11-19T18:01:00Z"),
        QStringLiteral("qa-1"),
        QStringLiteral("qa.approved"),
        QStringLiteral("ticket"),
        QStringLiteral("T-1"),
        QByteArray("{\"digest\":\"sha256:fixed\"}"));
    QVERIFY(chain.verify());

    QList<AuditEvent> tampered = chain.events();
    tampered[0].canonicalPayload = QByteArray("{\"severity\":\"low\"}");
    QVERIFY(!AuditChain::verify(tampered, key));
}

void DomainTest::auditChainDetectsDeletionAndReordering()
{
    const QByteArray key("test-secret-that-is-not-a-production-key");
    AuditChain chain(key);
    (void)chain.append(
        QStringLiteral("event-1"), QStringLiteral("time-1"), QStringLiteral("actor-1"),
        QStringLiteral("one"), QStringLiteral("ticket"), QStringLiteral("T-1"), QByteArray("{}"));
    (void)chain.append(
        QStringLiteral("event-2"), QStringLiteral("time-2"), QStringLiteral("actor-2"),
        QStringLiteral("two"), QStringLiteral("ticket"), QStringLiteral("T-1"), QByteArray("{}"));
    (void)chain.append(
        QStringLiteral("event-3"), QStringLiteral("time-3"), QStringLiteral("actor-3"),
        QStringLiteral("three"), QStringLiteral("ticket"), QStringLiteral("T-1"), QByteArray("{}"));

    QList<AuditEvent> deleted = chain.events();
    deleted.removeAt(1);
    QVERIFY(!AuditChain::verify(deleted, key));

    QList<AuditEvent> reordered = chain.events();
    reordered.swapItemsAt(0, 1);
    QVERIFY(!AuditChain::verify(reordered, key));
}

void DomainTest::storeCommitsTicketAndAuditAtomically()
{
    TicketStore store(
        QStringLiteral(":memory:"), QByteArray("01234567890123456789012345678901"));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    Ticket created = ticket(QStringLiteral("T-DB-1"), TicketState::Open, 1);
    created.reporterId = QStringLiteral("reporter-1");
    QVERIFY2(
        store.createTicket(
            created,
            QStringLiteral("event-create"),
            QStringLiteral("2026-11-19T18:00:00Z"),
            &error),
        qPrintable(error));

    const StoreResult result = store.transition(
        created.id,
        request(TicketState::Triaged, 1),
        actor(QStringLiteral("support-1"), {Role::Support}),
        QStringLiteral("event-triage"),
        QStringLiteral("2026-11-19T18:01:00Z"));
    QVERIFY2(result.persisted, qPrintable(result.error));
    QCOMPARE(result.ticket.state, TicketState::Triaged);
    QCOMPARE(store.auditEvents().size(), 2);
    QVERIFY(store.verifyAudit(&error));
    QVERIFY(!AuditChain::verify(
        store.auditEvents(), QByteArray("01234567890123456789012345678901")));
}

void DomainTest::storeRejectsStaleTransitionWithoutAuditAppend()
{
    TicketStore store(
        QStringLiteral(":memory:"), QByteArray("01234567890123456789012345678901"));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    Ticket created = ticket(QStringLiteral("T-DB-2"), TicketState::Open, 1);
    created.reporterId = QStringLiteral("reporter-1");
    QVERIFY(store.createTicket(
        created,
        QStringLiteral("event-create"),
        QStringLiteral("2026-11-19T18:00:00Z"),
        &error));

    const StoreResult result = store.transition(
        created.id,
        request(TicketState::Triaged, 9),
        actor(QStringLiteral("support-1"), {Role::Support}),
        QStringLiteral("event-stale"),
        QStringLiteral("2026-11-19T18:01:00Z"));
    QVERIFY(!result.persisted);
    QCOMPARE(result.decision.code, DecisionCode::StaleVersion);
    QCOMPARE(store.auditEvents().size(), 1);
    QCOMPARE(store.loadTicket(created.id)->version, quint64{1});
}

void DomainTest::storeFailsClosedOnAuditTampering()
{
    const QString connectionName = QStringLiteral("tamper-test");
    TicketStore store(
        QStringLiteral(":memory:"),
        QByteArray("01234567890123456789012345678901"),
        connectionName);
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    Ticket created = ticket(QStringLiteral("T-DB-3"), TicketState::Open, 1);
    created.reporterId = QStringLiteral("reporter-1");
    QVERIFY(store.createTicket(
        created,
        QStringLiteral("event-create"),
        QStringLiteral("2026-11-19T18:00:00Z"),
        &error));

    QSqlDatabase database = QSqlDatabase::database(connectionName);
    QSqlQuery tamper(database);
    QVERIFY(tamper.exec(QStringLiteral(
        "UPDATE audit_events SET canonical_payload = X'00' WHERE sequence = 1")));

    const StoreResult result = store.transition(
        created.id,
        request(TicketState::Triaged, 1),
        actor(QStringLiteral("support-1"), {Role::Support}),
        QStringLiteral("event-triage"),
        QStringLiteral("2026-11-19T18:01:00Z"));
    QVERIFY(!result.persisted);
    QVERIFY(result.error.contains(QStringLiteral("audit chain verification failed")));
    QCOMPARE(store.loadTicket(created.id)->state, TicketState::Open);
    QCOMPARE(store.auditEvents().size(), 1);
    database = QSqlDatabase();
}

void DomainTest::storeFailsClosedOnTicketRowTampering()
{
    const QString connectionName = QStringLiteral("ticket-row-tamper-test");
    TicketStore store(
        QStringLiteral(":memory:"),
        QByteArray("01234567890123456789012345678901"),
        connectionName);
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    Ticket created = ticket(QStringLiteral("T-DB-ROW"), TicketState::Open, 1);
    created.reporterId = QStringLiteral("reporter-1");
    QVERIFY(store.createTicket(
        created,
        QStringLiteral("event-create-row"),
        QStringLiteral("2026-11-19T18:00:00Z"),
        &error));

    QSqlDatabase database = QSqlDatabase::database(connectionName);
    QSqlQuery tamper(database);
    QVERIFY(tamper.exec(QStringLiteral(
        "UPDATE tickets SET project_id = 'PROJECT-ATTACKER' WHERE id = 'T-DB-ROW'")));

    const auto loaded = store.loadTicket(created.id, &error);
    QVERIFY(!loaded.has_value());
    QCOMPARE(error, QStringLiteral("ticket integrity verification failed"));
    const StoreResult transitioned = store.transition(
        created.id,
        request(TicketState::Triaged, 1),
        actor(QStringLiteral("support-1"), {Role::Support}),
        QStringLiteral("event-triage-row"),
        QStringLiteral("2026-11-19T18:01:00Z"));
    QVERIFY(!transitioned.persisted);
    QCOMPARE(transitioned.error, QStringLiteral("ticket integrity verification failed"));
    QCOMPARE(store.auditEvents().size(), 1);
    database = QSqlDatabase();
}

void DomainTest::storeRollsBackTicketWhenAuditAppendFails()
{
    TicketStore store(
        QStringLiteral(":memory:"), QByteArray("01234567890123456789012345678901"));
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    Ticket created = ticket(QStringLiteral("T-DB-4"), TicketState::Open, 1);
    created.reporterId = QStringLiteral("reporter-1");
    QVERIFY2(
        store.createTicket(
            created,
            QStringLiteral("duplicate-event-id"),
            QStringLiteral("2026-11-19T18:00:00Z"),
            &error),
        qPrintable(error));

    const StoreResult result = store.transition(
        created.id,
        request(TicketState::Triaged, 1),
        actor(QStringLiteral("support-1"), {Role::Support}),
        QStringLiteral("duplicate-event-id"),
        QStringLiteral("2026-11-19T18:01:00Z"));
    QVERIFY(!result.persisted);
    QVERIFY(result.error.contains(QStringLiteral("UNIQUE constraint failed")));
    const auto after = store.loadTicket(created.id, &error);
    QVERIFY2(after.has_value(), qPrintable(error));
    QCOMPARE(after->state, TicketState::Open);
    QCOMPARE(after->version, quint64{1});
    QCOMPARE(store.auditEvents().size(), 1);
    QVERIFY(store.verifyAudit(&error));
}

void DomainTest::everyNominalTransitionHasAnAuthorizedPath()
{
    struct Case final {
        TicketState from;
        TicketState to;
        Role role;
        bool needsDigest;
    };
    const std::array<Case, 8> cases{{
        {TicketState::Open, TicketState::Triaged, Role::Support, false},
        {TicketState::Triaged, TicketState::AgentQueued, Role::Support, false},
        {TicketState::AgentQueued, TicketState::PatchProposed, Role::Agent, true},
        {TicketState::PatchProposed, TicketState::QaRunning, Role::Qa, true},
        {TicketState::QaRunning, TicketState::QaApproved, Role::Qa, true},
        {TicketState::QaApproved, TicketState::ReleaseApproved, Role::Release, true},
        {TicketState::ReleaseApproved, TicketState::Deploying, Role::Operator, true},
        {TicketState::Deploying, TicketState::Deployed, Role::Operator, true},
    }};

    for (const Case &testCase : cases) {
        Ticket value = ticket(QStringLiteral("matrix"), testCase.from, 1);
        value.patchAuthorId = QStringLiteral("patch-author");
        value.qaApproverId = QStringLiteral("qa-approver");
        if (testCase.needsDigest) {
            value.artifactDigest = QStringLiteral("sha256:matrix");
        }
        const QString digest = testCase.needsDigest ? QStringLiteral("sha256:matrix") : QString{};
        const Decision decision = Workflow::evaluate(
            value,
            request(testCase.to, 1, digest),
            actor(QStringLiteral("independent-actor"), {testCase.role}));
        QVERIFY2(
            decision.allowed(),
            qPrintable(
                Workflow::stateName(testCase.from) + QStringLiteral(" -> ")
                + Workflow::stateName(testCase.to) + QStringLiteral(": ") + decision.message));
    }
}

void DomainTest::artifactGateCannotBeOmitted()
{
    const Ticket value = ticket(QStringLiteral("T-GATE"), TicketState::PatchProposed, 4);
    const Decision decision = Workflow::evaluate(
        value,
        request(TicketState::QaRunning, 4),
        actor(QStringLiteral("qa-1"), {Role::Qa}));
    QCOMPARE(decision.code, DecisionCode::MissingArtifactDigest);
}

void DomainTest::patchProposalMustBindArtifact()
{
    const Ticket value = ticket(QStringLiteral("T-PATCH"), TicketState::AgentQueued, 3);
    const Decision decision = Workflow::evaluate(
        value,
        request(TicketState::PatchProposed, 3),
        actor(QStringLiteral("agent-1"), {Role::Agent}));
    QCOMPARE(decision.code, DecisionCode::MissingArtifactDigest);
}

void DomainTest::earlyTransitionCannotInjectArtifact()
{
    const Ticket value = ticket(QStringLiteral("T-EARLY"), TicketState::Open, 1);
    const Decision decision = Workflow::evaluate(
        value,
        request(TicketState::Triaged, 1, QStringLiteral("sha256:premature")),
        actor(QStringLiteral("support-1"), {Role::Support}));
    QCOMPARE(decision.code, DecisionCode::UnexpectedArtifactDigest);
}

void DomainTest::legacySchemaFailsClosed()
{
    QTemporaryDir directory;
    QVERIFY(directory.isValid());
    const QString path = directory.filePath(QStringLiteral("legacy.db"));
    const QString setupConnection = QStringLiteral("legacy-schema-setup");
    {
        QSqlDatabase legacy = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), setupConnection);
        legacy.setDatabaseName(path);
        QVERIFY(legacy.open());
        QSqlQuery query(legacy);
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE schema_metadata (singleton INTEGER PRIMARY KEY, schema_version INTEGER)")));
        QVERIFY(query.exec(QStringLiteral(
            "INSERT INTO schema_metadata(singleton, schema_version) VALUES(1, 1)")));
        QVERIFY(query.exec(QStringLiteral(
            "CREATE TABLE tickets (id TEXT PRIMARY KEY, state TEXT NOT NULL)")));
        legacy.close();
    }
    QSqlDatabase::removeDatabase(setupConnection);

    TicketStore store(path, QByteArray("01234567890123456789012345678901"));
    QString error;
    QVERIFY(!store.open(&error));
    QVERIFY(error.contains(QStringLiteral("offline migration required")));
}

void DomainTest::durableStoreReopensWithValidAudit()
{
    QTemporaryDir directory;
    QVERIFY(directory.isValid());
    const QString path = directory.filePath(QStringLiteral("aieng.db"));
    const QByteArray key("01234567890123456789012345678901");
    {
        TicketStore store(path, key);
        QString error;
        QVERIFY2(store.open(&error), qPrintable(error));
        Ticket created = ticket(QStringLiteral("T-DURABLE"), TicketState::Open, 1);
        created.reporterId = QStringLiteral("reporter-1");
        QVERIFY2(
            store.createTicket(
                created,
                QStringLiteral("durable-create"),
                QStringLiteral("2026-11-19T18:00:00Z"),
                &error),
            qPrintable(error));
    }
    {
        TicketStore reopened(path, key);
        QString error;
        QVERIFY2(reopened.open(&error), qPrintable(error));
        const auto loaded = reopened.loadTicket(QStringLiteral("T-DURABLE"), &error);
        QVERIFY2(loaded.has_value(), qPrintable(error));
        QCOMPARE(loaded->state, TicketState::Open);
        QCOMPARE(loaded->version, quint64{1});
        QCOMPARE(reopened.auditEvents(&error).size(), 1);
        QVERIFY2(reopened.verifyAudit(&error), qPrintable(error));
    }
}

void DomainTest::workerLeaseExpiryAndTakeover()
{
    static qint64 now;
    now = 1000;
    const auto clock = []() -> qint64 { return now; };
    const QString connection = QStringLiteral("lease-test");
    TicketStore store(QStringLiteral(":memory:"), QByteArray(32, 'K'), connection, clock);
    QString error;
    QVERIFY2(store.open(&error), qPrintable(error));
    const auto id = QStringLiteral("lease-1");
    const auto time = QStringLiteral("2026-11-19T18:01:00Z");
    const auto support = actor(QStringLiteral("support"), {Role::Support});
    const auto a = actor(QStringLiteral("A"), {Role::Agent});
    const auto b = actor(QStringLiteral("B"), {Role::Agent});
    auto reported = ticket(id, TicketState::Open, 1);
    reported.reporterId = QStringLiteral("reporter");
    QVERIFY2(store.createTicket(reported, "created", time, &error), qPrintable(error));
    QVERIFY(store.transition(id, request(TicketState::Triaged, 1), support, "triage", time).persisted);
    QVERIFY(store.transition(id, request(TicketState::AgentQueued, 2), support, "queue", time).persisted);
    auto claim = request(TicketState::AgentQueued, 3);
    claim.claimProof = QByteArray(32, 'a');
    QVERIFY(!store.transition(id, claim, a, "queue", time).persisted); // duplicate audit ID rolls back lease
    const auto first = store.transition(id, claim, a, "claim-a", time);
    QVERIFY2(first.persisted, qPrintable(first.error));
    QCOMPARE(first.ticket.lease.expiresAtMs, now + 300000);
    QVERIFY(store.transition(id, claim, a, "retry", time).persisted);
    auto propose = request(TicketState::PatchProposed, 4, QStringLiteral("sha256:candidate"));
    const auto developer = actor(QStringLiteral("developer"), {Role::Developer});
    QVERIFY(!store.transition(id, propose, developer, "leased", time).persisted);
    propose.claimProof = claim.claimProof;
    QVERIFY(!store.transition(id, propose, b, "wrong-owner", time).persisted);
    now = first.ticket.lease.expiresAtMs - 1;
    claim.expectedVersion = 4;
    claim.claimProof = QByteArray(32, 'b');
    QVERIFY(!store.transition(id, claim, b, "early", time).persisted);
    now += 1;
    QVERIFY(!store.transition(id, propose, a, "expired", time).persisted);
    QVERIFY(store.transition(id, claim, b, "claim-b", time).persisted);
    QVERIFY(!store.transition(id, propose, a, "stale", time).persisted);
    propose.expectedVersion = 5;
    QVERIFY(!store.transition(id, propose, a, "old-holder", time).persisted);
    QVERIFY(!store.transition(id, propose, b, "old-proof", time).persisted);
    propose.claimProof = claim.claimProof;
    QVERIFY(store.transition(id, propose, b, "submitted", time).persisted);
    QCOMPARE(store.loadTicket(id)->patchAuthorId, b.id);
    QCOMPARE(store.auditEvents().size(), 6);
    QVERIFY(store.verifyAudit(&error));
    // On a second ticket, shut down the worker after pickup and finish the repair manually.
    reported.id = QStringLiteral("abandoned");
    QVERIFY(store.createTicket(reported, "open-abandoned", time, &error));
    QVERIFY(store.transition(reported.id, request(TicketState::Triaged, 1), support, "t2", time).persisted);
    QVERIFY(store.transition(reported.id, request(TicketState::AgentQueued, 2), support, "q2", time).persisted);
    claim.expectedVersion = 3;
    auto abandoned = store.transition(reported.id, claim, a, "claim-abandoned", time);
    QVERIFY(abandoned.persisted);
    now = abandoned.ticket.lease.expiresAtMs;
    propose.expectedVersion = 4;
    propose.claimProof.clear();
    QVERIFY(store.transition(reported.id, propose, developer, "developer-takeover", time).persisted);
    QVERIFY(store.loadTicket(reported.id)->lease.owner.isEmpty());
    QSqlQuery tamper(QSqlDatabase::database(connection));
    QVERIFY(tamper.exec(QStringLiteral("UPDATE tickets SET lease_expiry=99")));
    QVERIFY(!store.loadTicket(id, &error));
    QVERIFY(error.contains("integrity"));
}

QTEST_APPLESS_MAIN(DomainTest)

#include "test_domain.moc"

