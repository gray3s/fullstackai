add_library(aieng_application STATIC
    src/IdentityPolicy.cpp
    src/TicketApplication.cpp
)

target_include_directories(aieng_application
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_link_libraries(aieng_application
    PUBLIC
        aieng_domain
        Qt6::Core
    PRIVATE
        aieng_warnings
        aieng_security_flags
)
