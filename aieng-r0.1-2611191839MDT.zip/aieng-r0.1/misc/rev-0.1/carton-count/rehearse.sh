#!/usr/bin/env bash
# Copyright © 2026 Samuel A. Gray III. All rights reserved.
set -euo pipefail
umask 077
example=$(cd "$(dirname "$0")" && pwd)
root=$(cd "$example/../../.." && pwd)
bin="$root/build/release/apps/control-plane"
[[ -x "$bin/aieng-ticket-service" && -x "$bin/aieng-ticket" ]] || { echo "Run scripts/release-check.sh first." >&2; exit 1; }
run=$(mktemp -d)
echo "Rehearsal directory: $run"
mkdir -p "$run/work" "$run/qa" "$run/prod/releases" "$run/evidence"
build() { c++ -std=c++20 -O2 -Wall -Wextra -Werror -fstack-protector-strong -fPIE -pie -Wl,-z,relro,-z,now "$1" -o "$2"; }
digest() { sha256sum "$1" | cut -d' ' -f1; }
activate() { ln -s "releases/$1" "$run/prod/next"; mv -Tf "$run/prod/next" "$run/prod/current"; }
build "$example/cartons.cpp" "$run/prod/releases/v1"
activate v1
old=$(digest "$run/prod/current")
[[ $("$run/prod/current" 24 12) == 2 ]]
[[ $("$run/prod/current" 25 12) == 2 ]]
echo "Baseline reproduced: expected 3 cartons for 25/12, observed 2."

openssl rand -out "$run/intake.key" 32
systemd-socket-activate --seqpacket --accept --inetd -l "$run/intake.sock" \
    "$bin/aieng-ticket-service" "$run/tickets.db" "$run/intake.key" warehouse --support-uid "$(id -u)" >"$run/listener.log" 2>&1 &
listener=$!
cleanup() { kill "$listener" 2>/dev/null || true; wait "$listener" 2>/dev/null || true; }
trap cleanup EXIT
for ((i=0;i<100;i++)); do [[ -S "$run/intake.sock" ]] && break; kill -0 "$listener"; sleep 0.03; done
ticket() { "$bin/aieng-ticket" "$run/intake.sock" "$@"; }
ticket create "Count the last partial carton" <<< "25 items at 12 per carton must reserve three cartons. Zero items must reserve zero." \
    >"$run/evidence/open.json"
id=$(jq -er '.id' "$run/evidence/open.json")
ticket triage "$id" 1 <<< "Reproduced with synthetic order of 25 items" >"$run/evidence/triaged.json"
ticket queue "$id" 2 <<< "Prepare fix and retain the exact-multiple behavior" >"$run/evidence/queued.json"
jq -e '.state == "AGENT_QUEUED" and .version == "3"' "$run/evidence/queued.json" >/dev/null
echo "AIEng ticket $id reached AGENT_QUEUED. Starting scripted release rehearsal."

cp "$example/cartons.cpp" "$run/work/cartons.cpp"
patch --batch --fuzz=0 -d "$run/work" -p1 < "$example/partial-carton.patch"
build "$run/work/cartons.cpp" "$run/qa/cartons"
qa="$run/qa/cartons"
for spec in '0 12 0' '1 12 1' '24 12 2' '25 12 3' '1000000000 3 333333334'; do
    read -r items capacity expected <<< "$spec"
    actual=$("$qa" "$items" "$capacity")
    [[ "$actual" == "$expected" ]]
    printf '%s %s => %s\n' "$items" "$capacity" "$actual"
done
for spec in '1 0' '-1 12' '3x 2'; do
    read -r items capacity <<< "$spec"
    rc=0
    "$qa" "$items" "$capacity" >/dev/null 2>&1 || rc=$?
    [[ "$rc" == 2 ]]
done
approved=$(digest "$qa")
printf '%s\n' "$approved" >"$run/evidence/rehearsal-qa-digest"
promote() {
    local candidate=$1
    [[ $(digest "$candidate") == "$approved" ]] || return 1
    install -m 0555 "$candidate" "$run/prod/releases/v2" || return 1
    [[ $(digest "$run/prod/releases/v2") == "$approved" ]] || return 1
    activate v2
}
if promote "$run/prod/releases/v1"; then echo "Digest mismatch guard failed" >&2; exit 1; fi
[[ $(digest "$run/prod/current") == "$old" ]]
promote "$qa"
[[ $("$run/prod/current" 25 12) == 3 ]]
activate v1
[[ $(digest "$run/prod/current") == "$old" && $("$run/prod/current" 25 12) == 2 ]]
activate v2
[[ $(digest "$run/prod/current") == "$approved" && $("$run/prod/current" 25 12) == 3 ]]
jq -n --arg ticket "$id" --arg sha "$approved" --arg previous "$old" \
    '{ticket:$ticket,platform_state:"AGENT_QUEUED",environment:"local-production-rehearsal",approval:"fixture",
      qa_sha256:$sha,active_sha256:$sha,rollback_sha256:$previous,mismatch_rejected:true,rollback_checked:true}' \
    | tee "$run/evidence/release.json"
