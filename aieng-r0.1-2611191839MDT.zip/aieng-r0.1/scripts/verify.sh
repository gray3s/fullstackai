#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
./scripts/no-python-check.sh
cmake --preset dev
cmake --build --preset dev
ctest --preset dev
printf 'Native verification passed.\n'

