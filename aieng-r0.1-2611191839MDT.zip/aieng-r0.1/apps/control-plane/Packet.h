// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once
#include <QJsonDocument>
#include <QJsonObject>
#include <sys/socket.h>
#include <sys/time.h>
#include <cerrno>

namespace intake {
inline bool setTimeouts(int fd)
{
    const timeval timeout{10, 0};
    return setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) == 0
        && setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout)) == 0;
}

inline bool sendPacket(int fd, const QJsonObject &object)
{
    const auto bytes = QJsonDocument(object).toJson(QJsonDocument::Compact);
    return bytes.size() <= 65536 && send(fd, bytes.data(), static_cast<size_t>(bytes.size()), MSG_NOSIGNAL) == bytes.size();
}

inline QJsonObject receivePacket(int fd)
{
    QByteArray bytes(65536, Qt::Uninitialized);
    ssize_t size;
    do {
        size = recv(fd, bytes.data(), static_cast<size_t>(bytes.size()), MSG_TRUNC);
    } while (size < 0 && errno == EINTR);
    if (size <= 0 || size > bytes.size()) return {};
    bytes.truncate(size);
    return QJsonDocument::fromJson(bytes).object();
}
}
