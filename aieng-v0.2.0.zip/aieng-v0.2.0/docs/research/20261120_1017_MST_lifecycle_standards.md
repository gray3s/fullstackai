# Standards for turning developer intent into a deployed release

AIEng's first project question is “What algorithm do you want developed into code?” The answer belongs to the developer. A target,
an input domain and an expected outcome give the team a way to implement and test that answer. The standards below address different
parts of that work. Contract, market, safety classification and customer policy determine additional obligations. The table of contents
and publisher abstracts establish the scope of ISO documents; a buyer requiring formal conformance needs the applicable full editions.

## Sources and implementation decisions

1. **Development and change management.** ISO/IEC/IEEE 12207:2026 covers software lifecycle processes across acquisition, development,
   operation, maintenance and retirement and allows different development methods. For each change AIEng captures intent, assigns a
   ticket, identifies the source/build, and preserves the approved candidate. A later defect enters intake as another change.
   [ISO/IEC/IEEE 12207:2026](https://www.iso.org/standard/90219.html)
2. **Product quality.** ISO/IEC 25010:2023 supplies a quality model for expressing measurable product requirements. Translate each
   applicable quality concern into a workload, unit, observation and threshold. A memory ceiling belongs to a particular board and
   build. A throughput target belongs to a specified workload. Record the rationale when selecting characteristics.
   [ISO/IEC 25010:2023](https://www.iso.org/standard/78176.html)
3. **QA and validation.** ISO/IEC/IEEE 29119-2:2021 describes processes for managing and performing tests. Verification examines
   specified requirements; validation examines the intended use. Identify the oracle, exercise normal, boundary and rejected behavior,
   record observed outcomes, and require an independent review for release. A process framework cannot supply the customer's oracle.
   [ISO/IEC/IEEE 29119-2:2021](https://www.iso.org/standard/79428.html) · [NIST validation](https://csrc.nist.gov/glossary/term/validation)
4. **Secure development.** NIST SSDF 1.1 groups work into preparing the organization, protecting software, producing well-secured
   software, and responding to vulnerabilities. Assign responsibility; restrict access to release inputs; review design, code and
   dependencies; record unresolved findings; identify where a vulnerability report goes after deployment. Use the final 1.1 baseline;
   NIST's publication list labels 1.2 a draft. Tailor testing to the actual attack surface and expected privileges.
   [NIST SP 800-218](https://csrc.nist.gov/pubs/sp/800/218/final) · [Publication status](https://csrc.nist.gov/Projects/ssdf/publications)
5. **Build and deployment.** NIST SP 800-204D addresses supply chain security in CI/CD. SLSA v1.2 specifies build provenance, including
   build definition and run details. Retain source, toolchain, dependency and output identities. At install time compare the retrieved
   artifact to the approved digest. A build-log reference is a useful first step; a SLSA attestation and verified builder identity
   require a provenance producer and verifier.
   [NIST SP 800-204D](https://csrc.nist.gov/pubs/sp/800/204/d/final) · [SLSA v1.2 provenance](https://slsa.dev/spec/v1.2/build-provenance)
6. **Operating a change.** Record the target and baseline, designate the recovery action, install, measure the same workload and
   check the installed path. Google SRE describes comparing canary and control populations to avoid hiding regressions in aggregates.
   This is operational guidance. Independent release and operator identities are AIEng policy.
   [Google SRE, Canarying Releases](https://sre.google/workbook/canarying-releases/)
7. **Conditional overlays.** Select OWASP ASVS 5.0.0 requirements for applicable web applications/services. For a network protocol,
   record the designer-selected specification/version and applicable behavior. For a board, use its actual datasheet and operating
   limits. For open-source dependencies, inventory versions and license obligations and select a supported update path. Sector-specific
   standards and regulatory requirements need their own applicability decision before work is queued.
   [OWASP ASVS](https://asvs.owasp.org/)

## A repeatable unit of implementation

Start from a concern and keep asking what observation would settle it. Split a compound requirement into children until one leaf has
one action, one expected value or limit, and one evidence record. Implement the smallest change that makes the leaf pass. Re-run it
and its siblings; their common parent is satisfied only when all required children pass. Keep an unknown observation open.
Preselect expectations before gathering results. A peer can review an individual leaf without assuming that a whole platform is safe.

For example, the designer may select a network transport. Under “interoperability,” split “framing” into reconstruction of a partial
message and separation of two messages delivered together. Each becomes its own fixture with its own observable count or content.
A device project could instead branch into board revision, power mode and maximum memory in bytes. Neither choice selects an algorithm.

AIEng implements shared evidence checks and existing transactional approval controls. A development team still implements its
particular algorithm, supplies the test oracle and runs the relevant compiler, workload, security checks and device measurements.
The software can compare a numeric observation or digest and identify missing evidence. Independent collection and the authority of
a supplied report depend on the project's trusted tools and reviewers.
