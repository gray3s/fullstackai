// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/application/TicketApplication.h"

#include <QDateTime>
#include <QRegularExpression>

namespace aieng::application {
namespace {

[[nodiscard]] ApplicationResult result(
    ApplicationCode code,
    const QString &publicMessage,
    const QString &operatorDiagnostic = {})
{
    ApplicationResult value;
    value.code = code;
    value.publicMessage = publicMessage;
    value.operatorDiagnostic = operatorDiagnostic;
    return value;
}

[[nodiscard]] bool containsControlCharacter(const QString &value)
{
    for (const QChar character : value) {
        if (character.category() == QChar::Other_Control) {
            return true;
        }
    }
    return false;
}

} // namespace

TicketApplication::TicketApplication(domain::TicketStore &store)
    : m_store(store)
{
}

ApplicationResult TicketApplication::createTicket(
    const CreateTicketCommand &command,
    const AuthenticatedPrincipal &principal,
    const TrustedCommandContext &context)
{
    const ApplicationResult principalResult = validatePrincipal(principal);
    if (!principalResult.succeeded()) {
        return principalResult;
    }
    if (!isIdentifier(command.projectId)) {
        return invalid(QStringLiteral("project identifier is invalid"));
    }
    if (!principal.rolesForProject(command.projectId).contains(domain::Role::Reporter)) {
        return result(ApplicationCode::Forbidden, QStringLiteral("operation is not permitted"));
    }
    const ApplicationResult contextResult = validateContext(context);
    if (!contextResult.succeeded()) {
        return contextResult;
    }
    if (!isIdentifier(command.ticketId)) {
        return invalid(QStringLiteral("ticket identifier is invalid"));
    }

    domain::Ticket ticket;
    if (!isBoundedText(command.summary, 1, 160) || command.description.size() > 8192
        || command.description.trimmed().isEmpty()) {
        return invalid(QStringLiteral("enter a summary (1–160 characters) and description (1–8192 characters)"));
    }
    for (const auto ch : command.description) {
        if (ch.category() == QChar::Other_Control && ch != QLatin1Char('\n') && ch != QLatin1Char('\t')) {
            return invalid(QStringLiteral("description contains unsupported control characters"));
        }
    }
    ticket.summary = command.summary;
    ticket.description = command.description;
    ticket.id = command.ticketId;
    ticket.projectId = command.projectId;
    ticket.reporterId = principal.subject;
    QString storageError;
    if (!m_store.createTicket(
            ticket,
            context.eventId,
            context.occurredAtUtc,
            &storageError)) {
        return result(
            ApplicationCode::StorageFailure,
            QStringLiteral("ticket could not be created"),
            storageError);
    }

    ApplicationResult success = result(
        ApplicationCode::Succeeded, QStringLiteral("ticket created"));
    success.ticket = ticket;
    success.decisionCode = domain::DecisionCode::Allowed;
    return success;
}

ApplicationResult TicketApplication::listQueue(const QString &project, const QString &state,
    const QString &after, const AuthenticatedPrincipal &principal) const
{
    const auto identity = validatePrincipal(principal);
    if (!identity.succeeded()) return identity;
    if (!principal.rolesForProject(project).contains(domain::Role::Support)) {
        return result(ApplicationCode::Forbidden, QStringLiteral("Project support access required"));
    }
    const auto filter = domain::Workflow::stateFromName(state);
    if ((filter != domain::TicketState::Open && filter != domain::TicketState::Triaged
         && filter != domain::TicketState::AgentQueued) || (!after.isEmpty() && !isIdentifier(after))) {
        return invalid(QStringLiteral("invalid queue state or cursor"));
    }
    QString error;
    const auto page = m_store.listTickets(project, *filter, after, &error);
    if (!page) {
        const auto code = error == QStringLiteral("ticket integrity verification failed")
            ? ApplicationCode::IntegrityFailure : ApplicationCode::StorageFailure;
        return result(code, QStringLiteral("ticket queue could not be read"), error);
    }
    auto response = result(ApplicationCode::Succeeded, QStringLiteral("queue retrieved"));
    response.page = *page;
    response.decisionCode = domain::DecisionCode::Allowed;
    return response;
}

ApplicationResult TicketApplication::readTicket(
    const QString &ticketId, const AuthenticatedPrincipal &principal) const
{
    const auto identity = validatePrincipal(principal);
    if (!identity.succeeded()) return identity;
    if (!isIdentifier(ticketId)) return invalid(QStringLiteral("ticket identifier is invalid"));
    QString error;
    const auto ticket = m_store.loadTicket(ticketId, &error);
    if (!error.isEmpty()) {
        const auto code = error == QStringLiteral("ticket integrity verification failed")
            ? ApplicationCode::IntegrityFailure : ApplicationCode::StorageFailure;
        return result(code, QStringLiteral("ticket could not be read"), error);
    }
    if (ticket) {
        const auto roles = principal.rolesForProject(ticket->projectId);
        if (roles.contains(domain::Role::Support) || roles.contains(domain::Role::Auditor)
            || (roles.contains(domain::Role::Reporter) && principal.subject == ticket->reporterId)) {
            auto response = result(ApplicationCode::Succeeded, QStringLiteral("ticket retrieved"));
            response.ticket = *ticket;
            response.decisionCode = domain::DecisionCode::Allowed;
            return response;
        }
    }
    return result(ApplicationCode::NotFound, QStringLiteral("ticket was not found"));
}

ApplicationResult TicketApplication::transitionTicket(
    const TransitionTicketCommand &command,
    const AuthenticatedPrincipal &principal,
    const TrustedCommandContext &context)
{
    const ApplicationResult principalResult = validatePrincipal(principal);
    if (!principalResult.succeeded()) {
        return principalResult;
    }
    const ApplicationResult contextResult = validateContext(context);
    if (!contextResult.succeeded()) {
        return contextResult;
    }
    if (!isIdentifier(command.ticketId)) {
        return invalid(QStringLiteral("ticket identifier is invalid"));
    }
    if (!isBoundedText(command.rationale.trimmed(), 5, 2048)) {
        return invalid(QStringLiteral("rationale must contain 5 to 2048 characters"));
    }
    if (!command.artifactDigest.isEmpty() && !isSha256Digest(command.artifactDigest)) {
        return invalid(QStringLiteral("artifact digest must be a lowercase SHA-256 digest"));
    }

    QString loadError;
    const auto current = m_store.loadTicket(command.ticketId, &loadError);
    if (!current.has_value()) {
        const bool integrityFailure =
            loadError.startsWith(QStringLiteral("ticket integrity verification failed"));
        return result(
            integrityFailure ? ApplicationCode::IntegrityFailure
                             : (loadError.isEmpty() ? ApplicationCode::NotFound
                                                    : ApplicationCode::StorageFailure),
            integrityFailure ? QStringLiteral("integrity verification failed")
                             : (loadError.isEmpty() ? QStringLiteral("ticket was not found")
                                                    : QStringLiteral("ticket could not be loaded")),
            loadError);
    }
    const domain::Actor actor{
        principal.subject, principal.rolesForProject(current->projectId)};
    if (actor.roles.isEmpty()) {
        auto denied = result(ApplicationCode::Forbidden, QStringLiteral("operation is not permitted"));
        denied.decisionCode = domain::DecisionCode::MissingRole;
        return denied;
    }
    const domain::TransitionRequest request{
        command.target,
        command.expectedVersion,
        command.rationale.trimmed(),
        command.artifactDigest,
    };
    const domain::StoreResult stored = m_store.transition(
        command.ticketId,
        request,
        actor,
        context.eventId,
        context.occurredAtUtc);

    if (stored.persisted) {
        ApplicationResult success = result(
            ApplicationCode::Succeeded, QStringLiteral("ticket transitioned"));
        success.ticket = stored.ticket;
        success.decisionCode = stored.decision.code;
        return success;
    }
    if (!stored.error.isEmpty()) {
        const bool integrityFailure =
            stored.error.startsWith(QStringLiteral("audit chain verification failed"))
            || stored.error.startsWith(QStringLiteral("ticket integrity verification failed"));
        return result(
            integrityFailure ? ApplicationCode::IntegrityFailure
                             : (stored.error == QStringLiteral("ticket not found")
                                    ? ApplicationCode::NotFound
                                    : ApplicationCode::StorageFailure),
            integrityFailure ? QStringLiteral("integrity verification failed")
                             : (stored.error == QStringLiteral("ticket not found")
                                    ? QStringLiteral("ticket was not found")
                                    : QStringLiteral("ticket could not be transitioned")),
            stored.error);
    }

    ApplicationResult denied = result(
        stored.decision.code == domain::DecisionCode::StaleVersion
            ? ApplicationCode::Conflict
            : ApplicationCode::Forbidden,
        stored.decision.code == domain::DecisionCode::StaleVersion
            ? QStringLiteral("ticket version conflicts with current state")
            : QStringLiteral("operation is not permitted"));
    denied.decisionCode = stored.decision.code;
    return denied;
}

ApplicationResult TicketApplication::validatePrincipal(
    const AuthenticatedPrincipal &principal)
{
    if (!principal.authenticated) {
        return result(ApplicationCode::Unauthenticated, QStringLiteral("authentication is required"));
    }
    if (!isBoundedText(principal.subject, 1, 256)
        || !isBoundedText(principal.trustDomain, 1, 256)
        || (principal.projectRoles.isEmpty() && principal.platformRoles.isEmpty())) {
        return result(
            ApplicationCode::Unauthenticated,
            QStringLiteral("authenticated identity is invalid"));
    }
    for (auto scoped = principal.projectRoles.cbegin();
         scoped != principal.projectRoles.cend(); ++scoped) {
        if (!isIdentifier(scoped.key()) || scoped.value().isEmpty()) {
            return result(
                ApplicationCode::Unauthenticated,
                QStringLiteral("authenticated identity has invalid project roles"));
        }
    }
    return result(ApplicationCode::Succeeded, QStringLiteral("identity accepted"));
}

ApplicationResult TicketApplication::validateContext(const TrustedCommandContext &context)
{
    if (!isIdentifier(context.eventId)) {
        return invalid(QStringLiteral("event identifier is invalid"));
    }
    if (!isBoundedText(context.occurredAtUtc, 20, 32)
        || !context.occurredAtUtc.endsWith(QLatin1Char('Z'))) {
        return invalid(QStringLiteral("event time must be UTC"));
    }
    const QDateTime parsed = QDateTime::fromString(context.occurredAtUtc, Qt::ISODateWithMs);
    if (!parsed.isValid() || parsed.timeSpec() != Qt::UTC) {
        return invalid(QStringLiteral("event time is invalid"));
    }
    return result(ApplicationCode::Succeeded, QStringLiteral("context accepted"));
}

bool TicketApplication::isBoundedText(
    const QString &value,
    qsizetype minimum,
    qsizetype maximum)
{
    return value.size() >= minimum && value.size() <= maximum
        && value == value.trimmed()
        && !containsControlCharacter(value);
}

bool TicketApplication::isIdentifier(const QString &value)
{
    static const QRegularExpression expression(
        QStringLiteral("^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$"));
    return expression.match(value).hasMatch();
}

bool TicketApplication::isSha256Digest(const QString &value)
{
    static const QRegularExpression expression(
        QStringLiteral("^sha256:[0-9a-f]{64}$"));
    return expression.match(value).hasMatch();
}

ApplicationResult TicketApplication::invalid(const QString &message)
{
    return result(ApplicationCode::InvalidCommand, message);
}

} // namespace aieng::application
