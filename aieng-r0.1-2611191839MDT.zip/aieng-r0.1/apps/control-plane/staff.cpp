// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "StaffForm.h"
#include <QApplication>
#include <cstdio>

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    if (app.arguments().size() != 2) {
        std::fputs("Usage: aieng-staff SOCKET\n", stderr);
        return 2;
    }
    StaffForm window(app.arguments().at(1));
    window.show();
    return app.exec();
}
