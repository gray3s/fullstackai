# Candidate admission to independent QA

Baseline d561e90 records a worker's digest under an exclusive ticket lease. Add a local project QA listener. Accept a bounded candidate
file supplied by the reviewer and hash its bytes inside the service. Bind those exact bytes to the ticket and its QA-running transition in
one SQLite transaction. Keep the worker, its patch author identity and other projects outside reviewer authority. A controlled native
fixture can exercise distinct principals on hosts with a single login. Record what the real socket suite and native fixtures prove.

Acceptance requires rejection of substituted bytes, duplicate or stale requests, wrong roles and self-review. Reopen the database and
verify candidate custody, ticket integrity and audit history. Run debug, sanitizer, release hardening and no-Python checks. Stop at QA
admission for this checkpoint. Any later approval requires separate test evidence. Production and external publication are outside scope.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
