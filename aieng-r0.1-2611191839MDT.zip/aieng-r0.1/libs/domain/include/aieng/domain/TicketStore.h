// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include "aieng/domain/AuditChain.h"
#include "aieng/domain/Workflow.h"

#include <QSqlDatabase>
#include <QSqlQuery>

#include <optional>

namespace aieng::domain {

struct QueueEntry final {
    QString id;
    QString summary;
    quint64 version;
};

struct QueuePage final {
    QList<QueueEntry> entries;
    QString nextAfter;
};

struct StoreResult final {
    bool persisted{false};
    Decision decision;
    Ticket ticket;
    QString error;
};

class TicketStore final {
public:
    TicketStore(QString databaseName, QByteArray auditSecret, QString connectionName = {});
    ~TicketStore();

    TicketStore(const TicketStore &) = delete;
    TicketStore &operator=(const TicketStore &) = delete;
    TicketStore(TicketStore &&) = delete;
    TicketStore &operator=(TicketStore &&) = delete;

    [[nodiscard]] bool open(QString *error = nullptr);
    [[nodiscard]] bool createTicket(
        const Ticket &ticket,
        const QString &eventId,
        const QString &occurredAtUtc,
        QString *error = nullptr);
    [[nodiscard]] std::optional<Ticket> loadTicket(
        const QString &ticketId,
        QString *error = nullptr) const;
    [[nodiscard]] StoreResult transition(
        const QString &ticketId,
        const TransitionRequest &request,
        const Actor &actor,
        const QString &eventId,
        const QString &occurredAtUtc);
    [[nodiscard]] QList<AuditEvent> auditEvents(QString *error = nullptr) const;
    [[nodiscard]] bool verifyAudit(QString *error = nullptr) const;
    [[nodiscard]] std::optional<QueuePage> listTickets(
        const QString &project, TicketState state, const QString &after, QString *error) const;

private:
    [[nodiscard]] std::optional<Ticket> decodeRow(const QSqlQuery &query, QString *error) const;
    [[nodiscard]] bool migrate(QString *error);
    [[nodiscard]] bool appendAudit(
        const QString &eventId,
        const QString &occurredAtUtc,
        const QString &actorId,
        const QString &action,
        const QString &objectType,
        const QString &objectId,
        const QByteArray &canonicalPayload,
        QString *error);
    [[nodiscard]] static QByteArray transitionPayload(
        TicketState from,
        const Ticket &updated,
        const TransitionRequest &request);

    QString m_connectionName;
    QString m_databaseName;
    QByteArray m_auditSecret;
    QSqlDatabase m_database;
};

} // namespace aieng::domain

