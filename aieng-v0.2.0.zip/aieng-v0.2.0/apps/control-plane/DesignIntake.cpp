// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "DesignIntake.h"

#include <QFile>
#include <QStringList>
#include <cstdio>

namespace {
struct Method {
    QString action;
    QString benefit;
    QString cost;
};

class Interview {
public:
    explicit Interview(bool defaults) : methodsOnly(defaults) {}

    std::optional<QJsonObject> run()
    {
        if (!input.open(stdin, QIODevice::ReadOnly)) return {};
        const QString algorithm = ask("What algorithm do you want developed into code?", true);
        if (!ok || algorithm.isEmpty() || algorithm == "?" || algorithm == ":defaults") {
            std::fputs("A developer-supplied algorithm is required. No ticket was filed.\n", stderr);
            return {};
        }
        std::fputs("Enter ? for an open question. Enter :defaults to finish with suggested methods.\n", stderr);
        lines << "Developer's algorithm: " + algorithm;
        fact("Purpose", "Who will use this, and what problem should it solve?");
        fact("Inputs", "What inputs, units, and prior state can affect the result?");
        fact("Outputs", "What outputs or state changes should the user observe?");
        const auto target = fact("Target", "What target or compatibility constraints are already fixed?");
        requirement("R1", algorithm);
        fact("Developer priority", "Which implementation idea or trade-off matters most to the developer?");
        fact("Reported IT concern", "What production concern has IT identified, and who supplied it?");
        fact("Operations acceptance", "What measurable result would satisfy that concern on the intended target?");
        method("Design",
               {"Separate the rule from external I/O.", "Test behavior independently.", "Adapters require integration tests."},
               {"Prototype one complete user interaction.", "Expose integration assumptions early.", "Coupling may require later rework."});
        method("Implementation", {target.isEmpty()
            ? "Implement one testable behavior at a time. Defer toolchain and platform choices until the target is known."
            : "Implement one testable behavior at a time using a toolchain compatible with the specified target.",
            "Small changes make regressions easier to isolate.", "Cross-component behavior needs a later integration check."},
            {"Build a disposable integration spike first.", "Discover feasibility problems early.", "Budget time to rebuild and verify the production path."});
        method("QA",
               {"Replay each leaf's example and failure condition.", "Direct trace from requirement to regression.", "Examples can miss whole input classes."},
               {"Test a property over a range of inputs.", "Explore more cases with one oracle.", "The property and input generator need independent review."});
        rollout();
        lines << "Delivery sequence: resolve open behavior questions; implement and verify the leaf steps; integrate siblings; "
                 "compare the result with the reported IT acceptance condition; rehearse on the target class; submit the evidence for release.";
        if (!ok) return {};
        const QString description = lines.join('\n');
        if (description.size() > 8192) {
            std::fputs("The interview exceeds the ticket's 8192-character limit. Split it into smaller tickets.\n", stderr);
            return {};
        }
        return QJsonObject{{"op", "create"}, {"summary", algorithm.left(160).trimmed()}, {"description", description}};
    }

private:
    QString ask(const QString &prompt, bool required = false)
    {
        if (!ok || (methodsOnly && !required)) return {};
        const auto bytes = (prompt + " ").toUtf8();
        std::fputs(bytes.constData(), stderr);
        std::fflush(stderr);
        QByteArray line = input.readLine(4097);
        if (line.isEmpty() || line.size() > 4096 || !line.isValidUtf8()) {
            std::fputs("Interview interrupted or invalid input. No ticket was filed.\n", stderr);
            ok = false;
            return {};
        }
        const auto value = QString::fromUtf8(line).trimmed();
        for (const QChar ch : value) {
            if (ch.category() == QChar::Other_Control) {
                ok = false;
                std::fputs("Enter plain text on one line. No ticket was filed.\n", stderr);
                return {};
            }
        }
        if (!required && value == ":defaults") {
            methodsOnly = true;
            return {};
        }
        return value;
    }

    QString fact(const QString &name, const QString &question)
    {
        const auto value = ask(question);
        if (value.isEmpty() || value == "?") {
            lines << "Open question (" + name + "): " + question;
            return {};
        }
        lines << name + " (developer): " + value;
        return value;
    }

    void method(const QString &name, const Method &first, const Method &second)
    {
        const auto describe = [](const Method &m) {
            return m.action + " Benefit: " + m.benefit + " Cost: " + m.cost;
        };
        const auto options = name + " options:\n1. " + describe(first) + "\n2. " + describe(second);
        const auto choice = ask(options + "\nChoose 1, 2, your own method, or Enter for 1.");
        lines << options;
        if (choice == "?") {
            lines << "Open question (" + name + "): Which method fits the project?";
        } else if (choice.isEmpty() || choice == "1" || choice == "2") {
            const auto &selected = choice == "2" ? second : first;
            lines << name + (choice.isEmpty() ? " (AIEng default): " : " (developer): ") + selected.action;
            lines << "Expected trade-off: " + selected.benefit + " " + selected.cost;
        } else {
            lines << name + " (developer): " + choice;
            fact(name + " trade-off", "What benefit and cost should the team expect from this custom method?");
        }
    }

    QString condition(const QString &question)
    {
        while (ok) {
            const auto value = ask(question + " [yes/no/?]").toLower();
            if (value == "yes" || value == "no") return value;
            if (value.isEmpty() || value == "?") return "unknown";
            std::fputs("Enter yes, no or ? for unknown.\n", stderr);
        }
        return "unknown";
    }

    void rollout()
    {
        const auto parallel = condition("Can an independently testable second version coexist on the target?");
        const auto window = condition("Does IT allow a planned interruption to replace the active version?");
        const auto fit = [](const QString &answer) -> QString {
            if (answer == "yes") return "prerequisite reported available";
            if (answer == "no") return "blocked by reported constraint";
            return "prerequisite unconfirmed";
        };
        const auto options = "Deployment options:\n1. Parallel rollout: check before switching traffic; costs spare capacity and compatibility work ("
            + fit(parallel) + ").\n2. Maintenance window: uses one target; interrupts service and needs timed recovery (" + fit(window) + ").";
        lines << options;
        const auto choice = ask(options + "\nChoose 1, 2, another approach, or Enter for a conditional recommendation.");
        const QString label = choice.isEmpty() ? "Deployment (AIEng default): " : "Deployment (developer): ";
        const bool useParallel = choice == "1" || (choice.isEmpty() && parallel == "yes");
        const bool useWindow = choice == "2" || (choice.isEmpty() && !useParallel && window == "yes");
        if (useParallel || useWindow) {
            const auto name = useParallel ? QStringLiteral("parallel rollout") : QStringLiteral("maintenance window");
            const auto applies = useParallel ? parallel : window;
            lines << label + name + " — " + fit(applies);
            if (applies != "yes") lines << "Open question (rollout): Resolve the selected method's prerequisite with IT.";
        } else if (choice.isEmpty() || choice == "?") {
            lines << label + "Rehearse on a disposable target; production rollout remains open.";
            lines << "Open question (rollout): Which approach can meet the developer and IT constraints?";
        } else {
            lines << label + choice;
            fact("Custom rollout feasibility", "Which prerequisite, trade-off and recovery check apply to this approach?");
        }
    }

    void requirement(const QString &id, const QString &behavior)
    {
        lines << id + ": " + behavior;
        const auto rule = ask(id + " What rule maps the inputs to the outputs? Enter :split for smaller requirements.");
        if (!ok) return;
        if (rule == ":split") {
            int children = 0;
            while (ok && !methodsOnly) {
                const auto child = ask(id + " Give one smaller behavior, or press Enter to finish this group.");
                if (child.isEmpty() || child == "?") break;
                if (++nodes > 40) {
                    std::fputs("Split this interview into smaller tickets. No ticket was filed.\n", stderr);
                    ok = false;
                    return;
                }
                requirement(id + "." + QString::number(++children), child);
            }
            if (!children || methodsOnly) lines << "Open question (" + id + "): Which smaller behaviors complete this requirement?";
            return;
        }
        if (rule.isEmpty() || rule == "?") lines << "Open question (" + id + "): What rule determines the expected output?";
        else lines << id + " rule (developer): " + rule;
        const auto example = fact(id + " example", "Give an example input and its expected result.");
        const auto failure = fact(id + " failure", "What observable result would show this requirement was violated?");
        if (rule.isEmpty() || rule == "?" || example.isEmpty() || failure.isEmpty())
            lines << id + " next step: resolve the open questions for this behavior before implementing it.";
        else
            lines << id + " next step: implement the stated rule; exercise the example, check the expected result and watch for the stated failure.";
    }

    QFile input;
    QStringList lines;
    bool methodsOnly;
    bool ok = true;
    int nodes = 1;
};
}

std::optional<QJsonObject> intake::designTicket(bool useDefaults)
{
    return Interview(useDefaults).run();
}
