# AIEng Quality-Assurance Plan

## Principle: reflexive QA and security without self-certification

AIEng must develop projects that ship with self-QA and secure-by-design controls,
and must run its own code through the same governed assurance pipeline. This
includes threat modeling, least privilege, dependency/secret governance,
security testing, SBOM/provenance/signing, vulnerability response, backup and
recovery, and adversarial agent evaluation. The AI may create tests, execute
tests, harden candidates, and assemble evidence. It may not waive a failed gate,
approve its own patch, approve QA, declare itself secure, or authorize a release.

## Evidence hierarchy

1. Reproducible machine evidence: immutable inputs, commands, environment,
   outputs, logs, exit status, timing, and digests.
2. Independent deterministic verification: a separate runner rechecks artifact,
   provenance, signature, SBOM, policy, and selected tests.
3. Human QA judgment: named reviewer records scope, observations, exceptions,
   and immutable artifact digest.
4. Release authority: a different named person approves exactly the QA-approved
   digest for a named environment and window.

## Test portfolio

### Native code and domain

- C++ unit/property/boundary tests with Qt Test and deterministic seeds.
- State-machine transition matrices and forbidden-transition tests.
- SQLite/PostgreSQL migration, transaction, crash-recovery, and concurrency tests.
- Serialization compatibility, canonicalization, audit-chain, and tamper tests.
- Compiler matrix: supported GCC and Clang with warnings-as-errors, sanitizers,
  static analysis, and release hardening flags.

### Client-server and identity

- Transport-independent application-boundary tests: unauthenticated and
  malformed principals, role derivation, bounded commands, trusted UTC event
  context, conflict mapping, integrity failure, and public-error redaction.
- API contract and backward-compatibility tests.
- OIDC discovery/JWKS rotation, audience/issuer/time validation, PKCE, logout,
  token replay, session expiry, and step-up WebAuthn tests.
- Per-role positive/negative authorization tests and tenant isolation.
- Two-person QA/release separation and emergency-access audit tests.

### Agentic AI

- Fixed gold corpora for patch correctness and regression.
- Adversarial tickets/repositories containing prompt injection, poisoned memory,
  misleading build logs, fake policies, malicious symlinks, secret bait, huge
  files, Unicode/path tricks, and tool-call injection.
- Tool allowlist, normalized path, diff-size, generated/binary-file, secret,
  dependency, and network-egress policy tests.
- Model/version/prompt/context manifest captured for every proposal.
- Nondeterministic evaluations use repeated trials, confidence intervals, and a
  frozen human-authored acceptance contract; they cannot override deterministic
  security failures.

### Sandbox and supply chain

- Escape/denial fixtures against systemd, AppArmor, seccomp, cgroup, filesystem,
  device, IPC, network, and VM boundaries.
- Dependency lock, license policy, known-vulnerability, malicious-package, and
  dependency-confusion tests.
- SPDX SBOM completeness, SLSA/in-toto provenance, artifact digest, signature,
  transparency/timestamp, and verifier-policy tests.
- Rebuild comparison and `SOURCE_DATE_EPOCH`/locale/time-zone variance tests.

### Product and operations

- Qt Creator plugin compatibility and clean-room plugin instance tests.
- C, C++, Qt 6, and C# golden projects: create, configure, build, test, debug,
  package, patch, reject, approve, deploy to QA, and roll back.
- Ticket portal accessibility, browser security, usability, and workflow tests.
- Backup/restore, point-in-time recovery, upgrade/downgrade, disaster recovery,
  key rotation/revocation, audit export, and production rollback drills.
- Load, latency, long-run soak, queue fairness, resource exhaustion, and failure
  injection tests.

## QA environments

- `dev`: disposable developer state; no release credentials.
- `ci`: clean deterministic native builds and fast security gates.
- `hostile`: isolated sandbox/VM executing adversarial fixtures.
- `qa`: production-like topology with synthetic/redacted data and no production
  route or credentials.
- `release-verifier`: read-only independent verifier with trust roots but no
  signing or deployment authority.
- `production`: receives only a previously approved immutable digest.

## Release gate

A release is blocked unless all mandatory tests pass; no unexplained test is
skipped; the artifact digest matches all evidence; SBOM/provenance/signature
verify; vulnerabilities and exceptions meet policy; backup/rollback evidence is
current; QA and release identities are distinct; and the no-Python gate passes.

## AIEng dogfood milestone

The first credible end-to-end milestone is not “the UI opens.” It is: AIEng
accepts an AIEng ticket, creates an isolated candidate patch, builds and tests
it in a clean environment, emits the evidence bundle, receives independent QA,
promotes the exact digest to an isolated QA installation, exercises upgrade and
rollback, and verifies its own audit trail—without granting the agent approval
or production authority.

## Currently admitted local evidence

The native debug, ASan/UBSan, and hardened release presets currently exercise
three CTest targets: domain/store, application-boundary, and identity-policy
suites. They contain 52 passing QtTest phases at the 2026-11-19 12:47 MST
checkpoint.
LeakSanitizer is not claimed because it requires a non-ptrace VM or bare-metal
runner. API, identity-provider, PostgreSQL, sandbox, and end-to-end evidence is
not yet admitted.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

## Future revision — DTA/DTE for agent-assisted QA

Current status is unassessed for DTE Core v1 conformance. The planned first
scope is the decision to send a proposed ticket fix to independent human QA.
The Qt staff-form revision has no DTE runtime dependency.

Use the Decision-Tree Analysis method to freeze the ticket context, goals,
alternatives, acceptance criteria, authority and resource bounds before an
agent proposes a fix. Use the native Decision-Tree Engine to evaluate
criterion-linked evidence and validate adapter scope. Preserve TRUE, FALSE,
UNKNOWN and CONFLICT explicitly, together with corrections and their history.

Acceptance requires AIEng-specific positive, missing, contradictory, tampered
and out-of-scope fixtures. Re-run the same frozen inputs, versions and bounds
on an independent runner and compare canonical decision and transition bytes.
Record the tested scope, version and evidence before claiming conformance.
Human QA and release approval remain separate workflow steps.

Reference baseline in the sibling RPA2/general/dta project is
`examples/dte_core_v1_freeze_manifest_20261023_2138_MDT.json`, SHA-256
`d3c50ab156ff9981b619b9bed249552d93ca6fc6eae90ff590b7364c807227f0`.

