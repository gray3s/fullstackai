# ADR 0001: AI has proposal authority only

- Status: accepted
- Date: 2026-11-19

## Decision

AI identities may claim authorized jobs, create candidate changes, and attach
test evidence. They may not approve QA, approve releases, retrieve production
credentials, deploy, or roll back production.

## Rationale

Software agents are valuable high-throughput contributors but are not reliable
security principals for irreversible business decisions. Keeping approval and
deployment authority with attributable people limits prompt-injection and
supply-chain failures and makes the system auditable.

