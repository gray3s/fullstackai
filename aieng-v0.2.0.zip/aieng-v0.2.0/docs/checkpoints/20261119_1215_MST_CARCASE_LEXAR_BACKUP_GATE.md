# CarCase Lexar Backup Gate

**Recorded:** 2026-11-19 12:15 MST  
**Reason:** protect the system-drive CarCase tree before AIEng work that could
affect shared host state

## Authoritative source and mirror

- Source: `/home/sag/RPA2/general/legal/carcase/`
- Mirror: `/mnt/carcase-mirror/carcase/`
- Device: `/dev/sdb1`, label `CARCASE_MIRROR`
- Final mount state: read-only (`ro,nosuid,nodev,relatime`)
- The companion `/dev/sdb2` remains active swap and was not repartitioned,
  formatted, resized, or overwritten.

## Synchronization evidence

The historical 2026-11-03 mirror was first compared read-only and found stale.
Current additions included filing candidates, rendered documents, QA records,
working drafts, and resume records through 2026-11-15.

1. Metadata/hard-link-preserving synchronization:
   `rsync -aHAX --delete`
   - 10,642 entries examined
   - 30 entries created (23 files, 7 directories)
   - 35 regular files transferred
   - 0 deleted
2. Read-only checksum verification found five files whose content differed
   despite matching ordinary metadata.
3. Checksum-forced synchronization:
   `rsync -aHAXc --delete`
   - 5 regular files transferred
   - 758,774,266 bytes refreshed
   - 0 created and 0 deleted
4. The filesystem was flushed and returned to read-only after each write pass.

## Independent final comparisons

- Regular files: source 8,818; mirror 8,818.
- Directories: source 1,824; mirror 1,824.
- Logical regular-file bytes: source 9,920,484,680; mirror 9,920,484,680.
- The sole remaining `rsync -nci` itemization was a hard-linked 670,366,384-byte
  archived ZIP. Direct verification showed:
  - source and mirror SHA-256:
    `1220b4d304c103d6c4d781aa1daf5092c48ee44bbe2ba2b2bf5aaa5917e98d6f`
  - source and mirror MD5:
    `fd95acf5e90097289ac4988686c344bd`
  - POSIX byte comparison: `cmp` exit 0.

The counts, logical size, two digests, and byte comparison establish content
equivalence for the anomalous hard-linked file; the residual rsync itemization
is recorded rather than hidden.

## Gate result

**PASS for proceeding with AIEng project-local development.** Any later action
that can materially affect system-drive CarCase data, shared host storage,
partitioning, or filesystems requires a fresh backup check. The Lexar mirror is
not to be used as a VM disk, build workspace, package cache, model store, or
general scratch area.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

