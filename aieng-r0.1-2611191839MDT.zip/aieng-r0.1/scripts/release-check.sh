#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
./scripts/no-python-check.sh
cmake --preset release
cmake --build --preset release
ctest --preset release

for binary in aieng-staff aieng-ticket aieng-ticket-service; do
    executable="$project_dir/build/release/apps/control-plane/$binary"
    readelf -hW "$executable" | rg 'Type:[[:space:]]+DYN' >/dev/null
    readelf -lW "$executable" | rg 'GNU_RELRO' >/dev/null
    readelf -dW "$executable" | rg 'BIND_NOW' >/dev/null
    readelf -lW "$executable" | rg 'GNU_STACK.* RW ' >/dev/null
done
printf 'Native release verification passed: PIE, RELRO, NOW, non-executable stack.\n'

