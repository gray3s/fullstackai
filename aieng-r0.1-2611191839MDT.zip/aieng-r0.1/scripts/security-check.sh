#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
./scripts/no-python-check.sh
cmake --preset security
cmake --build --preset security
ASAN_OPTIONS=detect_leaks=0 ctest --preset security
printf 'Native ASan/UBSan verification passed; LeakSanitizer requires a non-ptrace runner.\n'

