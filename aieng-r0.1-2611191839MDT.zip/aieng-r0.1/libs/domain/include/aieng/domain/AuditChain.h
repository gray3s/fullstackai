// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#pragma once

#include <QByteArray>
#include <QList>
#include <QString>

namespace aieng::domain {

struct AuditEvent final {
    quint64 sequence{0};
    QString eventId;
    QString occurredAtUtc;
    QString actorId;
    QString action;
    QString objectType;
    QString objectId;
    QByteArray canonicalPayload;
    QByteArray previousMacHex;
    QByteArray macHex;
};

class AuditChain final {
public:
    explicit AuditChain(QByteArray secret);

    [[nodiscard]] AuditEvent append(
        const QString &eventId,
        const QString &occurredAtUtc,
        const QString &actorId,
        const QString &action,
        const QString &objectType,
        const QString &objectId,
        const QByteArray &canonicalPayload);

    [[nodiscard]] const QList<AuditEvent> &events() const noexcept { return m_events; }

    [[nodiscard]] bool verify() const;
    [[nodiscard]] static bool verify(const QList<AuditEvent> &events, const QByteArray &secret);

private:
    QByteArray m_secret;
    QList<AuditEvent> m_events;
};

} // namespace aieng::domain

