# AIEng Native Transport Research Gate Checkpoint

**Recorded:** 2026-11-19 12:32 MST  
**Owner:** Samuel A. Gray III  
**Window report:** 70% remaining at the start of this increment

## Preserved result

- Primary-source research now records Qt's explicit warning that Qt HTTP
  Server is not hardened for direct Internet exposure.
- The installed Qt 6.4.2 baseline predates the rate and request-size controls
  introduced in Qt 6.10 and 6.11.
- ADR 0002 proposes Drogon only as a native transport candidate. It is not an
  admitted dependency and nothing was installed on the host.
- The candidate must pass a disposable Ubuntu 26.04 VM qualification gate
  covering provenance, licenses, malformed input, finite resources,
  confinement, authentication failures, sanitizers, SBOM, and upgrade/removal.
- Policy and persistence remain transport-independent.
- `NOTICE` now explicitly preserves every third party's separate ownership and
  licensing; AIEng's proprietary notice applies only to original AIEng work.
- No third-party source is vendored in the repository.

## Verification evidence

At this checkpoint:

- `git diff --check`: passed.
- `scripts/no-python-check.sh`: passed.
- `scripts/verify.sh`: passed; 17 QtTest phases.
- `scripts/security-check.sh`: ASan/UBSan passed; LeakSanitizer remains pending
  on a non-ptrace VM or bare-metal runner and is not claimed as passed.
- `scripts/release-check.sh`: tests passed; PIE, RELRO, immediate binding, and
  non-executable stack checks passed.
- No system package, VM, network listener, external repository, or production
  environment was changed.
- The verified CarCase Lexar mirror remains outside this increment and mounted
  read-only; no action here risked the CarCase source or mirror.

## Honest current state

AIEng has a verified native workflow/persistence security core and documented
architecture controls. It does not yet have an admitted network transport,
identity integration, agent runner, Qt Creator extension, production database,
or turnkey deployment. Those are future gated increments, not implied by this
checkpoint.

## Next authorized action

Add a transport-independent application-command boundary with negative tests,
then prepare a reproducible disposable-VM qualification manifest. Do not
install Drogon or expose a listener until ADR 0002's evidence gate passes.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

