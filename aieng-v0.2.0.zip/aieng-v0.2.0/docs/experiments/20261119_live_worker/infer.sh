#!/usr/bin/env bash
set -euo pipefail
bin=/home/sag/RPA2/devneutral/servers/llama.cpp/relocated-gpt-llama.cpp-20260905_114935_MDT/build-local-native/bin
model=/home/sag/RPA2/devneutral/models/Ministral-3-3B-Instruct-2512-Q4_K_M-9ed150d4367e68df.gguf
timeout 120 "$bin/llama-cli" -m "$model" --offline -c 2048 -t 4 --temp 0 --seed 73 -n 350 --single-turn --simple-io --no-display-prompt --no-warmup --log-disable -f "$1.prompt" >"$1.raw" 2>"$1.log" </dev/null
