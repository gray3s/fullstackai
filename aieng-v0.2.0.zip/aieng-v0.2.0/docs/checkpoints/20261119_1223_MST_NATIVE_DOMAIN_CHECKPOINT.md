# AIEng Native Domain Checkpoint

**Created:** 2026-11-19 12:23 MST  
**Scope:** transport-independent authorization/workflow/audit foundation

## Implemented

- C++20 and Qt 6.4 minimum native build with CMake Presets and Ninja.
- Strict GCC/Clang warnings including warnings-as-errors and conversion checks.
- Typed human and non-human roles.
- Server-owned ticket state transition table.
- Optimistic ticket version checks.
- Agent proposal-only authority.
- Immutable artifact-digest binding from QA start through deployment workflow.
- Separation of patch author, QA approver, and release approver.
- Length-delimited canonical audit event encoding and HMAC-SHA-256 chaining.
- Guided-creator product requirements and CTO-governed production path.

## Acceptance evidence

Commands executed from `/home/sag/aieng`:

```text
cmake --preset dev
cmake --build --preset dev
ctest --preset dev
./scripts/no-python-check.sh
git diff --check
```

Result:

- Native configure/build: pass with GCC 13.3.0 and Qt 6.4.2.
- Qt Test/CTest: 1 executable, 8 test functions, pass.
- No-Python gate: pass.
- Git whitespace check: pass.

Negative evidence preserved during development: the first test build failed
because strict warnings rejected partially initialized security fixtures. The
gate was not weakened; fixtures were made explicit and the rebuild passed.

## Security truth

This checkpoint verifies in-memory domain invariants only. It does not yet
provide durable transactions, authenticated network transport, a service,
agent tooling, a Qt Creator plugin, a portal, sandboxing, artifact signing, or
deployment. The audit chain is tamper-evident only when its key and head are
protected/exported by later infrastructure.

## Next authorized action

Implement and test a native QtSql repository with schema migrations,
transactional ticket+audit commits, optimistic compare-and-swap updates,
database constraints, crash recovery, and independent audit verification.
Keep the transport adapter undecided until the service-framework ADR is
completed from primary-source and local-package evidence.

Copyright © 2026 Samuel A. Gray III. All rights reserved.

