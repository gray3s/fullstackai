add_library(aieng_domain STATIC
    src/AuditChain.cpp
    src/TicketStore.cpp
    src/Workflow.cpp
)

target_include_directories(aieng_domain
    PUBLIC
        ${CMAKE_CURRENT_SOURCE_DIR}/include
)

target_link_libraries(aieng_domain
    PUBLIC
        Qt6::Core
        Qt6::Sql
    PRIVATE
        aieng_warnings
        aieng_security_flags
)

