# Support triage and queue assignment

The local client and service carry a reported ticket through OPEN, TRIAGED and AGENT_QUEUED using the existing audited workflow. The service
matches the operator's kernel UID to the project listener's support UID. Requests include the observed ticket version and operator rationale.

The private socket test exercised reporter denial, mismatched UID denial, cross-project denial, valid triage, stale queue rejection, valid
assignment and reporter readback. All four suites passed under debug, ASan/UBSan and hardened release. The no-Python audit passed.

Resume with project-scoped discovery and exclusive claims for queued work. A queued ticket currently awaits an agent worker.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
