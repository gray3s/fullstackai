# Discover project work orders

Starting at d6b3ea2, extend the native intake service and CLI to page through open, triaged and queued project tickets. Check project support
authority before reading the store, validate row integrity and return bounded summaries. Verify paging, role denial and project isolation on
private test sockets. Checkpoint after the debug, sanitizer, release and no-Python gates. CarCase and DTA/DTE are outside this increment.

Copyright © 2026 Samuel A. Gray III. All rights reserved.
