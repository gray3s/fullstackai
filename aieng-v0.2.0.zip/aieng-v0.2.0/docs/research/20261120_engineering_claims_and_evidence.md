# Which production-readiness questions can an AIEng worker settle?

Research note, 20 November 2026. The conclusions below are proposals for the AIEng experiment. The publications describe their own
systems and methods. They do not establish how an AIEng worker will perform.

## Where does the expected answer come from?

NIST's systems-engineering definitions distinguish evidence about specified requirements from evidence about the intended use.
NASA's verification and validation plan outline makes this useful at project scale by connecting requirements and methods to
responsibilities and the circumstances of evaluation. For AIEng the minimum useful record is small: name the requirement, where it
came from, the subject under test, what observation would refute it, and how the expected result was determined.
[NIST verification](https://csrc.nist.gov/glossary/term/verification) · [NIST validation](https://csrc.nist.gov/glossary/term/validation) ·
[NASA V&V plan outline](https://www.nasa.gov/reference/appendix-i-verification-and-validation-plan-outline/)

A test oracle is the rule or reference used to judge an observed result. In Carton Count an independent arithmetic check suffices.
For n items, positive capacity k and proposed carton count c, check that c is a nonnegative integer, c × k ≥ n, and either c = 0
or (c − 1) × k < n. Use arithmetic wide enough for the products. This catches both under-allocation and needless extra cartons.
Whether different customers may share cartons is a business rule. If the policy is missing, preserve both plausible answers and
identify the decision needed. An AI or human worker earns credit for recognizing the ambiguity.

## What does definitive mean?

The 2009 seL4 paper demonstrates a machine-checked argument connecting a formal specification to a particular kernel implementation.
The authors state assumptions about the compiler, assembly and hardware. This is a constructive example of a strong conclusion with
explicit boundaries. AIEng should label its evidence as a counterexample, sampled observation, exhaustive check or proof. A proof
about arithmetic does not automatically establish a claim about the installed binary and its environment.
[Klein et al., seL4: Formal Verification of an OS Kernel](https://isabelle.in.tum.de/~kleing/papers/sosp09.html)

A single valid counterexample settles a universal correctness claim in the negative. To establish a positive universal claim, the
argument must cover the declared domain and execution assumptions. A diagnostic is resolved technically when the changed release
passes the decisive check and relevant regressions have been examined. Closing a ticket because the owner accepts the risk is a
different, recorded disposition. Either action can be automated under a prior policy; changing which risks are acceptable requires
authority delegated for that decision.

## What should be assessed before and after deployment?

NIST SP 800-53A offers assessment procedures that organizations can tailor to risk tolerance. NIST's Risk Management Framework
distinguishes assessment and authorization. For this pilot, select a small number of consequential rules, such as who may authorize a
release and which artifact may be installed. Record the effective permissions and an observed decision for relevant identities.
Record an exception separately from the control finding. This is a research design for a local platform.
[NIST assessment procedures](https://csrc.nist.gov/pubs/sp/800/53/a/r5/final) · [NIST Risk Management Framework](https://csrc.nist.gov/pubs/sp/800/37/r2/final)

Google's canary guidance explains how grouping observations by release can reveal a change hidden in a service-wide average. For AIEng,
record baseline and post-install workload, request counts, errors, observation duration, release identity and concurrent changes. Where
feasible, keep a comparable old instance alongside the candidate. For an illustrative 2 failures in 100 requests before installation
and 20 in 1,000 afterward, both observed rates are 2%. Those counts alone do not show whether the failing requests share a cause.
A permission newly visible after deployment similarly needs comparison against the intended access policy.
[Google SRE, Canarying Releases](https://sre.google/workbook/canarying-releases/)

Put an absolute requirement beside the change measurement. A deployment might preserve an already unacceptable error rate.
Conversely, a newly deployed service has no personal pre-install error rate. Assess it against its contract while measuring the impact
on existing services. When rollback is feasible, check data as well as executable identity if a migration was involved.

## What would count as evidence that a human was needed?

In an original controlled study, METR researchers randomized access to early-2025 AI tools across developers' tasks. Their endpoint
was time taken by experienced contributors on familiar repositories. The transferable lesson is to specify the people, tasks, tools
and outcome in advance. That study cannot decide the different AIEng question about a live worker performing QA and deployment.
[Becker et al., experimental design and study population](https://arxiv.org/abs/2507.09089)

Proposed AIEng comparison: blind the build labels, freeze intent and held-back cases, equalize information and resource limits, and
record worker-selected probes before revealing observations. Permit either worker to ask for missing policy, run another test, or
abstain. Report the fraction of defective builds passed, acceptable builds rejected, inconclusive runs and interventions, each with
its denominator. Grade factual judgments separately from elapsed time, independent approval and installer actions. A human rescue
demonstrates assistance in that run. A claim that only a human could solve the task would require much stronger evidence.
