// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/Workflow.h"

#include <array>

namespace aieng::domain {
namespace {

struct Rule final {
    TicketState from;
    TicketState to;
    std::array<Role, 2> roles;
    qsizetype roleCount;
    bool artifactRequired;
};

constexpr std::array<Rule, 8> rules{{
    {TicketState::Open, TicketState::Triaged, {Role::Support, Role::Support}, 1, false},
    {TicketState::Triaged,
     TicketState::AgentQueued,
     {Role::Support, Role::Developer},
     2,
     false},
    {TicketState::AgentQueued,
     TicketState::PatchProposed,
     {Role::Agent, Role::Developer},
     2,
     true},
    {TicketState::PatchProposed, TicketState::QaRunning, {Role::Qa, Role::Qa}, 1, true},
    {TicketState::QaRunning, TicketState::QaApproved, {Role::Qa, Role::Qa}, 1, true},
    {TicketState::QaApproved,
     TicketState::ReleaseApproved,
     {Role::Release, Role::Release},
     1,
     true},
    {TicketState::ReleaseApproved,
     TicketState::Deploying,
     {Role::Operator, Role::Operator},
     1,
     true},
    {TicketState::Deploying,
     TicketState::Deployed,
     {Role::Operator, Role::Operator},
     1,
     true},
}};

[[nodiscard]] bool hasHumanWorkflowRole(const Actor &actor)
{
    return actor.roles.contains(Role::Support) || actor.roles.contains(Role::Developer)
        || actor.roles.contains(Role::Qa) || actor.roles.contains(Role::Release)
        || actor.roles.contains(Role::Operator);
}

[[nodiscard]] const Rule *findRule(TicketState from, TicketState to)
{
    for (const auto &rule : rules) {
        if (rule.from == from && rule.to == to) {
            return &rule;
        }
    }
    return nullptr;
}

[[nodiscard]] bool hasRequiredRole(const Actor &actor, const Rule &rule)
{
    for (qsizetype index = 0; index < rule.roleCount; ++index) {
        if (actor.roles.contains(rule.roles.at(static_cast<std::size_t>(index)))) {
            return true;
        }
    }
    return false;
}

[[nodiscard]] Decision deny(DecisionCode code, const QString &message)
{
    return {code, message};
}

} // namespace

Decision Workflow::evaluate(
    const Ticket &ticket,
    const TransitionRequest &request,
    const Actor &actor)
{
    if (ticket.version != request.expectedVersion) {
        return deny(DecisionCode::StaleVersion, QStringLiteral("ticket version is stale"));
    }
    if (request.rationale.trimmed().size() < 5) {
        return deny(DecisionCode::MissingRationale, QStringLiteral("rationale is required"));
    }

    if (request.target == TicketState::NeedsHuman || request.target == TicketState::Rejected) {
        if (!hasHumanWorkflowRole(actor)) {
            return deny(
                DecisionCode::MissingRole,
                QStringLiteral("a human workflow role is required"));
        }
        return {DecisionCode::Allowed, QStringLiteral("allowed")};
    }

    const Rule *const rule = findRule(ticket.state, request.target);
    if (rule == nullptr) {
        return deny(
            DecisionCode::InvalidTransition,
            QStringLiteral("transition is not in the policy table"));
    }
    if (!hasRequiredRole(actor, *rule)) {
        return deny(
            DecisionCode::MissingRole,
            QStringLiteral("actor lacks a role permitted for this transition"));
    }
    if (rule->artifactRequired && request.artifactDigest.isEmpty()) {
        return deny(
            DecisionCode::MissingArtifactDigest,
            QStringLiteral("an immutable artifact digest is required"));
    }
    if (!rule->artifactRequired && !request.artifactDigest.isEmpty()) {
        return deny(
            DecisionCode::UnexpectedArtifactDigest,
            QStringLiteral("this transition cannot bind an artifact digest"));
    }
    if (!ticket.artifactDigest.isEmpty() && !request.artifactDigest.isEmpty()
        && ticket.artifactDigest != request.artifactDigest) {
        return deny(
            DecisionCode::ArtifactDigestChanged,
            QStringLiteral("the approved artifact digest cannot change"));
    }
    if (request.target == TicketState::ReleaseApproved
        && (actor.id == ticket.patchAuthorId || actor.id == ticket.qaApproverId)) {
        return deny(
            DecisionCode::SeparationOfDuties,
            QStringLiteral("patch author and QA approver cannot approve release"));
    }

    return {DecisionCode::Allowed, QStringLiteral("allowed")};
}

Decision Workflow::apply(
    Ticket &ticket,
    const TransitionRequest &request,
    const Actor &actor)
{
    const Decision decision = evaluate(ticket, request, actor);
    if (!decision.allowed()) {
        return decision;
    }

    ticket.state = request.target;
    ++ticket.version;
    if (request.target == TicketState::PatchProposed) {
        ticket.patchAuthorId = actor.id;
    }
    if (!request.artifactDigest.isEmpty() && ticket.artifactDigest.isEmpty()) {
        ticket.artifactDigest = request.artifactDigest;
    }
    if (request.target == TicketState::QaApproved) {
        ticket.qaApproverId = actor.id;
    }
    if (request.target == TicketState::ReleaseApproved) {
        ticket.releaseApproverId = actor.id;
    }
    return decision;
}

QString Workflow::stateName(TicketState state)
{
    switch (state) {
    case TicketState::Open: return QStringLiteral("OPEN");
    case TicketState::Triaged: return QStringLiteral("TRIAGED");
    case TicketState::AgentQueued: return QStringLiteral("AGENT_QUEUED");
    case TicketState::PatchProposed: return QStringLiteral("PATCH_PROPOSED");
    case TicketState::QaRunning: return QStringLiteral("QA_RUNNING");
    case TicketState::QaApproved: return QStringLiteral("QA_APPROVED");
    case TicketState::ReleaseApproved: return QStringLiteral("RELEASE_APPROVED");
    case TicketState::Deploying: return QStringLiteral("DEPLOYING");
    case TicketState::Deployed: return QStringLiteral("DEPLOYED");
    case TicketState::NeedsHuman: return QStringLiteral("NEEDS_HUMAN");
    case TicketState::Rejected: return QStringLiteral("REJECTED");
    case TicketState::RollbackRequired: return QStringLiteral("ROLLBACK_REQUIRED");
    }
    return QStringLiteral("UNKNOWN");
}

std::optional<TicketState> Workflow::stateFromName(const QString &name)
{
    constexpr std::array<TicketState, 12> states{{
        TicketState::Open,
        TicketState::Triaged,
        TicketState::AgentQueued,
        TicketState::PatchProposed,
        TicketState::QaRunning,
        TicketState::QaApproved,
        TicketState::ReleaseApproved,
        TicketState::Deploying,
        TicketState::Deployed,
        TicketState::NeedsHuman,
        TicketState::Rejected,
        TicketState::RollbackRequired,
    }};
    for (const TicketState state : states) {
        if (stateName(state) == name) {
            return state;
        }
    }
    return std::nullopt;
}

} // namespace aieng::domain

