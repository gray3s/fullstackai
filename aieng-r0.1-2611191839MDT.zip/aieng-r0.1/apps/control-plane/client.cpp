// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "Packet.h"
#include <QCoreApplication>
#include <QFile>
#include <sys/un.h>
#include <unistd.h>
#include <cstdio>
#include <cstring>

int main(int argc, char **argv)
{
    QCoreApplication process(argc, argv);
    const auto args = process.arguments();
    const auto op = args.value(2);
    const bool transition = (op == "triage" || op == "queue") && args.size() == 5;
    const bool list = op == "list" && (args.size() == 4 || args.size() == 5);
    if (!list && !transition && (args.size() != 4 || (op != "create" && op != "show"))) {
        std::fputs("Usage: aieng-ticket SOCKET create SUMMARY < description.txt\n"
                   "       aieng-ticket SOCKET show TICKET-ID\n"
                   "       aieng-ticket SOCKET list OPEN|TRIAGED|AGENT_QUEUED [AFTER-ID]\n"
                   "       aieng-ticket SOCKET triage|queue TICKET-ID VERSION < rationale.txt\n", stderr);
        return 2;
    }
    QJsonObject request{{"op", args[2]}};
    if (list) {
        request.insert("state", args[3]);
        request.insert("after", args.value(4));
    } else if (op != "show") {
        QFile input;
        if (!input.open(stdin, QIODevice::ReadOnly)) return 2;
        const auto bytes = input.read(32769);
        if (bytes.size() > 32768 || !bytes.isValidUtf8()) {
            std::fputs("Enter bounded UTF-8 text on standard input.\n", stderr);
            return 2;
        }
        if (transition) {
            request.insert("id", args[3]);
            request.insert("version", args[4]);
            request.insert("rationale", QString::fromUtf8(bytes).trimmed());
        } else {
            request.insert("summary", args[3]);
            request.insert("description", QString::fromUtf8(bytes));
        }
    } else {
        request.insert("id", args[3]);
    }
    sockaddr_un address{};
    address.sun_family = AF_UNIX;
    const auto path = QFile::encodeName(args[1]);
    if (path.isEmpty() || path.size() >= static_cast<qsizetype>(sizeof(address.sun_path))) return 2;
    std::memcpy(address.sun_path, path.constData(), static_cast<size_t>(path.size()));
    const int fd = socket(AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0);
    if (fd < 0 || !intake::setTimeouts(fd) || connect(fd, reinterpret_cast<sockaddr *>(&address), sizeof(address)) != 0
        || !intake::sendPacket(fd, request)) {
        std::perror("Ticket service connection");
        return 1;
    }
    const auto response = intake::receivePacket(fd);
    close(fd);
    if (response.isEmpty()) {
        std::fputs("Ticket service did not confirm the request.\n", stderr);
        return 1;
    }
    const bool failed = response.contains("error");
    std::fputs(QJsonDocument(response).toJson().constData(), failed ? stderr : stdout);
    return failed ? 1 : 0;
}
