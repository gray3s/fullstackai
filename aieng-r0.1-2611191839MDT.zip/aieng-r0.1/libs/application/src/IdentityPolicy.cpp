// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/application/IdentityPolicy.h"

#include <utility>

namespace aieng::application {
namespace {

[[nodiscard]] bool hasControlCharacter(const QString &value)
{
    for (const QChar character : value) {
        if (character.category() == QChar::Other_Control) {
            return true;
        }
    }
    return false;
}

} // namespace

IdentityPolicy::IdentityPolicy(IdentityPolicyConfig config)
    : m_config(std::move(config))
{
}

IdentityDecision IdentityPolicy::evaluate(
    const CryptographicallyVerifiedClaims &claims,
    qint64 nowEpochSeconds) const
{
    if (!configurationIsValid()) {
        return deny(
            IdentityDecisionCode::ConfigurationInvalid,
            QStringLiteral("identity policy configuration is invalid"));
    }
    if (!claims.signatureVerified || !claims.duplicateMembersRejected) {
        return deny(
            IdentityDecisionCode::VerificationMissing,
            QStringLiteral("signature verification and duplicate-member rejection are required"));
    }
    if (claims.tokenType != m_config.tokenType) {
        return deny(
            IdentityDecisionCode::WrongTokenType,
            QStringLiteral("token type does not match the access-token validation profile"));
    }
    if (claims.algorithm == QStringLiteral("none")
        || !m_config.allowedAlgorithms.contains(claims.algorithm)) {
        return deny(
            IdentityDecisionCode::AlgorithmRejected,
            QStringLiteral("token algorithm is not explicitly allowed"));
    }
    if (!isBoundedClaim(claims.keyId, 256)) {
        return deny(
            IdentityDecisionCode::KeyIdentityMissing,
            QStringLiteral("verified signing key identity is missing or invalid"));
    }
    if (claims.issuer != m_config.issuer) {
        return deny(
            IdentityDecisionCode::IssuerMismatch,
            QStringLiteral("issuer does not exactly match policy"));
    }
    if (claims.audiences.isEmpty() || claims.audiences.size() > 16) {
        return deny(
            IdentityDecisionCode::AudienceMismatch,
            QStringLiteral("audience claim count is invalid"));
    }
    for (const QString &audience : claims.audiences) {
        if (!isBoundedClaim(audience, 256)) {
            return deny(
                IdentityDecisionCode::AudienceMismatch,
                QStringLiteral("audience claim is invalid"));
        }
    }
    if (!claims.audiences.contains(m_config.audience)) {
        return deny(
            IdentityDecisionCode::AudienceMismatch,
            QStringLiteral("required resource audience is absent"));
    }
    if (!isBoundedClaim(claims.subject, 256)) {
        return deny(
            IdentityDecisionCode::SubjectInvalid,
            QStringLiteral("subject is empty, unbounded, padded, or contains control characters"));
    }
    if (nowEpochSeconds < 0 || claims.issuedAtEpochSeconds <= 0
        || claims.notBeforeEpochSeconds <= 0 || claims.expiresAtEpochSeconds <= 0
        || claims.expiresAtEpochSeconds <= claims.issuedAtEpochSeconds
        || claims.notBeforeEpochSeconds > claims.expiresAtEpochSeconds
        || (claims.issuedAtEpochSeconds > nowEpochSeconds
            && claims.issuedAtEpochSeconds - nowEpochSeconds
                > m_config.allowedClockSkewSeconds)
        || (claims.notBeforeEpochSeconds > nowEpochSeconds
            && claims.notBeforeEpochSeconds - nowEpochSeconds
                > m_config.allowedClockSkewSeconds)
        || (claims.expiresAtEpochSeconds <= nowEpochSeconds
            && nowEpochSeconds - claims.expiresAtEpochSeconds
                >= m_config.allowedClockSkewSeconds)) {
        return deny(
            IdentityDecisionCode::TimeInvalid,
            QStringLiteral("token time claims are inconsistent, future, inactive, or expired"));
    }
    if (claims.expiresAtEpochSeconds - claims.issuedAtEpochSeconds
            > m_config.maximumTokenLifetimeSeconds) {
        return deny(
            IdentityDecisionCode::LifetimeExceeded,
            QStringLiteral("token lifetime exceeds policy"));
    }
    if (claims.groups.size() > 64) {
        return deny(
            IdentityDecisionCode::GroupClaimsInvalid,
            QStringLiteral("group claim count exceeds policy"));
    }

    QHash<QString, QSet<domain::Role>> mappedProjectRoles;
    QSet<domain::Role> allMappedRoles;
    for (const QString &group : claims.groups) {
        if (!isBoundedClaim(group, 128)) {
            return deny(
                IdentityDecisionCode::GroupClaimsInvalid,
                QStringLiteral("group claim is empty, unbounded, padded, or contains controls"));
        }
        const auto mapped = m_config.groupRoles.constFind(group);
        if (mapped != m_config.groupRoles.cend()) {
            mappedProjectRoles[mapped->projectId].unite(mapped->roles);
            allMappedRoles.unite(mapped->roles);
        }
    }
    if (allMappedRoles.isEmpty()) {
        return deny(
            IdentityDecisionCode::NoMappedRole,
            QStringLiteral("no configured AIEng role maps from the verified groups"));
    }
    if (m_config.requireSenderProof
        && (!claims.senderProofVerified
            || !isBoundedClaim(claims.confirmationThumbprint, 256))) {
        return deny(
            IdentityDecisionCode::SenderProofRequired,
            QStringLiteral("sender-constrained access-token proof is required"));
    }
    if (includesPrivilegedRole(allMappedRoles)) {
        if (claims.authenticatedAtEpochSeconds <= 0
            || claims.authenticatedAtEpochSeconds > nowEpochSeconds
            || nowEpochSeconds - claims.authenticatedAtEpochSeconds
                > m_config.maximumPrivilegedAuthenticationAgeSeconds
            || m_config.privilegedAuthenticationContext.isEmpty()
            || claims.authenticationContext != m_config.privilegedAuthenticationContext) {
            return deny(
                IdentityDecisionCode::PrivilegedAuthenticationRequired,
                QStringLiteral("privileged role requires recent configured step-up authentication"));
        }
    }

    IdentityDecision accepted;
    accepted.code = IdentityDecisionCode::Accepted;
    accepted.principal.subject = claims.subject;
    accepted.principal.projectRoles = mappedProjectRoles;
    accepted.principal.trustDomain = claims.issuer;
    accepted.principal.authenticated = true;
    accepted.diagnostic = QStringLiteral("identity claims accepted");
    return accepted;
}

bool IdentityPolicy::configurationIsValid() const
{
    if (!isBoundedClaim(m_config.issuer, 2048)
        || !isBoundedClaim(m_config.audience, 256)
        || !isBoundedClaim(m_config.tokenType, 64)
        || !isBoundedClaim(m_config.privilegedAuthenticationContext, 256)
        || m_config.allowedClockSkewSeconds < 0
        || m_config.allowedClockSkewSeconds > 300
        || m_config.maximumTokenLifetimeSeconds <= 0
        || m_config.maximumTokenLifetimeSeconds > 3600
        || m_config.maximumPrivilegedAuthenticationAgeSeconds <= 0
        || m_config.maximumPrivilegedAuthenticationAgeSeconds > 3600
        || m_config.allowedAlgorithms.isEmpty()
        || m_config.allowedAlgorithms.size() > 8
        || m_config.groupRoles.isEmpty()
        || m_config.groupRoles.size() > 64) {
        return false;
    }
    for (const QString &algorithm : m_config.allowedAlgorithms) {
        if (!isBoundedClaim(algorithm, 32) || algorithm == QStringLiteral("none")) {
            return false;
        }
    }
    for (auto mapped = m_config.groupRoles.cbegin(); mapped != m_config.groupRoles.cend(); ++mapped) {
        if (!isBoundedClaim(mapped.key(), 128)
            || !isBoundedClaim(mapped->projectId, 128)
            || mapped->roles.isEmpty()) {
            return false;
        }
    }
    return true;
}

bool IdentityPolicy::isBoundedClaim(const QString &value, qsizetype maximum)
{
    return !value.isEmpty() && value.size() <= maximum && value == value.trimmed()
        && !hasControlCharacter(value);
}

bool IdentityPolicy::includesPrivilegedRole(const QSet<domain::Role> &roles)
{
    return roles.contains(domain::Role::Qa) || roles.contains(domain::Role::Release)
        || roles.contains(domain::Role::Operator)
        || roles.contains(domain::Role::Administrator);
}

IdentityDecision IdentityPolicy::deny(
    IdentityDecisionCode code,
    const QString &diagnostic)
{
    IdentityDecision denied;
    denied.code = code;
    denied.diagnostic = diagnostic;
    return denied;
}

} // namespace aieng::application
