// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "aieng/domain/TeamReview.h"
#include <QJsonArray>
#include <QJsonDocument>
#include <QRegularExpression>
#include <QSet>
#include <algorithm>

namespace {
using namespace Qt::StringLiterals;
bool named(const QJsonValue &v) {
    return v.isString() && !v.toString().trimmed().isEmpty() && v.toString().size() <= 512;
}
bool identifier(const QString &s) {
    static const QRegularExpression pattern(u"\\A[A-Za-z0-9][A-Za-z0-9_.-]{0,63}\\z"_s);
    return pattern.match(s).hasMatch();
}
bool readSet(const QJsonValue &v, QSet<QString> &set) {
    if (!v.isArray() || v.toArray().isEmpty()) return false;
    for (const auto item : v.toArray()) {
        const auto name = item.toString();
        if (!identifier(name) || set.contains(name)) return false;
        set.insert(name);
    }
    return true;
}
QJsonObject invalid(const QString &message) {
    return {{"status","invalid"},{"error",message}};
}
struct Decision {
    QString id, authority, choice, reason;
    QSet<QString> options, feasible;
    QStringList blockers;
    int concerns = 0;
};
}

QJsonObject aieng::domain::reviewTeamPlan(const QJsonObject &plan, const QJsonObject *observations)
{
    if (QJsonDocument(plan).toJson(QJsonDocument::Compact).size() > 16384 ||
        !named(plan.value("accountable")) || !plan.value("decisions").isArray() || !plan.value("concerns").isArray())
        return invalid("Provide an accountable owner, decisions and concerns within 16 KiB.");
    QMap<QString,Decision> decisions;
    for (const auto entry : plan.value("decisions").toArray()) {
        const auto d = entry.toObject();
        Decision item;
        item.id = d.value("id").toString();
        item.authority = d.value("owner").toString(plan.value("accountable").toString());
        item.choice = d.value("choice").toString();
        item.reason = d.value("reason").toString();
        if (!identifier(item.id) || decisions.contains(item.id) || !named(item.authority)
            || (d.contains("owner") && !named(d.value("owner"))) || !readSet(d.value("options"), item.options)
            || (d.contains("choice") && !d.value("choice").isString())
            || (!item.choice.isEmpty() && !item.options.contains(item.choice))) return invalid("Invalid decision: " + item.id);
        item.feasible = item.options;
        decisions.insert(item.id, item);
    }
    QSet<QString> ids;
    QJsonArray steps, open, conflicts, preferences, choices;
    for (const auto entry : plan.value("concerns").toArray()) {
        const auto c = entry.toObject();
        const auto id = c.value("id").toString();
        auto d = decisions.find(c.value("decision").toString());
        const auto kind = c.value("kind").toString();
        QSet<QString> allows;
        if (!identifier(id) || ids.contains(id) || d == decisions.end() || !named(c.value("owner"))
            || !named(c.value("action")) || !named(c.value("verify")) || (kind != "required" && kind != "preference")
            || !readSet(c.value("allows"), allows) || !d->options.contains(allows)) return invalid("Invalid concern: " + id);
        ids.insert(id);
        ++d->concerns;
        if (kind == "required") {
            d->feasible.intersect(allows);
            d->blockers << id;
        } else if (!d->choice.isEmpty() && !allows.contains(d->choice)) {
            preferences.append(id);
        }
        QJsonObject step{{"id",id},{"owner",c.value("owner")},{"action",c.value("action")},{"verify",c.value("verify")}};
        if (observations && kind == "required") {
            const auto observed = observations->value(id).toObject();
            const auto result = observed.value("result").toString();
            step.insert("result", result.isEmpty() ? QStringLiteral("missing") : result);
            if (result == "disputed") conflicts.append(QJsonObject{{"decision",d->id},{"concern",id},{"authority",d->authority}});
            else if (result != "pass" || !named(observed.value("record"))) open.append("Verify " + id + ": " + c.value("verify").toString());
        }
        steps.append(step);
    }
    if (ids.isEmpty() || decisions.isEmpty()) return invalid("Specify at least one concern and decision.");
    if (observations) {
        for (auto it = observations->begin(); it != observations->end(); ++it)
            if (!ids.contains(it.key())) return invalid("Unknown observation: " + it.key());
    }
    for (const auto &d : decisions) {
        if (!d.concerns) return invalid("Decision has no stakeholder concerns: " + d.id);
        auto feasible = d.feasible.values();
        std::sort(feasible.begin(), feasible.end());
        QJsonObject summary{{"decision",d.id},{"authority",d.authority},{"feasible",QJsonArray::fromStringList(feasible)},{"choice",d.choice}};
        choices.append(summary);
        if (feasible.isEmpty() || (!d.choice.isEmpty() && !d.feasible.contains(d.choice))) {
            summary.insert("required_concerns", QJsonArray::fromStringList(d.blockers));
            conflicts.append(summary);
        } else if (d.choice.isEmpty() || d.reason.trimmed().isEmpty()) open.append("Obtain the decision and reason from " + d.authority + " for " + d.id);
    }
    const QString status = !conflicts.isEmpty() ? "conflict" : !open.isEmpty() ? "open" : observations ? "verified" : "agreed";
    QJsonObject result{{"status",status},{"steps",steps},{"decisions",choices},{"open",open},{"conflicts",conflicts},{"unmet_preferences",preferences}};
    if (!conflicts.isEmpty()) result.insert("interview","aieng-ticket questions conflict");
    return result;
}
