// Copyright © 2026 Samuel A. Gray III. All rights reserved.
#include "Packet.h"
#include "CandidateTransfer.h"
#include "aieng/application/TicketApplication.h"
#include <QCoreApplication>
#include <QJsonArray>
#include <QDateTime>
#include <QFile>
#include <QUuid>
#include <sys/stat.h>
#include <unistd.h>

using namespace aieng::application;
using namespace aieng::domain;

static QString newId()
{
    return QUuid::createUuid().toString(QUuid::WithoutBraces);
}

int main(int argc, char **argv)
{
    QCoreApplication process(argc, argv);
    const auto args = process.arguments();
    const QHash<QString, Role> options{{"--support-uid", Role::Support}, {"--worker-uid", Role::Agent},
                                       {"--developer-uid", Role::Developer}, {"--qa-uid", Role::Qa},
                                       {"--release-uid", Role::Release}, {"--operator-uid", Role::Operator}};
    if (args.size() != 4 && (args.size() != 6 || !options.contains(args[4]))) return 2;
    uint configuredUid = 0;
    if (args.size() == 6) {
        bool valid = false;
        configuredUid = args[5].toUInt(&valid);
        if (!valid || args[5] != QString::number(configuredUid)) return 2;
    }
    umask(0077);
    constexpr int fd = STDIN_FILENO;
    ucred peer{};
    socklen_t length = sizeof(peer);
    sockaddr_storage address{};
    socklen_t addrLength = sizeof(address);
    int type = 0;
    socklen_t typeLength = sizeof(type);
    if (getpeername(fd, reinterpret_cast<sockaddr *>(&address), &addrLength) != 0
        || address.ss_family != AF_UNIX || getsockopt(fd, SOL_SOCKET, SO_TYPE, &type, &typeLength) != 0
        || type != SOCK_SEQPACKET || getsockopt(fd, SOL_SOCKET, SO_PEERCRED, &peer, &length) != 0
        || peer.pid <= 0 || !intake::setTimeouts(fd)) return 2;
    const auto request = intake::receivePacket(fd);
    const auto op = request.value("op").toString();
    const bool create = op == "create" && request.size() == 3
        && request.value("summary").isString() && request.value("description").isString();
    const bool show = op == "show" && request.size() == 2 && request.value("id").isString();
    const bool checkout = (op == "qa-checkout" || op == "deploy-fetch") && request.size() == 2 && request.value("id").isString();
    const bool list = op == "list" && request.size() == 3 && request.value("state").isString() && request.value("after").isString();
    const bool supportAction = op == "triage" || op == "queue";
    const bool claim = op == "claim";
    const bool propose = op == "propose";
    bool versionValid = false;
    const auto versionText = request.value("version").toString();
    const auto version = versionText.toULongLong(&versionValid);
    const bool versioned = request.value("id").isString() && versionValid && version > 0 && QString::number(version) == versionText;
    const auto byteCount = request.value("size").toInteger();
    const bool admit = op == "qa-admit" && versioned && request.size() == 4 && byteCount > 0 && byteCount <= maxCandidateBytes;
    const bool manual = op == "propose-file" && versioned && request.size() == 4 && request.value("digest").isString();
    const bool deployStep = op == "deploy-start" || op == "deploy-confirm";
    const bool approve = (op == "qa-pass" || op == "release-approve" || deployStep) && versioned && request.size() == 5
        && request.value("digest").isString() && request.value("rationale").isString();
    const bool transition = supportAction && versioned && request.size() == 4 && request.value("rationale").isString();
    const auto proofText = request.value("proof").toString().toLatin1();
    const auto proof = QByteArray::fromHex(proofText);
    const bool workerAction = versioned && proof.size() == 32 && proof.toHex() == proofText
        && ((claim && request.size() == 4) || (propose && request.size() == 5
            && request.value("digest").isString() && !request.value("digest").toString().isEmpty()));
    if (!create && !show && !transition && !list && !workerAction && !admit && !manual && !checkout && !approve) {
        intake::sendPacket(fd, {{"error", "Invalid ticket request"}});
        return 1;
    }
    const Role role = args.size() == 6 && peer.uid == configuredUid ? options.value(args[4]) : Role::Reporter;
    const bool support = role == Role::Support;
    const bool worker = role == Role::Agent;
    const bool qa = role == Role::Qa;
    if (manual && role != Role::Developer) {
        intake::sendPacket(fd, {{"error", "Project developer access required"}});
        return 1;
    }
    if ((admit || op == "qa-checkout" || (approve && op == "qa-pass")) && !qa) {
        intake::sendPacket(fd, {{"error", "Project QA access required"}});
        return 1;
    }
    if ((deployStep || op == "deploy-fetch") && role != Role::Operator) {
        intake::sendPacket(fd, {{"error", "Project operator access required"}});
        return 1;
    }
    if (approve && op == "release-approve" && role != Role::Release) {
        intake::sendPacket(fd, {{"error", "Project release access required"}});
        return 1;
    }
    if (workerAction && !worker) {
        intake::sendPacket(fd, {{"error", "Project worker access required"}});
        return 1;
    }
    const bool qaList = qa && (request.value("state") == "PATCH_PROPOSED" || request.value("state") == "QA_RUNNING");
    const bool repairList = (worker || role == Role::Developer) && request.value("state") == "AGENT_QUEUED";
    const bool releaseList = role == Role::Release && request.value("state") == "QA_APPROVED";
    if ((transition || (list && !qaList && !repairList && !releaseList)) && !support) {
        intake::sendPacket(fd, {{"error", "Project support access required"}});
        return 1;
    }
    QFile key(args[2]);
    struct stat info{};
    if (!key.open(QIODevice::ReadOnly) || fstat(key.handle(), &info) != 0 || !S_ISREG(info.st_mode)
        || (info.st_mode & 0077) != 0 || info.st_size != 32) return 2;
    TicketStore store(args[1], key.read(33));
    QString error;
    if (!store.open(&error)) {
        intake::sendPacket(fd, {{"error", "Ticket storage is unavailable"}});
        return 1;
    }
    AuthenticatedPrincipal principal;
    principal.subject = QStringLiteral("local-uid-%1").arg(peer.uid);
    principal.trustDomain = QStringLiteral("local-unix");
    principal.projectRoles[args[3]].insert(Role::Reporter);
    principal.projectRoles[args[3]].insert(role);
    principal.authenticated = true;
    TicketApplication app(store);
    const TrustedCommandContext context{newId(), QDateTime::currentDateTimeUtc().toString(Qt::ISODateWithMs)};
    const auto ticketId = request.value("id").toString();
    ApplicationResult response;
    if (create) {
        response = app.createTicket({newId(), args[3], request.value("summary").toString(), request.value("description").toString()},
                                    principal, context);
    } else if (list) {
        response = app.listQueue(args[3], request.value("state").toString(), request.value("after").toString(), principal);
    } else if (show || checkout) {
        response = app.readTicket(ticketId, principal);
        if (checkout && response.succeeded()) {
            if (op == "deploy-fetch" && response.ticket.state != TicketState::ReleaseApproved
                && response.ticket.state != TicketState::Deploying) {
                intake::sendPacket(fd, {{"error", "Approved release required"}});
                return 1;
            }
            const auto bytes = store.verifiedCandidate(ticketId, &error);
            if (bytes.isEmpty()) {
                intake::sendPacket(fd, {{"error", "Verified candidate unavailable"}});
                return 1;
            }
            return intake::sendPacket(fd, {{"id", ticketId}, {"artifact_digest", response.ticket.artifactDigest},
                {"size", static_cast<qint64>(bytes.size())}}) && intake::sendCandidate(fd, bytes) ? 0 : 1;
        }
    } else if (approve) {
        const QHash<QString, TicketState> targets{{"qa-pass", TicketState::QaApproved}, {"release-approve", TicketState::ReleaseApproved},
            {"deploy-start", TicketState::Deploying}, {"deploy-confirm", TicketState::Deployed}};
        response = app.transitionTicket({ticketId, targets.value(op),
            version, request.value("rationale").toString(), request.value("digest").toString()}, principal, context);
    } else if (admit) {
        response = app.readTicket(ticketId, principal);
        if (response.succeeded()) {
            const auto &ticket = response.ticket;
            if (ticket.state != TicketState::PatchProposed || ticket.version != version
                || ticket.patchAuthorId == principal.subject || ticket.patchAuthorId.isEmpty()) {
                intake::sendPacket(fd, {{"error", "Independent QA requires a current patch proposal"}});
                return 1;
            }
            if (!intake::sendPacket(fd, {{"ready", true}})) return 1;
            const auto bytes = intake::receiveCandidate(fd, byteCount);
            if (bytes.isEmpty()) {
                intake::sendPacket(fd, {{"error", "Incomplete candidate transfer"}});
                return 1;
            }
            response = app.transitionTicket({ticketId, TicketState::QaRunning, version, QStringLiteral("Independent QA received candidate"),
                ticket.artifactDigest, {}, bytes}, principal, context);
        }
    } else if (manual) {
        response = app.transitionTicket({ticketId, TicketState::PatchProposed, version, QStringLiteral("Developer proposed candidate file"),
            request.value("digest").toString()}, principal, context);
    } else if (workerAction) {
        response = app.transitionTicket({ticketId, claim ? TicketState::AgentQueued : TicketState::PatchProposed, version,
            claim ? QStringLiteral("Worker claimed queued ticket") : QStringLiteral("Worker proposed candidate artifact"),
            request.value("digest").toString(), proof}, principal, context);
    } else {
        const auto target = op == "triage" ? TicketState::Triaged : TicketState::AgentQueued;
        response = app.transitionTicket({ticketId, target, version, request.value("rationale").toString(), {}}, principal, context);
    }
    if (!response.succeeded()) {
        intake::sendPacket(fd, {{"error", response.publicMessage}});
        return 1;
    }
    const auto &ticket = response.ticket;
    if (list) {
        QJsonArray entries;
        for (const auto &entry : response.page.entries) {
            entries.append(QJsonObject{{"id", entry.id}, {"summary", entry.summary}, {"version", QString::number(entry.version)}});
        }
        return intake::sendPacket(fd, {{"tickets", entries}, {"next_after", response.page.nextAfter}}) ? 0 : 1;
    }
    QJsonObject output{{"id", ticket.id}, {"state", Workflow::stateName(ticket.state)},
        {"version", QString::number(ticket.version)}, {"project", ticket.projectId},
        {"summary", ticket.summary}, {"description", ticket.description}};
    if (claim) output.insert("lease_expires_utc", QDateTime::fromMSecsSinceEpoch(ticket.lease.expiresAtMs, Qt::UTC).toString(Qt::ISODateWithMs));
    if (!ticket.artifactDigest.isEmpty()) output.insert("artifact_digest", ticket.artifactDigest);
    return intake::sendPacket(fd, output) ? 0 : 1;
}
