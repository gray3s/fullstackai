# AIEng

**Version 0.2.0 — experimental source release.** See
[release notes](RELEASE_NOTES_v0.2.0.md) for included scope and verification status.

AIEng is a secure, self-hosted engineering workstation and DevSecOps control
plane for Ubuntu. It combines C, C++, C#, and Qt 6 development, corporate
support-ticket intake, a local patch-generation agent, isolated test execution,
human QA approval, signed artifacts, and controlled production promotion.

> Project viewpoint: December 2026. The architecture assumes modern software-
> supply-chain controls while remaining deployable on an Ubuntu server today.

## Core safety rule

The local AI can read an assigned ticket, create a branch, propose a patch, and
run approved tests in an isolated worker. It cannot approve its own work, access
production credentials, or deploy to production. QA and production promotion
are separate, attributable human actions.

The intended developer experience is a native AIEng extension to Qt Creator,
backed by independently deployable native C++ services. AIEng is also its own
first governed project: it must QA and secure itself through the same evidence
pipeline it generates for other projects, without allowing AI self-approval.

## Current verified state

The [project goals and delivery plan](docs/PROJECT_GOALS.md) define how AIEng turns stakeholder requirements and applicable standards into reviewed work and release evidence.

The installed control plane is a native program. It runs without a model.
Staff can file tickets, support can queue them, and a human developer or optional
worker can propose a candidate. QA, release and operations have separate commands
for reviewing the file, approving it and recording its installation.
The [version operating model](docs/VERSION_OPERATING_MODEL.md) records who builds,
runs and operates each version. The latest checkpoints under `docs/checkpoints/`
record the scope of local verification.

## Repository map

- `apps/control-plane`: native ticket, approval, deployment, and audit service
- `apps/agent`: native local-model orchestration and deterministic tool broker
- `apps/creator-plugin`: native AIEng Qt Creator integration
- `libs`: reusable native domain, policy, evidence, and protocol libraries
- `tests`: deterministic, adversarial, integration, and golden-project suites
- `toolchains`: reproducible C/C++/Qt 6 and .NET build images
- `infra`: local turnkey deployment configuration
- `docs`: architecture, security model, operations, and decision records
- `scripts`: bootstrap, verification, backup, and recovery commands

## Development

```bash
make check
```

This runs the no-Python audit, builds the native targets and executes CTest. The
intake integration suite uses systemd-socket-activate, openssl, jq and a private
Unix socket to file and retrieve a ticket across two service invocations.

## Try staff ticket intake on Ubuntu

From the repository root, build with `make check`. Start a private development
instance with the following commands. The printed directory identifies this
instance and holds its database and key. Keep both together for recovery.

```bash
umask 077
intake_dir=$(mktemp -d)
printf '%s\n' "$intake_dir"
openssl rand -out "$intake_dir/key" 32
systemd-socket-activate --seqpacket --accept --inetd -l "$intake_dir/socket" \
    build/dev/apps/control-plane/aieng-ticket-service "$intake_dir/tickets.db" "$intake_dir/key" demo
```

In another terminal at the repository root, set `intake_dir` to the printed
directory. The first command returns the ticket ID. Use that ID in the second.

```bash
printf '%s\n' 'Opening the Qt kit closes the editor.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" create 'Qt kit closes editor'
build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" show TICKET-ID
```

Ctrl+C stops the listener. Reuse the directory and key to reopen the instance.
To file and look up tickets in the Qt staff form, run
`build/dev/apps/control-plane/aieng-staff "$intake_dir/socket"` while the listener runs.
After filing, use **Copy ticket ID** to save the reference for follow-up.
The local service associates each reporter with the kernel-supplied Unix UID.
Use a dedicated database per host identity domain. This development transport
supports filing and reading your own tickets. Corporate remote login and
agent processing are pending.

### Start with the developer's algorithm

Run `aieng-ticket SOCKET design`. The first prompt asks what algorithm you want developed into code.
Describe the intent, inputs, outputs and rule in your own words. Enter `:split` at a rule to describe smaller behaviors recursively.
Each leaf asks for an example and an observable failure. QA can use those answers as the basis for checks.

For a method question, press Enter to use the displayed default, enter your own method, or enter `?` to keep the question open.
Enter `:defaults` to finish the remaining interview with open behavioral questions and labeled design, implementation, QA and
deployment defaults. The interview records the developer's priority, the reported IT concern and its acceptance condition.
Design, implementation and QA options include their expected benefit and cost; a custom method can carry its own trade-off.
The rollout comparison considers parallel capacity and a permitted maintenance window. Unknown or conflicting prerequisites stay
visible in the ticket. These assessments are qualitative and the operator verifies them on the actual target.
For the shortest route, run `aieng-ticket SOCKET design --defaults` and enter only the algorithm.
The service files the result as an open ticket. Read it with `show` to review the choices before triage. These are proposed methods.
The existing QA and release approvals apply when the candidate moves through the delivery workflow.

### Triage a ticket and queue it for repair

To designate a local support operator for the listener's project, append
`--support-uid NUMERIC-UID` to the **service** command at startup. For a private
demo, use your own numeric UID from `id -u`. The service matches this setting
against the UID supplied by the kernel for each connection. Omitting the setting
keeps the listener in reporter mode.

Use `aieng-ticket SOCKET list OPEN` to find reports that need triage. Use
`TRIAGED` or `AGENT_QUEUED` to inspect the later queues. Results include up to
25 ticket IDs, summaries and versions ordered by ticket ID. When `next_after`
contains an ID, pass it as the final argument to fetch the next page. Each
request reflects current state, so restart the listing to include newly queued
items whose IDs sort before the cursor.

Use the version returned by `show` or by the last successful transition. For a
new ticket the sequence is:

```bash
printf '%s\n' 'Confirmed the failure with the Qt kit.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" triage TICKET-ID 1
printf '%s\n' 'Prepare a candidate fix for this build failure.' | \
    build/dev/apps/control-plane/aieng-ticket "$intake_dir/socket" queue TICKET-ID 2
```

If another operator acts first, re-read the ticket before deciding whether
the action is still appropriate. A successful queue command records
`AGENT_QUEUED` and its rationale. This persisted state is the shared repair
queue and also serves installations running entirely with human developers.

### Submit a human repair with the worker off

Leave the worker listener stopped. Configure a private developer listener with
`--developer-uid NUMERIC-UID` and the same service database, key and project.
The developer can list the queue, read the assigned work order and submit the
digest of a candidate file. Hand the same file to the independent QA reviewer.

```bash
aieng-ticket DEV-SOCKET list AGENT_QUEUED
aieng-ticket DEV-SOCKET show ID
aieng-ticket DEV-SOCKET propose-file ID VERSION ./candidate
```

An active worker lease holds the ticket until its deadline. If pickup is disabled
mid-job, the developer may submit at expiry using the current ticket version.
Stopping the socket blocks new connections. An already accepted service process
can finish its current request.

### Claim a queued ticket

Start a second listener on a private worker socket, with the same database,
key and project as the support listener. Use `--worker-uid NUMERIC-UID`
on that listener to designate the local worker account. Keep the service key
and database private to the service. The worker needs access to its socket.
Run the following in the worker environment, replacing SOCKET, ID and VERSION
with the socket path and the values returned by the queue.

```bash
aieng-ticket SOCKET list AGENT_QUEUED
umask 077
proof=$(mktemp)
openssl rand -hex 32 > "$proof"
aieng-ticket SOCKET claim ID VERSION < "$proof"
```

The winning worker receives the description, an incremented version and a UTC
expiry. Each lease lasts five minutes on the service host clock. The queue can
include leased tickets. A competing claim is refused until expiry. Save the
original version and protected proof file before claiming. After a lost reply
or worker restart, repeat that claim within its lease to recover the same
version and deadline. After expiry, list again and use a fresh proof.

To record a candidate digest, use the claim version and the candidate's SHA-256.

```bash
aieng-ticket SOCKET propose ID CLAIM-VERSION sha256:HEX < "$proof"
```

The service records the worker identity and
digest and moves the ticket to `PATCH_PROPOSED`. That record is a worker's
declaration. Artifact custody and independent verification require separate evidence.

### Admit a candidate to QA

Start a project listener with `--qa-uid NUMERIC-UID` for a reviewer with a separate
Unix account from the patch author. On the QA account, identify the pending proposal
and submit the candidate file received for review.

```bash
aieng-ticket QA-SOCKET list PATCH_PROPOSED
aieng-ticket QA-SOCKET qa-admit ID PROPOSAL-VERSION ./candidate
```

The service accepts a regular file from 1 byte through 16 MiB, hashes the uploaded
bytes, and checks the result against the proposal. A successful admission stores
the bytes in SQLite and records the responsible QA identity in the same transaction
that moves the ticket to `QA_RUNNING`.

### Test and deliver the approved file

QA retrieves a verified copy into a new private file using
`aieng-ticket QA-SOCKET qa-checkout ID NEW-FILE`. Test that file in the review
environment. Submit a short review with the exact tested digest. Configure a
separate release listener with `--release-uid NUMERIC-UID` and an operator
listener with `--operator-uid NUMERIC-UID` on the same project database.

```bash
aieng-ticket QA-SOCKET qa-pass ID VERSION sha256:HEX < review.txt
aieng-ticket RELEASE-SOCKET list QA_APPROVED
aieng-ticket RELEASE-SOCKET release-approve ID VERSION sha256:HEX < release-decision.txt
aieng-ticket OPS-SOCKET deploy-start ID VERSION sha256:HEX < target-plan.txt
aieng-ticket OPS-SOCKET deploy-fetch ID NEW-FILE
```

Use the version returned by the previous step. The operator installs the fetched
file, checks behavior from its installed path, and retains the previous release.
Record success with `aieng-ticket OPS-SOCKET deploy-confirm ID VERSION sha256:HEX < smoke-result.txt`.
The service records the operator's attestation. The target-specific installer
and its smoke test run under operator control.

The Carton Count experiment carries the published example through these steps
in a fresh local directory. It uses the supplied patch and two test principals
to represent distinct developer and release accounts on a single-login machine.
Run the release suite, then run the experiment with retained evidence:

```bash
./scripts/release-check.sh
bin=build/release/apps/control-plane
bash tests/carton_delivery.sh "$bin/aieng-ticket" "$bin/aieng-ticket-service" "$bin/aieng-qa-fixture" --keep
```

See [Architecture](docs/ARCHITECTURE.md), [Security model](docs/SECURITY.md),
[QA plan](docs/QA_PLAN.md), and the
[research baseline](docs/research/20261119_AIENG_PRIMARY_SOURCE_RESEARCH_BASELINE.md)
before enabling an agent or connecting any external environment.

The [product requirements](docs/PRODUCT_REQUIREMENTS.md) define the guided
production path for inexperienced creators and the CTO-grade controls that may
not be bypassed.
The [pilot goals](docs/PROJECT_GOALS.md) prioritize live-worker QA, then deployment of an approved artifact, then repetition on an unfamiliar project.

## Ownership

Copyright © 2026 Samuel A. Gray III. All rights reserved.

This repository is proprietary. No license to copy, modify, distribute,
sublicense, or operate this software for third parties is granted without the
copyright holder's written permission.

