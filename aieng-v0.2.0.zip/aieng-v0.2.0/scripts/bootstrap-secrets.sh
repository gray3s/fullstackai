#!/usr/bin/env bash
set -euo pipefail
umask 077

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
secrets_dir="$project_dir/secrets"
env_file="$project_dir/.env"
mkdir -p "$secrets_dir"

if [[ ! -f "$env_file" ]]; then
  cp "$project_dir/.env.example" "$env_file"
fi

replace_once() {
  local key="$1" value="$2"
  sed -i "s|^${key}=.*|${key}=${value}|" "$env_file"
}

postgres_password="$(openssl rand -hex 24)"
keycloak_password="$(openssl rand -hex 24)"
ide_password="$(openssl rand -hex 24)"
replace_once POSTGRES_PASSWORD "$postgres_password"
replace_once KEYCLOAK_ADMIN_PASSWORD "$keycloak_password"
replace_once CODE_SERVER_PASSWORD "$ide_password"

if [[ ! -f "$secrets_dir/audit_hmac" ]]; then
  openssl rand -hex 32 > "$secrets_dir/audit_hmac"
fi
if [[ ! -f "$secrets_dir/tls.key" ]]; then
  openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days 30 \
    -subj "/CN=aieng.local/O=AIEng Development" \
    -addext "subjectAltName=DNS:aieng.local" \
    -keyout "$secrets_dir/tls.key" -out "$secrets_dir/tls.crt"
fi

printf 'Bootstrap complete.\nKeycloak user: %s\nKeycloak password: %s\nIDE password: %s\n' \
  "${KEYCLOAK_ADMIN:-bootstrap-admin}" "$keycloak_password" "$ide_password"
printf 'Store these credentials in your password manager; rotate them after first login.\n'

