# Architecture

## Outcome

AIEng provides one governed path from a staff-reported problem to a deployed
fix. Every state transition is authenticated, authorized, and audit recorded.

```text
Corporate user -> Ticket portal -> Control plane -> Agent job queue
                                          |               |
                                          |               v
                                          |        Ephemeral workspace
                                          |        local model + tests
                                          |               |
                                          v               v
                                     append-only audit <- patch proposal
                                          |
                         QA reviewer -> QA environment -> release approver
                                                               |
                                                               v
                                                    signed prod deployment
```

## Trust zones

1. **User zone**: browser and optional Ubuntu desktop client. No shared secrets.
2. **Control zone**: reverse proxy, OIDC provider, API, database, audit store.
3. **Build zone**: short-lived, network-restricted workers with read-only base
   images and per-job writable workspaces.
4. **QA zone**: production-like but contains synthetic or redacted data only.
5. **Production zone**: separate credentials, network, and deployment runner.

The build zone cannot route to production. The control plane stores references
to deployment credentials, never raw long-lived production secrets. A later
HA deployment uses OpenBao or an existing corporate vault for short-lived
credentials.

## Components

| Component | Responsibility |
| --- | --- |
| Nginx | TLS termination, request limits, security headers, route isolation |
| Keycloak | OIDC login, MFA/WebAuthn, group-to-role mapping |
| Control API | workflow invariants, RBAC, approvals, immutable audit chain |
| PostgreSQL | transactional workflow state and audit records |
| Agent worker | claim job, create branch, ask local model, validate diff |
| Sandbox runner | compile/test/SAST/SBOM in an ephemeral constrained container |
| code-server | browser IDE with organization-approved extensions/toolchains |
| Registry | OCI images, SBOMs, attestations, signed release artifacts |

## Native control-plane boundaries

The security-critical workflow is split into layers with one-way authority:

```text
ingress / Qt Creator adapter
    -> authentication adapter (verifies issuer, audience, signature, lifetime)
    -> bounded command decoder (no actor field accepted from request content)
    -> application service (principal, command, trusted event context)
    -> domain policy (transition and separation-of-duties authority)
    -> transactional state + audit store
```

Only the authentication adapter constructs an `AuthenticatedPrincipal`. The
application service derives the domain actor and ticket reporter from that
principal. It rejects unauthenticated or malformed identities, unbounded text,
non-UTC event context, malformed artifact digests, and storage-integrity
failures before returning a transport-safe result. Operator diagnostics are
separate from public error text.

Token verification and authorization mapping are distinct. The verifier owns
raw JWT/JWS/JWK/DPoP parsing and cryptographic proof under mutually exclusive
token profiles. The identity policy then applies exact issuer/audience/time,
group mapping, sender-constraint, and privileged step-up rules. A claims struct
is never treated as cryptographic evidence merely because it has a trusted
type name; see ADR 0003.

The patch author must bind a lowercase SHA-256 artifact digest when proposing
the patch. Earlier transitions cannot inject a digest; QA, release, and deploy
steps must carry the identical digest. A model may propose that artifact but
cannot approve it.

Human and workload roles are project-scoped. A role granted for one project is
not presented to the domain while acting on another project's ticket. Platform
roles are stored separately and do not implicitly confer QA, release, or
operator authority.

SQLite schema version 2 stores an HMAC-SHA-256 integrity tag over every current
ticket security field, including project, workflow state/version, attributable
identities, and artifact digest. Ticket reads verify the tag before the row can
drive authorization or mutation. This complements the chained history: the row
tag detects current-state changes, while the audit chain detects history
tampering, deletion, and reordering. Unsupported version-1 databases fail
closed pending an explicit offline migration; they are never silently blessed.
The audit chain and current-row tags use distinct purpose-labeled HMAC subkeys
derived from the injected master secret.

The control API transport is unresolved pending ADR 0002's disposable-VM
qualification. No embedded Qt HTTP listener may be externally exposed.

## Workflow state machine

```text
OPEN -> TRIAGED -> AGENT_QUEUED -> PATCH_PROPOSED -> QA_RUNNING
  -> QA_APPROVED -> RELEASE_APPROVED -> DEPLOYING -> DEPLOYED

Any active state may move to NEEDS_HUMAN or REJECTED. A failed deployment moves
to ROLLBACK_REQUIRED; rollback is a distinct, audited human-authorized action.
```

No endpoint accepts an arbitrary target state. The server owns the allowed
transition table and enforces role, separation-of-duties, and optimistic
version checks.

## Delivery phases

- Phase 1: executable control-plane core, local Compose topology, tests.
- Phase 2: portal UI, isolated agent patch loop, C/C++/Qt/.NET toolchains.
- Phase 3: Git forge/registry integration, SBOM/signing, QA environment runner.
- Phase 4: production promotion adapter, HA, backup/restore, security validation.

