#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

forbidden_files="$({
  find . -path './.git' -prune -o -path './build' -prune -o \
    \( -name '*.py' -o -name '*.pyc' -o -name '*.pyo' -o \
       -name 'pyproject.toml' -o -name 'requirements.txt' -o \
       -name 'Pipfile' -o -name 'poetry.lock' -o -name '__pycache__' -o \
       -name '.venv' -o -name 'venv' \) -print
} | sort)"

if [[ -n "$forbidden_files" ]]; then
  printf 'Forbidden Python artifacts found:\n%s\n' "$forbidden_files" >&2
  exit 1
fi

invocations="$(rg -n --hidden \
  --glob '!build/**' --glob '!build-*/**' --glob '!.git/**' \
  --glob '!docs/**' --glob '!AGENTS.md' --glob '!scripts/no-python-check.sh' \
  '(^|[^[:alnum:]_-])(python[0-9.]*|pip[0-9.]*)[[:space:]]' . || true)"

if [[ -n "$invocations" ]]; then
  printf 'Forbidden Python interpreter/package invocations found:\n%s\n' "$invocations" >&2
  exit 1
fi

printf 'No-Python gate passed.\n'

